$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$bundledJdkPath = Join-Path $project 'tools/jdk'
$jdk = if (Test-Path -LiteralPath $bundledJdkPath) { Get-ChildItem -LiteralPath $bundledJdkPath -Directory | Select-Object -First 1 }
if ($jdk) {
    $env:JAVA_HOME = $jdk.FullName
    $env:PATH = "$(Join-Path $jdk.FullName 'bin');$env:PATH"
} elseif (-not ((& java -version 2>&1 | Out-String) -match 'version "21\.')) {
    throw 'JDK 21 is required. Install it or place it in tools/jdk.'
}
$env:GRADLE_USER_HOME = Join-Path $project 'tools/gradle-home'
Push-Location $project
try {
    & .\gradlew.bat build --no-daemon
    if ($LASTEXITCODE -ne 0) { throw "Gradle failed with exit code $LASTEXITCODE" }
    $version = ([regex]::Match((Get-Content (Join-Path $project 'build.gradle') -Raw), "(?m)^version = '([^']+)'$")).Groups[1].Value
    if (-not $version) { throw 'Cannot determine mod version from build.gradle.' }
    $artifact = "hollow-signal-$version.jar"
    Copy-Item -LiteralPath (Join-Path $project "build/libs/$artifact") -Destination (Join-Path $project "release/$artifact") -Force
} finally { Pop-Location }
