# Hollow Signal / Пустой сигнал

Minecraft Java **1.21.1**, Fabric, Java 21. Requires Fabric API. Version 2.5.0.

Hollow Signal turns every night into an escalating encounter. Time spent in low light builds exposure; the signal answers with warnings, hunters and, if you call it, a boss. Bright light, daylight, sleeping and Ward Beacons push exposure back down. Creative and spectator players are never targeted.

## The exposure loop

Exposure rises once every five seconds while it is night, you are in light level 7 or lower, awake and outside a warded area. The client shows a small meter in the lower left corner with the current night event above it.

- **25 / 50 / 75** send escalating warnings with a heartbeat cue.
- **50** sends a Hollow Watcher after you.
- **100** brings the Signal Stalker, then drops exposure to 20 so the night keeps building.

## Night events

At dusk the world rolls one event for the whole night. A compact five-second banner shows its name and rules without covering the crosshair; the event name stays on the exposure HUD until sunrise.

- **Signal Storm:** exposure builds twice as fast, Dread Moths ride the storm, and electric sparks crackle around you.
- **Dead Silence:** no warnings at all, exposure creeps through smoke, but the Stalker arrives at 70 and everything that spawns is faster.
- **Echo Hunt:** ghostly blue flames mark the hunt, Watchers arrive in pairs, and every mod mob drops double Echo Shards.
- **Convergence:** portal motes signal nearby rifts, Null Creepers gather, and the Hollow Herald will answer a ritual.
- **Red Eclipse:** crimson spores and a deep heartbeat signal faster exposure; swift Null Creepers emerge earlier, and rift guards arrive more often.
- **Echo Bloom:** drifting lights mark an unstable harvest. Hollow mobs drop double shards; killing one removes 18 exposure, and sealing a rift yields two extra shards.

World operators can use `/hollowsignal event <event_id>` (or `/hollowsignal event random`) to stage an event immediately. Valid IDs are `calm`, `signal_storm`, `dead_silence`, `echo_hunt`, `convergence`, `red_eclipse`, and `echo_bloom`.

Survive an event after reaching 50 exposure, sealing a rift or defeating a Hollow mob to receive 2–4 Echo Shards at dawn. Dying before sunrise loses that night's reward. Staying safe inside a ward or sleeping through the night does not qualify on its own.

## Signal Rifts

At 50 exposure, a Signal Rift can open on nearby ground. During Convergence it can open from 35 exposure. Its crystal gives off light and soul particles, increases exposure for players within eight blocks, and calls Hollow Watchers to defend it. Rifts become dormant by day but remain in the world until closed.

While a survival player stays within 24 blocks at night, the rift escalates through three phases. After a six-second warning, Watchers arrive in waves; the last phase also calls a Null Creeper. Each pulse is visible and audible, slows players within eight blocks and can hurt players within four blocks in the later phases. The number of guards is capped. You can seal the rift early to escape the fight, or hold out for a larger reward.

Right click the crystal with an Echo Shard, or shoot it with the Resonator, to seal it. The charge is spent and the rift yields 2–4 Echo Shards and eight experience points, plus one shard and four experience points for each phase survived, and 15 seconds of Resistance and Speed. Sealing it clears your exposure and delays a new rift for two minutes. The Signal Finder reports the distance and cardinal direction of a rift within 32 blocks.

At half health the Hollow Herald enters a red-bar second phase and opens a rift. While a rift remains within 16 blocks, it heals the boss. Closing the crystal turns that regeneration off, making the Resonator's ranged shot useful in the boss fight.

## Enemies

| Mob | Health | Behaviour | Drop |
| --- | --- | --- | --- |
| Hollow Watcher | 22 | A fast arachnid that snares its target with a purple pulse; its bite also slows | 1 Echo Shard |
| Signal Stalker | 34 | A masked hunter that phases behind targets and inflicts Darkness in melee | 2–3 Echo Shards |
| Dread Moth | 16 | A flier with emissive eyes and a sonic shriek that darkens nearby players' vision | 1–2 Echo Shards |
| Null Creeper | 18 | Its core and sparks swell while it primes a blast: no block damage, but Darkness and Slowness nearby | 1–3 Echo Shards |
| Hollow Herald | 160 | A boss with an announced sonic pulse, a Watcher escort and a second-phase healing rift | Echo Heart + 8–12 Echo Shards |

Spawn eggs for all five are available in the Creative inventory.

## The ritual

Place an Echo Block, wait for night, then right click the block with an Echo Shard. The shard is consumed and the Hollow Herald arrives. The ritual fails during the day, or while another Herald is alive within 64 blocks. Set `herald_ritual=false` in the config to disable it.

## Equipment and base defence

- **Signal Finder:** right click to reveal nearby threats with a brief soul-particle burst and locate the nearest Signal Rift. 96 uses, 12-second cooldown. Recipe: compass, two amethyst shards, iron ingot, redstone.
- **Ward Charm:** clears exposure, grants Resistance for ten seconds and Night Vision for fifteen. One-minute cooldown. Recipe makes two from an Echo Shard, four gold nuggets and string.
- **Echo Totem:** held in either hand, it is consumed instead of letting you die: it restores you, clears every effect, clears exposure and grants Regeneration, Resistance and Night Vision. Recipe uses an Echo Heart, four Echo Shards and four gold ingots.
- **Echo Blade:** sword on the echo material (1240 durability, repaired with Echo Shards). Hits deal 5 extra damage to Hollow mobs and repair the blade; right click to blink up to five blocks through clear space and strike nearby enemies, with a quick slash animation and arrival ring. Six-second ability cooldown. Recipe: two Echo Shards, two iron ingots, stick.
- **Signal Lance:** reach weapon — one extra block of attack range, heavy knockback, and Weakness on mod mobs. Right click for a piercing eight-block thrust that stops at a wall; five-second cooldown. Recipe: Echo Block, iron ingot, stick on the diagonal.
- **Resonator:** ranged weapon. Right click to fire a sonic pulse up to 24 blocks for 9 damage (13 against Hollow mobs) with knockback. Each shot spends one Echo Shard and has a 2.5-second cooldown. Sneak-right click to spend three shards on a three-ray overcharge with a seven-second cooldown. 192 durability. Recipe: two amethyst shards, an Echo Block, three iron ingots, redstone.
- **Echo Block:** nine Echo Shards compressed. Used for the ritual and to amplify a beacon.
- **Ward Beacon:** a fuelled block, not a decoration. Feed it Echo Shards (up to eight); each shard lasts two minutes of night. While lit it suppresses exposure, marks Hollow mobs with subtle sparks, and grants Night Vision inside its radius. Stack Echo Blocks directly beneath it to raise its tier:

| Echo Blocks below | Tier | Radius | Extra |
| --- | --- | --- | --- |
| 0 | 0 | 8 | Exposure suppression, light level 14 |
| 1 | 1 | 14 | Night Vision for players in range |
| 2 | 2 | 20 | Resistance for players in range |
| 3 | 3 | 26 | Burns mod mobs that enter the radius |

Right click a beacon with an Echo Heart to make it eternal: it never burns fuel again. Right click with an empty hand for its tier, radius and charge.

## Configuration

`config/hollow_signal.properties` is written on first launch.

| Key | Default | Meaning |
| --- | --- | --- |
| `exposure_rate` | 1.0 | Multiplies how fast exposure builds (0.1–5.0) |
| `night_events` | true | Roll a night event at dusk |
| `signal_spawns` | true | Let exposure spawn mobs |
| `herald_ritual` | true | Allow the Echo Block ritual |
| `exposure_hud` | true | Draw the exposure meter |
| `warning_messages` | true | Send the action bar warnings |
| `beacon_radius` | 8 | Base horizontal radius of a Ward Beacon |

## Achievements, recipes and translations

Eleven advancements track the run, from the first Echo Shard to silencing the Herald. All recipes are unlocked by holding their ingredients. The mod ships original pixel textures, custom voxel models for all three weapons, and English and Russian translations. Install the mod on the client for the custom mobs, weapons and HUD. The server sends HUD data only to clients that advertise support for it.

## Build and install

Run `powershell -ExecutionPolicy Bypass -File .\build-local.ps1` to build with the bundled JDK 21 in the full project folder; the source ZIP builds with any installed JDK 21. The distributable JAR is `release/hollow-signal-2.5.0.jar`. Install Fabric Loader and Fabric API for Minecraft 1.21.1, then put only the mod JAR into the game's `mods` folder.

In-game QA screenshots are in `release/screenshots-2.4.0/` and `release/screenshots-2.4.1/`. The gallery shots were captured with the user's Lumenite shaderpack via Iris and Sodium; the shader is optional and is not bundled in the mod JAR.

For a CurseForge gallery, use the selected survival-mode screenshots in `release/curseforge-selected-2.4.1/`. They are captured from the Minecraft client area without the window title bar. All eight validated crafting-table recipes are pictured in `release/recipes-2.4.1/`.

Upload `release/hollow-signal-curseforge-logo.png` as the CurseForge project logo. It is a square 1254×1254 PNG; the 128×128 in-game icon remains in the mod assets.

Helper scripts live in `tools/`: `make_textures.py` regenerates the textures, voxel weapon models and mod icon, `make_resources.py` regenerates boilerplate JSON without overwriting the weapon models, and `verify_resources.py` fails if any referenced model, texture or translation is missing.

The CurseForge project copy is kept in `release/curseforge-listing.md`.
