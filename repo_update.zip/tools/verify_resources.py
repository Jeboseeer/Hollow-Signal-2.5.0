"""Checks that every model, texture and translation the mod references actually ships with it."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'src/main/resources'
ASSETS = RES / 'assets/hollow_signal'
DATA = RES / 'data/hollow_signal'
SOURCE = (ROOT / 'src/main/java/dev/hollowsignal/HollowSignal.java').read_text(encoding='utf-8')
problems = []


def load(path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except json.JSONDecodeError as error:
        problems.append(f'{path.relative_to(ROOT)}: invalid JSON ({error})')
        return None


def asset(reference, kind):
    namespace, _, name = reference.partition(':')
    if not name:
        namespace, name = 'minecraft', reference
    if namespace != 'hollow_signal':
        return None
    return ASSETS / f'{kind}/{name}.{"png" if kind == "textures" else "json"}'


items = set(re.findall(r'register\("([a-z_]+)"', SOURCE))
blocks = set(re.findall(r'Identifier\.of\(MOD_ID, "([a-z_]+)"\),\s*\n?\s*new (?:Ward|Block)', SOURCE))
entities = set(re.findall(r'registerEntity\("([a-z_]+)"', SOURCE))

for item in sorted(items):
    model = ASSETS / f'models/item/{item}.json'
    if not model.exists():
        problems.append(f'missing item model for {item}')
        continue
    payload = load(model) or {}
    for texture in payload.get('textures', {}).values():
        path = asset(texture, 'textures')
        if path and not path.exists():
            problems.append(f'{item}: missing texture {texture}')
    parent = payload.get('parent', '')
    parent_path = asset(parent, 'models')
    if parent_path and not parent_path.exists():
        problems.append(f'{item}: missing parent model {parent}')

for block in sorted(blocks):
    states = ASSETS / f'blockstates/{block}.json'
    if not states.exists():
        problems.append(f'missing blockstate for {block}')
        continue
    for variant in (load(states) or {}).get('variants', {}).values():
        model_path = asset(variant['model'], 'models')
        if not model_path or not model_path.exists():
            problems.append(f'{block}: missing model {variant["model"]}')
            continue
        for texture in (load(model_path) or {}).get('textures', {}).values():
            path = asset(texture, 'textures')
            if path and not path.exists():
                problems.append(f'{block}: missing texture {texture}')

for entity in sorted(entities):
    if not (ASSETS / f'textures/entity/{entity}.png').exists():
        problems.append(f'missing entity texture for {entity}')

english = load(ASSETS / 'lang/en_us.json') or {}
russian = load(ASSETS / 'lang/ru_ru.json') or {}
expected = {f'item.hollow_signal.{item}' for item in items}
expected |= {f'block.hollow_signal.{block}' for block in blocks}
expected |= {f'entity.hollow_signal.{entity}' for entity in entities}
for key in sorted(expected - english.keys()):
    problems.append(f'en_us.json: missing key {key}')
for key in sorted(english.keys() - russian.keys()):
    problems.append(f'ru_ru.json: missing key {key}')
for key in sorted(russian.keys() - english.keys()):
    problems.append(f'en_us.json: extra key only in Russian: {key}')

used_keys = set(re.findall(r'"((?:message|event|advancement)\.hollow_signal\.[a-z_0-9.]+)"', SOURCE))
for java in (ROOT / 'src/main/java').rglob('*.java'):
    used_keys |= set(re.findall(r'"((?:message|event|advancement)\.hollow_signal\.[a-z_0-9.]+)"', java.read_text(encoding='utf-8')))
for key in sorted(used_keys - english.keys()):
    if key.endswith('warning_'):
        continue
    problems.append(f'en_us.json: missing key used in code: {key}')

for path in DATA.rglob('*.json'):
    payload = load(path)
    if payload is None:
        continue
    for reference in re.findall(r'hollow_signal:([a-z_]+)', json.dumps(payload)):
        if reference not in items and reference not in blocks and reference not in entities \
                and not (DATA / f'recipe/{reference}.json').exists() and not (DATA / f'advancement/{reference}.json').exists():
            problems.append(f'{path.relative_to(ROOT)}: unknown reference hollow_signal:{reference}')

for key in sorted(english):
    if key.startswith('advancement.') and key.endswith('.description'):
        name = key.split('.')[2]
        if not (DATA / f'advancement/{name}.json').exists():
            problems.append(f'advancement file missing for {name}')

if problems:
    print('\n'.join(sorted(set(problems))))
    print(f'{len(set(problems))} problem(s)')
    sys.exit(1)
print('all referenced models, textures and translations are present')
