"""Build the three original voxel weapon models and their colour atlases."""
from pathlib import Path
import json
import struct
import zlib

ROOT = Path(__file__).resolve().parents[1] / "src/main/resources/assets/hollow_signal"
MODELS = ROOT / "models/item"
TEXTURES = ROOT / "textures/item"

# Four-pixel swatches keep every face crisp under Minecraft's nearest filtering.
COLORS = {
    "void": (20, 17, 33, 255),
    "iron": (99, 105, 128, 255),
    "iron_light": (178, 186, 207, 255),
    "iron_dark": (54, 57, 77, 255),
    "echo": (111, 57, 166, 255),
    "echo_light": (197, 130, 245, 255),
    "echo_dark": (59, 34, 98, 255),
    "core": (67, 216, 229, 255),
    "core_light": (200, 251, 245, 255),
    "gold": (190, 139, 65, 255),
    "gold_light": (247, 210, 124, 255),
    "leather": (91, 58, 53, 255),
    "leather_light": (154, 95, 71, 255),
    "black": (35, 32, 49, 255),
    "white": (237, 219, 255, 255),
    "amethyst": (153, 94, 218, 255),
}
UV = {name: [i % 4 * 4, i // 4 * 4, i % 4 * 4 + 4, i // 4 * 4 + 4]
      for i, name in enumerate(COLORS)}


def write_atlas(name):
    pixels = bytearray()
    swatches = list(COLORS.values())
    for y in range(16):
        pixels.append(0)
        for x in range(16):
            red, green, blue, alpha = swatches[(y // 4) * 4 + x // 4]
            edge = -13 if x % 4 == 0 or y % 4 == 0 else (8 if x % 4 == 3 or y % 4 == 3 else 0)
            pixels.extend((max(0, min(255, red + edge)), max(0, min(255, green + edge)),
                           max(0, min(255, blue + edge)), alpha))

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

    image = (b"\x89PNG\r\n\x1a\n" +
             chunk(b"IHDR", struct.pack(">IIBBBBB", 16, 16, 8, 6, 0, 0, 0)) +
             chunk(b"IDAT", zlib.compress(bytes(pixels), 9)) + chunk(b"IEND", b""))
    (TEXTURES / f"{name}_3d.png").write_bytes(image)


def box(start, end, front, side=None, top=None):
    side = side or front
    top = top or front
    return {
        "from": list(start), "to": list(end),
        "faces": {
            "north": {"uv": UV[front], "texture": "#atlas"},
            "south": {"uv": UV[front], "texture": "#atlas"},
            "east": {"uv": UV[side], "texture": "#atlas"},
            "west": {"uv": UV[side], "texture": "#atlas"},
            "up": {"uv": UV[top], "texture": "#atlas"},
            "down": {"uv": UV[side], "texture": "#atlas"},
        },
    }


SWORD = [
    box((6.5, 0, 6.5), (9.5, 1, 9.5), "gold", "iron_dark", "gold_light"),
    box((7.05, 0.9, 7.05), (8.95, 5.5, 8.95), "leather", "leather", "leather_light"),
    box((6.9, 1.7, 6.9), (9.1, 2.2, 9.1), "leather_light", "leather", "leather_light"),
    box((6.9, 3.1, 6.9), (9.1, 3.6, 9.1), "leather_light", "leather", "leather_light"),
    box((6.5, 4.9, 6.5), (9.5, 5.8, 9.5), "gold", "iron_dark", "gold_light"),
    box((3, 5.5, 7), (13, 6.4, 9), "iron", "iron_dark", "iron_light"),
    box((2.5, 5.1, 6.8), (4.1, 7.1, 9.2), "gold", "iron_dark", "gold_light"),
    box((11.9, 5.1, 6.8), (13.5, 7.1, 9.2), "gold", "iron_dark", "gold_light"),
    box((6.0, 6.3, 7.15), (10.0, 10.4, 8.85), "echo", "echo_dark", "echo_light"),
    box((6.5, 10.4, 7.25), (9.5, 13.1, 8.75), "echo", "echo_dark", "echo_light"),
    box((7.0, 13.1, 7.4), (9.0, 14.7, 8.6), "echo_light", "echo", "white"),
    box((7.5, 14.7, 7.65), (8.5, 16, 8.35), "white", "iron_light", "white"),
    box((5.7, 6.7, 7.3), (6.1, 10.2, 8.7), "iron_light", "iron", "white"),
    box((6.2, 10.4, 7.3), (6.6, 12.9, 8.7), "iron_light", "iron", "white"),
    box((9.9, 6.7, 7.3), (10.3, 10.2, 8.7), "iron_light", "iron", "white"),
    box((9.4, 10.4, 7.3), (9.8, 12.9, 8.7), "iron_light", "iron", "white"),
    box((7.25, 7, 6.6), (8.75, 12.9, 7.0), "core", "core", "core_light"),
    box((7.55, 13.1, 7.0), (8.45, 14.6, 7.35), "core_light", "core", "white"),
    box((7.27, 5.55, 6.7), (8.73, 6.85, 7.1), "core_light", "core", "white"),
    box((7.45, 0.2, 6.1), (8.55, 0.85, 6.5), "core", "core", "core_light"),
    box((6.0, 8.0, 6.98), (6.45, 11.8, 7.3), "gold_light", "gold", "white"),
    box((9.55, 8.0, 6.98), (10.0, 11.8, 7.3), "gold_light", "gold", "white"),
    box((7.15, 9.3, 6.52), (8.85, 9.7, 6.65), "white", "core", "white"),
    box((7.15, 11.1, 6.52), (8.85, 11.5, 6.65), "white", "core", "white"),
    box((4.25, 6.0, 6.6), (5.7, 6.65, 6.9), "echo_light", "echo", "white"),
    box((10.3, 6.0, 6.6), (11.75, 6.65, 6.9), "echo_light", "echo", "white"),
]

LANCE = [
    box((6.4, 0, 6.4), (9.6, 1.2, 9.6), "iron_dark", "void", "iron"),
    box((7.15, 1.1, 7.15), (8.85, 11.5, 8.85), "leather", "leather", "leather_light"),
    box((6.95, 2.3, 6.95), (9.05, 2.8, 9.05), "gold", "iron_dark", "gold_light"),
    box((6.95, 5, 6.95), (9.05, 5.5, 9.05), "gold", "iron_dark", "gold_light"),
    box((6.95, 7.7, 6.95), (9.05, 8.2, 9.05), "gold", "iron_dark", "gold_light"),
    box((6.8, 10.1, 6.8), (9.2, 11.2, 9.2), "iron", "iron_dark", "iron_light"),
    box((6.2, 10.8, 7.25), (9.8, 11.7, 8.75), "gold", "iron_dark", "gold_light"),
    box((6.0, 11.2, 7.0), (10.0, 12.7, 9.0), "echo", "echo_dark", "echo_light"),
    box((7.0, 12.7, 7.25), (9.0, 14.2, 8.75), "iron_light", "echo", "white"),
    box((7.55, 14.2, 7.55), (8.45, 16, 8.45), "white", "iron_light", "white"),
    box((6.25, 11.7, 7.4), (6.65, 13.7, 8.6), "iron_light", "iron", "white"),
    box((9.35, 11.7, 7.4), (9.75, 13.7, 8.6), "iron_light", "iron", "white"),
    box((7.25, 11.7, 6.75), (8.75, 14.3, 7.15), "core", "core", "core_light"),
    box((7.0, 3.4, 6.75), (9.0, 3.9, 7.1), "iron_light", "iron", "white"),
    box((7.0, 6.1, 6.75), (9.0, 6.6, 7.1), "iron_light", "iron", "white"),
    box((7.0, 8.8, 6.75), (9.0, 9.3, 7.1), "iron_light", "iron", "white"),
    box((6.05, 11.45, 6.55), (7.25, 12.0, 6.9), "echo", "echo_dark", "echo_light"),
    box((8.75, 11.45, 6.55), (9.95, 12.0, 6.9), "echo", "echo_dark", "echo_light"),
    box((7.2, 15.2, 7.0), (8.8, 15.5, 7.25), "gold_light", "gold", "white"),
]

RESONATOR = [
    box((2, 6.2, 5.6), (12.5, 10.4, 10.4), "black", "void", "iron_dark"),
    box((3.3, 6.6, 5.35), (10.9, 10.1, 5.6), "iron", "iron_dark", "iron_light"),
    box((3.3, 6.6, 10.4), (10.9, 10.1, 10.65), "iron", "iron_dark", "iron_light"),
    box((1, 6.6, 6), (3.3, 9.8, 10), "leather", "leather", "leather_light"),
    box((3.1, 6.8, 5.1), (4.1, 9.9, 10.9), "gold", "iron_dark", "gold_light"),
    box((5.2, 2, 6.5), (7.5, 7.2, 9.5), "leather", "leather", "leather_light"),
    box((5.1, 1.4, 6.2), (7.8, 2.6, 9.8), "iron_dark", "void", "iron"),
    box((6.9, 5.1, 6.4), (8, 6.9, 9.6), "gold", "iron_dark", "gold_light"),
    box((7.3, 5.5, 7.1), (8.1, 6.6, 8.9), "black", "void", "iron_dark"),
    box((7.9, 7.3, 5), (10.4, 9.4, 5.35), "echo", "echo_dark", "echo_light"),
    box((8.4, 7.8, 4.78), (9.9, 8.9, 5), "core_light", "core", "white"),
    box((7.9, 7.3, 10.65), (10.4, 9.4, 11), "echo", "echo_dark", "echo_light"),
    box((11.4, 6.8, 6.2), (14.2, 9.8, 9.8), "echo_dark", "void", "echo"),
    box((13.5, 6.1, 5.6), (15.3, 10.5, 10.4), "iron", "iron_dark", "iron_light"),
    box((15.3, 6.1, 5.6), (15.95, 6.85, 10.4), "void", "iron_dark", "iron_light"),
    box((15.3, 9.75, 5.6), (15.95, 10.5, 10.4), "void", "iron_dark", "iron_light"),
    box((15.3, 6.85, 5.6), (15.95, 9.75, 6.4), "void", "iron_dark", "iron_light"),
    box((15.3, 6.85, 9.6), (15.95, 9.75, 10.4), "void", "iron_dark", "iron_light"),
    box((15.35, 6.85, 6.4), (15.7, 9.75, 9.6), "black", "void", "black"),
    box((15.7, 7.3, 6.9), (15.85, 9.3, 9.1), "core", "core_light", "core_light"),
    box((13.6, 6.45, 5.25), (15.6, 10.1, 5.6), "echo_light", "echo", "white"),
    box((14.1, 7.15, 5.02), (15.4, 9.4, 5.25), "core", "core_light", "white"),
    box((13.7, 10.5, 6.4), (15.4, 10.9, 9.6), "echo_light", "echo", "white"),
    box((4.5, 10.4, 6.8), (7.2, 11.2, 9.2), "gold", "iron_dark", "gold_light"),
    box((5.6, 3.1, 6.1), (7.15, 3.65, 9.9), "gold", "iron_dark", "gold_light"),
    box((5.6, 4.6, 6.1), (7.15, 5.15, 9.9), "gold", "iron_dark", "gold_light"),
    box((11.75, 6.5, 5.65), (12.35, 10.1, 10.35), "gold", "iron_dark", "gold_light"),
    box((13.15, 6.35, 5.5), (13.75, 10.25, 10.5), "gold", "iron_dark", "gold_light"),
    box((6.4, 7.3, 5.05), (7.4, 9.45, 5.35), "core", "core", "core_light"),
    box((5.0, 10.9, 7.1), (6.7, 12.0, 8.9), "iron_dark", "void", "iron_light"),
    box((9.0, 8.0, 10.8), (10.2, 8.8, 11.15), "core_light", "core", "white"),
]

COMMON_DISPLAY = {
    "ground": {"translation": [0, 3, 0], "scale": [0.48, 0.48, 0.48]},
    "fixed": {"rotation": [0, 180, 0], "scale": [0.8, 0.8, 0.8]},
}

# Each silhouette has a different long axis. Shared hand rotations made the blade
# edge-on and pointed the Resonator's barrel out of frame.
DISPLAYS = {
    "echo_blade": {
        "thirdperson_righthand": {"rotation": [0, -25, 35], "translation": [0, 1, -2.5], "scale": [0.95, 0.95, 0.95]},
        "thirdperson_lefthand": {"rotation": [0, 25, -35], "translation": [0, 1, -2.5], "scale": [0.95, 0.95, 0.95]},
        "firstperson_righthand": {"rotation": [0, -22, 38], "translation": [0.5, 1.0, 0.0], "scale": [0.78, 0.78, 0.78]},
        "firstperson_lefthand": {"rotation": [0, 22, -38], "translation": [0.5, 1.0, 0.0], "scale": [0.78, 0.78, 0.78]},
        "gui": {"rotation": [25, -25, 42], "scale": [0.92, 0.92, 0.92]},
    },
    "signal_lance": {
        "thirdperson_righthand": {"rotation": [0, -25, 25], "translation": [0, 1, -2.5], "scale": [1.0, 1.0, 1.0]},
        "thirdperson_lefthand": {"rotation": [0, 25, -25], "translation": [0, 1, -2.5], "scale": [1.0, 1.0, 1.0]},
        "firstperson_righthand": {"rotation": [-12, -30, 28], "translation": [0.5, 1.0, 0.0], "scale": [0.96, 0.96, 0.96]},
        "firstperson_lefthand": {"rotation": [-12, 30, -28], "translation": [0.5, 1.0, 0.0], "scale": [0.96, 0.96, 0.96]},
        "gui": {"rotation": [25, -25, 42], "scale": [0.92, 0.92, 0.92]},
    },
    "resonator": {
        "thirdperson_righthand": {"rotation": [0, 145, 15], "translation": [0, 1, -2.5], "scale": [0.85, 0.85, 0.85]},
        "thirdperson_lefthand": {"rotation": [0, -145, -15], "translation": [0, 1, -2.5], "scale": [0.85, 0.85, 0.85]},
        "firstperson_righthand": {"rotation": [0, 120, 42], "translation": [-5.3, 4.4, 0.0], "scale": [0.78, 0.78, 0.78]},
        "firstperson_lefthand": {"rotation": [0, -120, -42], "translation": [5.3, 4.4, 0.0], "scale": [0.78, 0.78, 0.78]},
        "gui": {"rotation": [25, 145, 0], "scale": [0.9, 0.9, 0.9]},
    },
}

for name, elements in (("echo_blade", SWORD), ("signal_lance", LANCE), ("resonator", RESONATOR)):
    write_atlas(name)
    model = {
        "gui_light": "front",
        "textures": {"atlas": f"hollow_signal:item/{name}_3d", "particle": f"hollow_signal:item/{name}_3d"},
        "elements": elements,
        "display": {**COMMON_DISPLAY, **DISPLAYS[name]},
    }
    (MODELS / f"{name}.json").write_text(json.dumps(model, indent=2) + "\n", encoding="utf-8")
