"""Generates the JSON resources that are pure boilerplate: models, blockstates, recipes, loot tables, advancements."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1] / 'src/main/resources'
ASSETS = ROOT / 'assets/hollow_signal'
DATA = ROOT / 'data/hollow_signal'
MOBS = ['signal_stalker', 'hollow_watcher', 'dread_moth', 'null_creeper', 'hollow_herald']


def write(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')


def generated(name):
    return {"parent": "minecraft:item/generated", "textures": {"layer0": f"hollow_signal:item/{name}"}}


for item in ['echo_shard', 'echo_heart', 'echo_totem', 'signal_finder', 'ward_charm']:
    write(ASSETS / f'models/item/{item}.json', generated(item))

# The three weapon models are authored by make_weapon_models.py; leave them intact.

for mob in MOBS:
    write(ASSETS / f'models/item/{mob}_spawn_egg.json', {"parent": "minecraft:item/template_spawn_egg"})

write(ASSETS / 'blockstates/ward_beacon.json', {"variants": {
    "lit=false": {"model": "hollow_signal:block/ward_beacon"},
    "lit=true": {"model": "hollow_signal:block/ward_beacon_lit"}}})
write(ASSETS / 'models/block/ward_beacon.json', {"parent": "minecraft:block/cube_all", "textures": {"all": "hollow_signal:block/ward_beacon"}})
write(ASSETS / 'models/block/ward_beacon_lit.json', {"parent": "minecraft:block/cube_all", "textures": {"all": "hollow_signal:block/ward_beacon_lit"}})
write(ASSETS / 'models/item/ward_beacon.json', {"parent": "hollow_signal:block/ward_beacon_lit"})
write(ASSETS / 'blockstates/echo_block.json', {"variants": {"": {"model": "hollow_signal:block/echo_block"}}})
write(ASSETS / 'models/block/echo_block.json', {"parent": "minecraft:block/cube_all", "textures": {"all": "hollow_signal:block/echo_block"}})
write(ASSETS / 'models/item/echo_block.json', {"parent": "hollow_signal:block/echo_block"})

for block in ['ward_beacon', 'echo_block']:
    write(DATA / f'loot_table/blocks/{block}.json', {
        "type": "minecraft:block",
        "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"hollow_signal:{block}"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

write(DATA / 'recipe/signal_finder.json', {
    "type": "minecraft:crafting_shaped",
    "category": "equipment",
    "pattern": [" a ", "aci", " r "],
    "key": {"a": {"item": "minecraft:amethyst_shard"}, "c": {"item": "minecraft:compass"},
            "i": {"item": "minecraft:iron_ingot"}, "r": {"item": "minecraft:redstone"}},
    "result": {"id": "hollow_signal:signal_finder", "count": 1}})

write(DATA / 'recipe/ward_charm.json', {
    "type": "minecraft:crafting_shaped",
    "category": "equipment",
    "pattern": ["gsg", "geg"],
    "key": {"g": {"item": "minecraft:gold_nugget"}, "e": {"item": "hollow_signal:echo_shard"},
            "s": {"item": "minecraft:string"}},
    "result": {"id": "hollow_signal:ward_charm", "count": 2}})

write(DATA / 'recipe/ward_beacon.json', {
    "type": "minecraft:crafting_shaped",
    "category": "building",
    "pattern": ["aea", "gig", "iii"],
    "key": {"a": {"item": "minecraft:amethyst_shard"}, "e": {"item": "hollow_signal:echo_shard"},
            "g": {"item": "minecraft:glass"}, "i": {"item": "minecraft:iron_ingot"}},
    "result": {"id": "hollow_signal:ward_beacon", "count": 1}})

write(DATA / 'recipe/echo_block.json', {
    "type": "minecraft:crafting_shaped",
    "category": "building",
    "pattern": ["eee", "eee", "eee"],
    "key": {"e": {"item": "hollow_signal:echo_shard"}},
    "result": {"id": "hollow_signal:echo_block", "count": 1}})

write(DATA / 'recipe/echo_shard_from_block.json', {
    "type": "minecraft:crafting_shapeless",
    "category": "misc",
    "ingredients": [{"item": "hollow_signal:echo_block"}],
    "result": {"id": "hollow_signal:echo_shard", "count": 9}})

write(DATA / 'recipe/echo_totem.json', {
    "type": "minecraft:crafting_shaped",
    "category": "equipment",
    "pattern": ["geg", "ghg", "geg"],
    "key": {"g": {"item": "minecraft:gold_ingot"}, "e": {"item": "hollow_signal:echo_shard"},
            "h": {"item": "hollow_signal:echo_heart"}},
    "result": {"id": "hollow_signal:echo_totem", "count": 1}})


write(DATA / 'recipe/echo_blade.json', {
    "type": "minecraft:crafting_shaped",
    "category": "equipment",
    "pattern": [" e ", "iei", " s "],
    "key": {"e": {"item": "hollow_signal:echo_shard"}, "i": {"item": "minecraft:iron_ingot"},
            "s": {"item": "minecraft:stick"}},
    "result": {"id": "hollow_signal:echo_blade", "count": 1}})

write(DATA / 'recipe/signal_lance.json', {
    "type": "minecraft:crafting_shaped",
    "category": "equipment",
    "pattern": ["  b", " i ", "s  "],
    "key": {"b": {"item": "hollow_signal:echo_block"}, "i": {"item": "minecraft:iron_ingot"},
            "s": {"item": "minecraft:stick"}},
    "result": {"id": "hollow_signal:signal_lance", "count": 1}})

write(DATA / 'recipe/resonator.json', {
    "type": "minecraft:crafting_shaped",
    "category": "equipment",
    "pattern": ["aba", "iri", " i "],
    "key": {"a": {"item": "minecraft:amethyst_shard"}, "b": {"item": "hollow_signal:echo_block"},
            "i": {"item": "minecraft:iron_ingot"}, "r": {"item": "minecraft:redstone"}},
    "result": {"id": "hollow_signal:resonator", "count": 1}})

RECIPE_GROUPS = {
    'signal_finder': 'tools', 'ward_charm': 'misc', 'ward_beacon': 'decorations',
    'echo_block': 'building', 'echo_shard_from_block': 'misc', 'echo_totem': 'misc',
    'echo_blade': 'combat', 'signal_lance': 'combat', 'resonator': 'combat'}
UNLOCK = {
    'signal_finder': 'minecraft:compass', 'ward_charm': 'hollow_signal:echo_shard',
    'ward_beacon': 'hollow_signal:echo_shard', 'echo_block': 'hollow_signal:echo_shard',
    'echo_shard_from_block': 'hollow_signal:echo_block', 'echo_totem': 'hollow_signal:echo_heart',
    'echo_blade': 'hollow_signal:echo_shard', 'signal_lance': 'hollow_signal:echo_block',
    'resonator': 'hollow_signal:echo_block'}

for recipe, group in RECIPE_GROUPS.items():
    write(DATA / f'advancement/recipes/{group}/{recipe}.json', {
        "parent": "minecraft:recipes/root",
        "criteria": {
            "has_item": {"trigger": "minecraft:inventory_changed",
                         "conditions": {"items": [{"items": [UNLOCK[recipe]]}]}},
            "has_the_recipe": {"trigger": "minecraft:recipe_unlocked",
                               "conditions": {"recipe": f"hollow_signal:{recipe}"}}},
        "requirements": [["has_item", "has_the_recipe"]],
        "rewards": {"recipes": [f"hollow_signal:{recipe}"]}})


def advancement(name, parent, icon, frame, criteria, hidden=False):
    payload = {
        "display": {
            "icon": {"id": icon},
            "title": {"translate": f"advancement.hollow_signal.{name}"},
            "description": {"translate": f"advancement.hollow_signal.{name}.description"},
            "frame": frame,
            "show_toast": True,
            "announce_to_chat": True,
            "hidden": hidden},
        "criteria": criteria,
        "requirements": [list(criteria.keys())]}
    if parent:
        payload["parent"] = f"hollow_signal:{parent}"
    else:
        payload["display"]["background"] = "minecraft:textures/block/sculk.png"
    write(DATA / f'advancement/{name}.json', payload)


def killed(entity):
    return {"killed": {"trigger": "minecraft:player_killed_entity",
                       "conditions": {"entity": [{"condition": "minecraft:entity_properties", "entity": "this",
                                                  "predicate": {"type": f"hollow_signal:{entity}"}}]}}}


def has(item):
    return {"has_item": {"trigger": "minecraft:inventory_changed",
                         "conditions": {"items": [{"items": [f"hollow_signal:{item}"]}]}}}


advancement('root', None, 'hollow_signal:echo_shard', 'task', has('echo_shard'))
advancement('signal_finder', 'root', 'hollow_signal:signal_finder', 'task', has('signal_finder'))
advancement('ward_beacon', 'signal_finder', 'hollow_signal:ward_beacon', 'task', has('ward_beacon'))
advancement('echo_block', 'ward_beacon', 'hollow_signal:echo_block', 'task', has('echo_block'))
advancement('echo_blade', 'root', 'hollow_signal:echo_blade', 'task', has('echo_blade'))
advancement('signal_lance', 'echo_blade', 'hollow_signal:signal_lance', 'task', has('signal_lance'))
advancement('resonator', 'signal_lance', 'hollow_signal:resonator', 'goal', has('resonator'))
advancement('kill_watcher', 'root', 'hollow_signal:hollow_watcher_spawn_egg', 'task', killed('hollow_watcher'))
advancement('kill_stalker', 'kill_watcher', 'hollow_signal:signal_stalker_spawn_egg', 'goal', killed('signal_stalker'))
advancement('kill_herald', 'kill_stalker', 'hollow_signal:echo_heart', 'challenge', killed('hollow_herald'))
advancement('echo_totem', 'kill_herald', 'hollow_signal:echo_totem', 'goal', has('echo_totem'))

print('resources written')
