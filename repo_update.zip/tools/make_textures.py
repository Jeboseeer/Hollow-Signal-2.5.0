from pathlib import Path
import struct, zlib

ROOT = Path(__file__).resolve().parents[1] / 'src/main/resources/assets/hollow_signal/textures/item'
ROOT.mkdir(parents=True, exist_ok=True)

def png(name, grid, palette):
    pixels = b''.join(b'\x00' + b''.join(bytes(palette.get(ch, (0,0,0,0))) for ch in row.ljust(16)[:16]) for row in grid)
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data))
    data = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 16,16,8,6,0,0,0)) + chunk(b'IDAT', zlib.compress(pixels, 9)) + chunk(b'IEND', b'')
    (ROOT / f'{name}.png').write_bytes(data)

common = {' ': (0,0,0,0), 'o':(21,17,34,255), 'd':(52,40,78,255), 'p':(112,65,162,255), 'v':(178,112,239,255), 'w':(236,204,255,255), 'c':(83,211,238,255), 'b':(25,107,170,255), 'g':(224,181,73,255), 'y':(255,231,141,255)}
png('echo_shard', [
'                ','       w        ','      wvw       ','     wvpvw      ','     vpdpv      ','    vpdddpv     ','    vpdddpv     ','   wvpdddpvw    ','    vpdddpv     ','     vpdpv      ','     wvpvw      ','      wvw       ','       v        ','                ','                ','                '
], common)
png('signal_finder', [
'                ','     oooooo     ','   oo dddd oo   ','  o dggggd  o  ',' o dgccccgd  o ',' o dgcbwbgd  o ',' o dgcbwbgd  o ',' o dgccccgd  o ',' o dggggggd  o ',' o dddddddd  o ','  o        oo  ','   oooooooo    ','     oooo       ','                ','                ','                '
], common)
png('ward_charm', [
'                ','       gg       ','      gyyg      ','    gggyyggg    ','   gyygddgyyg   ','  gyygdpdg yyg  '.replace(' ',''),'  gy gdpdg yg   '.replace(' ',''),'   gyygddgyyg   ','    gggyyggg    ','      gyyg      ','       gg       ','                ','                ','                ','                ','                '
], common)

def write_rgba(path, width, height, pixels):
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = b''.join(b'\x00' + b''.join(bytes(pixels[y][x]) for x in range(width)) for y in range(height))
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data))
    path.write_bytes(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width,height,8,6,0,0,0)) + chunk(b'IDAT', zlib.compress(raw,9)) + chunk(b'IEND', b''))

def canvas(width, height, color): return [[color for _ in range(width)] for _ in range(height)]
def rect(p, x0,y0,x1,y1,c):
    for y in range(max(0,y0),min(len(p),y1)):
        for x in range(max(0,x0),min(len(p[0]),x1)): p[y][x]=c

# Zombie UV: front face of the head is x=8..15, y=8..15; front torso x=20..27, y=20..31.
stalker = canvas(64,64,(19,17,31,255))
for y in range(64):
    for x in range(64):
        if (x*11+y*17)%19 < 3: stalker[y][x]=(32,28,49,255)
rect(stalker,8,8,16,16,(29,27,42,255))
rect(stalker,9,10,11,12,(86,229,237,255)); rect(stalker,13,10,15,12,(86,229,237,255))
rect(stalker,10,13,14,14,(8,10,17,255))
rect(stalker,20,20,28,32,(28,26,43,255))
rect(stalker,23,21,25,30,(87,215,224,255)); rect(stalker,21,24,27,26,(72,172,194,255))
rect(stalker,21,29,27,30,(43,94,112,255))
write_rgba(ROOT.parent/'entity/signal_stalker.png',64,64,stalker)

# Spider geometry uses most of the upper 32 rows. Its body is violet with a luminous eye cluster.
watcher = canvas(64,32,(31,20,43,255))
for y in range(32):
    for x in range(64):
        if (x*7+y*13)%11 < 2: watcher[y][x]=(54,32,67,255)
        if (x+y)%23 == 0: watcher[y][x]=(81,47,101,255)
for x in range(32,48): rect(watcher,x,8,x+1,9,(89,58,115,255))
rect(watcher,32,4,48,6,(53,30,72,255))
for x in (35,39,43): rect(watcher,x,11,x+2,13,(235,104,247,255))
for x in (36,42): rect(watcher,x,15,x+1,17,(159,77,199,255))
write_rgba(ROOT.parent/'entity/hollow_watcher.png',64,32,watcher)

beacon = canvas(16,16,(31,26,48,255))
rect(beacon,1,1,15,15,(57,43,75,255)); rect(beacon,3,3,13,13,(18,67,85,255))
rect(beacon,5,5,11,11,(77,220,226,255)); rect(beacon,7,3,9,13,(180,247,245,255))
rect(beacon,3,7,13,9,(180,247,245,255)); rect(beacon,7,7,9,9,(255,255,222,255))
write_rgba(ROOT.parent/'block/ward_beacon.png',16,16,beacon)

# V2 entity UV sheets for the custom 3D models. Each colored region corresponds
# to a deliberate model cuboid, so face details do not depend on the vanilla UV map.
def stone_sheet(w,h,base,mid,lit):
    p=canvas(w,h,base)
    for y in range(h):
        for x in range(w):
            v=(x*37+y*59+(x*y)%17)%41
            if v<5: p[y][x]=mid
            elif v==13: p[y][x]=lit
    return p

stalker = stone_sheet(128,128,(42,49,66,255),(58,68,88,255),(83,98,119,255))
# Mask and hood: pale ridges frame a black face, with separate luminous eye geometry.
rect(stalker,0,0,32,16,(21,27,39,255))
rect(stalker,32,0,72,20,(28,35,49,255))
rect(stalker,42,10,52,11,(61,75,89,255))
rect(stalker,42,11,43,19,(60,72,87,255)); rect(stalker,51,11,52,19,(60,72,87,255))
rect(stalker,43,12,51,18,(12,17,28,255))
rect(stalker,45,17,49,18,(79,105,116,255))
# Eyes, mouth slit, antenna rods and silver transmitter tips.
rect(stalker,80,0,88,6,(66,224,232,255))
rect(stalker,81,1,87,4,(174,255,247,255))
rect(stalker,88,0,96,4,(4,10,20,255))
rect(stalker,96,0,104,9,(81,92,110,255))
rect(stalker,108,0,126,8,(124,158,169,255))
rect(stalker,112,2,120,5,(198,247,243,255))
# Layered coat, shoulder plates, separated cyan core, and mechanical ribs.
rect(stalker,0,32,24,48,(63,76,98,255))
rect(stalker,2,34,10,46,(70,86,110,255))
for y in (36,39,42): rect(stalker,3,y,9,y+1,(91,123,139,255))
rect(stalker,32,32,72,44,(59,67,83,255))
rect(stalker,40,35,64,37,(100,119,135,255))
rect(stalker,80,20,88,28,(69,202,215,255))
rect(stalker,82,22,86,26,(190,255,246,255))
rect(stalker,88,20,106,26,(75,131,153,255))
rect(stalker,96,20,116,34,(91,100,116,255))
# Sleeves, boots and back tendrils carry their own rough metal treatment.
rect(stalker,0,64,30,86,(52,64,84,255))
for y in (70,77,83): rect(stalker,0,y,30,y+1,(66,81,103,255))
rect(stalker,32,64,66,84,(55,68,88,255))
rect(stalker,48,76,66,84,(78,92,109,255))
rect(stalker,72,64,86,88,(45,68,82,255))
for y in range(66,87,4): rect(stalker,78,y,80,y+2,(100,195,199,255))
write_rgba(ROOT.parent/'entity/signal_stalker.png',128,128,stalker)

watcher = stone_sheet(128,96,(63,39,77,255),(84,53,102,255),(115,73,135,255))
rect(watcher,0,0,30,16,(58,38,70,255))
rect(watcher,5,5,13,12,(55,32,68,255))
rect(watcher,32,0,74,20,(48,31,61,255))
for x in (38,45,52,59,66): rect(watcher,x,4,x+2,14,(94,60,113,255))
rect(watcher,80,0,102,10,(105,72,133,255))
rect(watcher,104,0,112,6,(228,81,247,255))
rect(watcher,105,1,111,4,(255,180,255,255))
rect(watcher,112,0,124,8,(146,97,175,255))
rect(watcher,0,32,50,52,(69,43,82,255))
for y in (35,39,43,47): rect(watcher,5,y,43,y+1,(92,54,114,255))
rect(watcher,52,32,84,44,(131,77,151,255))
rect(watcher,59,34,77,39,(160,93,179,255))
rect(watcher,0,64,30,72,(50,32,64,255))
rect(watcher,0,67,30,69,(97,59,119,255))
rect(watcher,32,64,48,73,(136,80,160,255))
rect(watcher,48,64,72,78,(72,47,91,255))
rect(watcher,60,70,72,78,(155,95,177,255))
write_rgba(ROOT.parent/'entity/hollow_watcher.png',128,96,watcher)

transparent=(0,0,0,0)
stalker_glow=canvas(128,128,transparent)
rect(stalker_glow,80,0,88,6,(105,247,246,255))
rect(stalker_glow,80,20,88,28,(60,213,237,200))
rect(stalker_glow,112,2,120,5,(190,255,245,200))
write_rgba(ROOT.parent/'entity/signal_stalker_glow.png',128,128,stalker_glow)
watcher_glow=canvas(128,96,transparent)
rect(watcher_glow,104,0,112,6,(255,115,255,255))
write_rgba(ROOT.parent/'entity/hollow_watcher_glow.png',128,96,watcher_glow)

# --- Version 2.0 content: new items, blocks, mobs and the mod icon. ---
ITEMS = ROOT
BLOCKS = ROOT.parent / 'block'
ENTITY = ROOT.parent / 'entity'

def noise_sheet(w, h, base, mid, lit, seed=1):
    p = canvas(w, h, base)
    for y in range(h):
        for x in range(w):
            v = (x * 31 + y * 57 + seed * 13 + (x * y) % 19) % 43
            if v < 6: p[y][x] = mid
            elif v == 17: p[y][x] = lit
    return p

# Echo Heart: a boss trophy with a bright violet core.
heart = canvas(16, 16, (0, 0, 0, 0))
rect(heart, 4, 3, 12, 5, (62, 32, 92, 255)); rect(heart, 3, 4, 13, 11, (88, 44, 128, 255))
rect(heart, 5, 11, 11, 13, (62, 32, 92, 255)); rect(heart, 7, 13, 9, 14, (46, 24, 70, 255))
rect(heart, 5, 5, 11, 10, (168, 92, 232, 255)); rect(heart, 6, 6, 10, 9, (226, 168, 255, 255))
rect(heart, 7, 4, 9, 12, (255, 236, 255, 255)); rect(heart, 4, 7, 12, 8, (255, 236, 255, 255))
write_rgba(ITEMS / 'echo_heart.png', 16, 16, heart)

# Echo Totem: gold frame around an echo core, read as a second-chance charm.
totem = canvas(16, 16, (0, 0, 0, 0))
rect(totem, 5, 1, 11, 4, (214, 170, 66, 255)); rect(totem, 4, 4, 12, 12, (226, 186, 84, 255))
rect(totem, 6, 12, 10, 15, (190, 146, 56, 255)); rect(totem, 6, 3, 10, 10, (52, 30, 78, 255))
rect(totem, 7, 4, 9, 9, (176, 104, 240, 255)); rect(totem, 7, 5, 9, 7, (238, 196, 255, 255))
rect(totem, 4, 6, 5, 9, (255, 226, 132, 255)); rect(totem, 11, 6, 12, 9, (255, 226, 132, 255))
write_rgba(ITEMS / 'echo_totem.png', 16, 16, totem)

# Echo Block: compressed shards, used to amplify a Ward Beacon.
echo_block = noise_sheet(16, 16, (46, 28, 66, 255), (58, 36, 84, 255), (92, 58, 126, 255), seed=4)
rect(echo_block, 0, 0, 16, 1, (32, 20, 48, 255)); rect(echo_block, 0, 15, 16, 16, (32, 20, 48, 255))
rect(echo_block, 0, 0, 1, 16, (32, 20, 48, 255)); rect(echo_block, 15, 0, 16, 16, (32, 20, 48, 255))
rect(echo_block, 3, 3, 7, 10, (150, 92, 214, 255)); rect(echo_block, 4, 4, 6, 9, (214, 168, 255, 255))
rect(echo_block, 8, 6, 12, 13, (134, 80, 198, 255)); rect(echo_block, 9, 7, 11, 12, (204, 154, 252, 255))
rect(echo_block, 9, 2, 12, 5, (118, 70, 176, 255))
write_rgba(BLOCKS / 'echo_block.png', 16, 16, echo_block)

# Lit Ward Beacon: the fueled state of the same block.
beacon_lit = canvas(16, 16, (36, 30, 56, 255))
rect(beacon_lit, 1, 1, 15, 15, (68, 52, 92, 255)); rect(beacon_lit, 3, 3, 13, 13, (24, 92, 116, 255))
rect(beacon_lit, 5, 5, 11, 11, (122, 243, 247, 255)); rect(beacon_lit, 7, 3, 9, 13, (214, 255, 253, 255))
rect(beacon_lit, 3, 7, 13, 9, (214, 255, 253, 255)); rect(beacon_lit, 6, 6, 10, 10, (255, 255, 236, 255))
write_rgba(BLOCKS / 'ward_beacon_lit.png', 16, 16, beacon_lit)

# Dread Moth: sheet laid out for DreadMothModel (body, head, antennae, tail, two wing segments).
moth = noise_sheet(64, 64, (37, 47, 63, 255), (52, 69, 86, 255), (76, 102, 119, 255), seed=7)
rect(moth, 0, 0, 30, 13, (28, 38, 54, 255))            # thorax
for y in range(2, 12, 3): rect(moth, 1, y, 29, y + 1, (54, 112, 118, 255))
rect(moth, 0, 14, 20, 20, (33, 46, 62, 255))           # thorax collar
rect(moth, 30, 0, 48, 8, (24, 34, 48, 255))            # head
rect(moth, 32, 1, 36, 4, (120, 246, 222, 255))         # eye patch
rect(moth, 41, 1, 45, 4, (120, 246, 222, 255))
rect(moth, 30, 9, 34, 12, (186, 255, 240, 255))        # proboscis
rect(moth, 48, 0, 52, 7, (78, 190, 176, 255))          # antennae rods
rect(moth, 0, 22, 38, 32, (24, 33, 47, 255))           # tail
for y in range(23, 31, 2): rect(moth, 2, y, 36, y + 1, (62, 126, 128, 255))
rect(moth, 40, 22, 44, 28, (36, 50, 64, 255))          # legs
rect(moth, 0, 34, 46, 44, (47, 66, 83, 255))           # inner wings
for x in range(2, 44, 5): rect(moth, x, 35, x + 2, 43, (70, 150, 150, 255))
rect(moth, 0, 36, 46, 37, (150, 230, 220, 255))
rect(moth, 0, 46, 36, 56, (26, 36, 52, 255))           # wing tips
for x in range(1, 34, 4): rect(moth, x, 47, x + 2, 55, (58, 128, 134, 255))
rect(moth, 0, 50, 36, 51, (126, 214, 206, 255))
write_rgba(ENTITY / 'dread_moth.png', 64, 64, moth)

moth_glow = canvas(64, 64, (0, 0, 0, 0))
rect(moth_glow, 32, 1, 36, 4, (168, 255, 240, 255))
rect(moth_glow, 41, 1, 45, 4, (168, 255, 240, 255))
rect(moth_glow, 30, 9, 34, 12, (206, 255, 248, 220))
rect(moth_glow, 48, 0, 52, 2, (150, 255, 232, 220))
write_rgba(ENTITY / 'dread_moth_glow.png', 64, 64, moth_glow)

# Null Creeper: sheet laid out for NullCreeperModel (head, crest, vent, body, core, four legs).
null_creeper = noise_sheet(64, 64, (32, 50, 58, 255), (48, 73, 80, 255), (73, 105, 109, 255), seed=11)
rect(null_creeper, 0, 0, 32, 16, (20, 34, 42, 255))    # head
rect(null_creeper, 8, 3, 14, 7, (10, 18, 24, 255))     # hollow face
rect(null_creeper, 18, 3, 24, 7, (10, 18, 24, 255))
rect(null_creeper, 32, 0, 59, 12, (26, 44, 52, 255))   # crest
for x in range(33, 58, 5): rect(null_creeper, x, 1, x + 2, 11, (72, 182, 166, 255))
rect(null_creeper, 0, 18, 8, 22, (104, 244, 212, 255)) # eye geometry
rect(null_creeper, 10, 18, 18, 21, (8, 14, 18, 255))   # mouth slit
rect(null_creeper, 40, 14, 50, 22, (58, 150, 142, 255))# vent
rect(null_creeper, 0, 28, 24, 44, (39, 61, 70, 255))   # body
for y in range(30, 43, 4): rect(null_creeper, 1, y, 23, y + 1, (66, 168, 154, 255))
rect(null_creeper, 28, 28, 44, 40, (24, 40, 48, 255))  # chest plate
rect(null_creeper, 30, 30, 42, 32, (84, 198, 180, 255))
rect(null_creeper, 0, 46, 24, 58, (118, 252, 222, 255))# core
rect(null_creeper, 2, 48, 22, 56, (212, 255, 246, 255))
rect(null_creeper, 44, 28, 60, 40, (18, 30, 38, 255))  # legs
rect(null_creeper, 44, 40, 60, 46, (28, 48, 56, 255))  # feet
write_rgba(ENTITY / 'null_creeper.png', 64, 64, null_creeper)

null_creeper_glow = canvas(64, 64, (0, 0, 0, 0))
rect(null_creeper_glow, 0, 18, 8, 22, (150, 255, 230, 255))
rect(null_creeper_glow, 0, 46, 24, 58, (160, 255, 236, 230))
rect(null_creeper_glow, 40, 14, 50, 22, (110, 230, 210, 180))
write_rgba(ENTITY / 'null_creeper_glow.png', 64, 64, null_creeper_glow)

# Echo weapons.
blade = canvas(16, 16, (0, 0, 0, 0))
rect(blade, 3, 11, 7, 15, (66, 44, 30, 255))           # grip
rect(blade, 4, 12, 6, 15, (96, 66, 42, 255))
rect(blade, 2, 9, 9, 11, (214, 178, 86, 255))          # guard
rect(blade, 3, 10, 8, 11, (255, 226, 140, 255))
for i in range(8):
    y = 9 - i
    rect(blade, 5 + i // 2, y - 1, 9 + i // 2, y, (122, 76, 178, 255))
    rect(blade, 6 + i // 2, y - 1, 8 + i // 2, y, (206, 158, 255, 255))
rect(blade, 12, 0, 14, 2, (248, 228, 255, 255))        # tip
write_rgba(ITEMS / 'echo_blade.png', 16, 16, blade)

lance = canvas(16, 16, (0, 0, 0, 0))
for i in range(12):
    rect(lance, 2 + i, 13 - i, 5 + i, 15 - i, (74, 60, 92, 255))
    rect(lance, 3 + i, 13 - i, 4 + i, 14 - i, (126, 108, 156, 255))
rect(lance, 10, 1, 15, 6, (96, 60, 150, 255))          # head
rect(lance, 11, 2, 14, 5, (186, 142, 248, 255))
rect(lance, 12, 0, 16, 3, (240, 220, 255, 255))
rect(lance, 8, 6, 12, 9, (210, 172, 96, 255))          # collar
rect(lance, 1, 13, 4, 16, (58, 42, 34, 255))           # butt cap
write_rgba(ITEMS / 'signal_lance.png', 16, 16, lance)

resonator = canvas(16, 16, (0, 0, 0, 0))
rect(resonator, 2, 6, 12, 11, (44, 38, 60, 255))       # body
rect(resonator, 3, 7, 11, 10, (72, 62, 96, 255))
rect(resonator, 10, 4, 15, 13, (58, 48, 78, 255))      # emitter bell
rect(resonator, 11, 5, 14, 12, (126, 92, 190, 255))
rect(resonator, 12, 6, 15, 11, (214, 178, 255, 255))
rect(resonator, 4, 8, 8, 9, (236, 208, 255, 255))      # core line
rect(resonator, 1, 9, 5, 14, (206, 166, 82, 255))      # grip
rect(resonator, 2, 10, 4, 13, (250, 222, 142, 255))
write_rgba(ITEMS / 'resonator.png', 16, 16, resonator)

# Hollow Herald: the boss sheet follows the cuboids of HollowHeraldModel.
herald = noise_sheet(128, 128, (44, 31, 62, 255), (65, 45, 87, 255), (94, 64, 126, 255), seed=5)
rect(herald, 0, 0, 40, 20, (30, 22, 44, 255))          # skull
rect(herald, 10, 4, 30, 16, (16, 12, 26, 255))
rect(herald, 12, 6, 18, 9, (198, 120, 255, 255)); rect(herald, 22, 6, 28, 9, (198, 120, 255, 255))
rect(herald, 14, 12, 26, 14, (120, 70, 168, 255))
rect(herald, 40, 0, 76, 16, (58, 40, 84, 255))         # crown band
for x in range(42, 74, 6): rect(herald, x, 2, x + 3, 12, (154, 104, 206, 255))
rect(herald, 0, 20, 10, 24, (226, 174, 255, 255))      # eye geometry
rect(herald, 10, 20, 20, 24, (160, 96, 214, 255))
rect(herald, 80, 0, 96, 24, (72, 52, 102, 255))        # horns
for y in range(2, 22, 4): rect(herald, 82, y, 94, y + 2, (134, 96, 178, 255))
rect(herald, 0, 40, 56, 80, (61, 42, 82, 255))         # torso
rect(herald, 6, 46, 50, 48, (118, 74, 166, 255))
rect(herald, 6, 56, 50, 58, (118, 74, 166, 255))
rect(herald, 18, 62, 38, 74, (176, 108, 240, 255))
rect(herald, 22, 64, 34, 72, (236, 196, 255, 255))
rect(herald, 60, 40, 110, 56, (77, 52, 104, 255))       # shoulder mantle
rect(herald, 60, 56, 108, 100, (48, 33, 67, 255))      # cloak
for y in range(60, 98, 6): rect(herald, 62, y, 106, y + 1, (74, 52, 106, 255))
rect(herald, 96, 40, 128, 68, (38, 28, 56, 255))       # arms
for y in range(42, 66, 5): rect(herald, 98, y, 126, y + 1, (96, 66, 136, 255))
rect(herald, 96, 68, 112, 76, (214, 176, 255, 255))    # claws
rect(herald, 32, 88, 72, 110, (30, 22, 46, 255))       # legs
for y in range(90, 108, 5): rect(herald, 34, y, 70, y + 1, (84, 58, 118, 255))
write_rgba(ENTITY / 'hollow_herald.png', 128, 128, herald)

herald_glow = canvas(128, 128, (0, 0, 0, 0))
rect(herald_glow, 12, 6, 18, 9, (232, 170, 255, 255)); rect(herald_glow, 22, 6, 28, 9, (232, 170, 255, 255))
rect(herald_glow, 0, 20, 10, 24, (244, 206, 255, 255))
rect(herald_glow, 18, 62, 38, 74, (206, 140, 255, 220))
rect(herald_glow, 96, 68, 112, 76, (226, 196, 255, 200))
write_rgba(ENTITY / 'hollow_herald_glow.png', 128, 128, herald_glow)

# Mod icon shown in the launcher, Mod Menu and the CurseForge project page.
icon = canvas(128, 128, (14, 10, 22, 255))
for y in range(128):
    for x in range(128):
        if (x * 13 + y * 29) % 37 < 3: icon[y][x] = (24, 17, 36, 255)
for radius, color in ((54, (34, 24, 52, 255)), (42, (52, 34, 80, 255)), (30, (86, 52, 132, 255)), (18, (150, 92, 214, 255)), (8, (236, 206, 255, 255))):
    for y in range(128):
        for x in range(128):
            dx, dy = x - 64, y - 64
            d = (dx * dx + dy * dy) ** 0.5
            if radius - 2 <= d <= radius: icon[y][x] = color
rect(icon, 60, 20, 68, 108, (118, 74, 170, 255))
rect(icon, 20, 60, 108, 68, (118, 74, 170, 255))
rect(icon, 62, 22, 66, 106, (214, 176, 255, 255))
rect(icon, 22, 62, 106, 66, (214, 176, 255, 255))
rect(icon, 56, 56, 72, 72, (18, 12, 26, 255))
rect(icon, 59, 59, 69, 69, (236, 206, 255, 255))
write_rgba(ROOT.parent.parent / 'icon.png', 128, 128, icon)

# Replace the legacy flat weapon icons with their authored voxel models.
import runpy
runpy.run_path(str(Path(__file__).with_name('make_weapon_models.py')))
