# Drives the dev client through chat commands and captures the game window.
# Usage: powershell -ExecutionPolicy Bypass -File .\tools\capture-screenshots.ps1
param([switch]$QuickWeapon, [switch]$QuickEvents, [switch]$SurvivalGallery, [switch]$SurvivalScenes, [switch]$DawnReward, [switch]$AnimationQA, [string]$RecipeId, [switch]$FinalExtras)
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$shots = Join-Path $project $(if ($AnimationQA) { 'release/screenshots-2.4.2' } elseif ($SurvivalGallery -or $SurvivalScenes) { 'release/curseforge-gallery-2.4.0' } elseif ($DawnReward) { 'release/screenshots-2.4.1' } else { 'release/screenshots-2.4.0' })
New-Item -ItemType Directory -Force $shots | Out-Null

Add-Type -AssemblyName System.Drawing
Add-Type @'
using System;
using System.Runtime.InteropServices;
public class Win {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public KEYBDINPUT ki; public int pad1; public int pad2; }
    [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr extra; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr h, int x, int y, int width, int height, bool repaint);
    [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] inputs, int size);
    [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, IntPtr extra);
    public static void Key(ushort vk, bool up) {
        INPUT[] input = new INPUT[1];
        input[0].type = 1;
        input[0].ki.wVk = vk;
        input[0].ki.dwFlags = up ? 2u : 0u;
        SendInput(1, input, Marshal.SizeOf(typeof(INPUT)));
    }
    public static void Char(char c) {
        INPUT[] input = new INPUT[2];
        input[0].type = 1; input[0].ki.wScan = c; input[0].ki.dwFlags = 4;
        input[1].type = 1; input[1].ki.wScan = c; input[1].ki.dwFlags = 4 | 2;
        SendInput(2, input, Marshal.SizeOf(typeof(INPUT)));
    }
}
'@

function Get-GameWindow {
    foreach ($try in 1..60) {
        $proc = Get-Process -Name javaw, java -ErrorAction SilentlyContinue |
            Where-Object { $_.MainWindowTitle -match 'Minecraft' } | Select-Object -First 1
        if ($proc) { return $proc }
        Start-Sleep -Seconds 5
    }
    throw 'Minecraft window never appeared.'
}

function Focus-Game($proc) {
    [Win]::ShowWindow($proc.MainWindowHandle, 9) | Out-Null
    # An Alt key press permits a background QA script to request foreground focus on Windows.
    [Win]::Key(0x12, $false); [Win]::Key(0x12, $true)
    [Win]::SetForegroundWindow($proc.MainWindowHandle) | Out-Null
    Start-Sleep -Milliseconds 200
    if ([Win]::GetForegroundWindow() -ne $proc.MainWindowHandle) {
        (New-Object -ComObject WScript.Shell).AppActivate($proc.Id) | Out-Null
        Start-Sleep -Milliseconds 200
    }
    if ([Win]::GetForegroundWindow() -ne $proc.MainWindowHandle) {
        $rect = New-Object Win+RECT
        [Win]::GetWindowRect($proc.MainWindowHandle, [ref]$rect) | Out-Null
        [Win]::SetCursorPos($rect.Left + 100, $rect.Top + 15) | Out-Null
        [Win]::mouse_event(0x0002, 0, 0, 0, [IntPtr]::Zero)
        [Win]::mouse_event(0x0004, 0, 0, 0, [IntPtr]::Zero)
        Start-Sleep -Milliseconds 250
    }
    if ([Win]::GetForegroundWindow() -ne $proc.MainWindowHandle) {
        throw 'Minecraft is not foreground; refusing to send keys.'
    }
}

function Send-Command($text) {
    Focus-Game $game

    if ($AnimationQA) {
        Send-Command '/gamemode creative'
        Send-Command '/gamerule doDaylightCycle false'
        Send-Command '/gamerule doMobSpawning false'
        Send-Command '/kill @e[type=!player]'
        Send-Command '/tp @s 95 70 -126 facing 95 70 -121'
        Send-Command '/time set 15000'
        Send-Command '/hollowsignal event red_eclipse'
        Start-Sleep -Seconds 1
        Save-Shot $game '01-compact-event-banner'
        foreach ($weapon in @('echo_blade', 'signal_lance', 'resonator')) {
            Send-Command "/item replace entity @s hotbar.0 with hollow_signal:$weapon"
            Send-Key 0x31
            Start-Sleep -Milliseconds 400
            [Win]::mouse_event(0x0008, 0, 0, 0, [IntPtr]::Zero)
            [Win]::mouse_event(0x0010, 0, 0, 0, [IntPtr]::Zero)
            Start-Sleep -Milliseconds 110
            Save-Shot $game "02-$weapon-ability"
        }
        return
    }
    [Win]::Key(0x54, $false); [Win]::Key(0x54, $true)   # T opens chat
    Start-Sleep -Milliseconds 350
    foreach ($c in $text.ToCharArray()) { [Win]::Char($c); Start-Sleep -Milliseconds 12 }
    Start-Sleep -Milliseconds 150
    [Win]::Key(0x0D, $false); [Win]::Key(0x0D, $true)   # Enter
    Start-Sleep -Milliseconds 350
}

function Send-Key($vk, $holdMs = 60) {
    [Win]::Key($vk, $false); Start-Sleep -Milliseconds $holdMs; [Win]::Key($vk, $true)
    Start-Sleep -Milliseconds 200
}

function Toggle-Hitboxes {
    [Win]::Key(0x72, $false) # F3
    Send-Key 0x42            # B
    [Win]::Key(0x72, $true)
    Start-Sleep -Seconds 2
}

function Clear-Chat {
    [Win]::Key(0x72, $false) # F3 + D clears the chat overlay
    Send-Key 0x44
    [Win]::Key(0x72, $true)
    Start-Sleep -Milliseconds 400
}

function Right-Click {
    [Win]::mouse_event(0x0008, 0, 0, 0, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 120
    [Win]::mouse_event(0x0010, 0, 0, 0, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 300
}

function Click-Client($proc, [int]$x, [int]$y, [bool]$right = $false) {
    Focus-Game $proc
    $point = New-Object Win+POINT
    $point.X = $x; $point.Y = $y
    [Win]::ClientToScreen($proc.MainWindowHandle, [ref]$point) | Out-Null
    [Win]::SetCursorPos($point.X, $point.Y) | Out-Null
    Start-Sleep -Milliseconds 180
    $down = if ($right) { 0x0008 } else { 0x0002 }
    $up = if ($right) { 0x0010 } else { 0x0004 }
    [Win]::mouse_event($down, 0, 0, 0, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 70
    [Win]::mouse_event($up, 0, 0, 0, [IntPtr]::Zero)
    Start-Sleep -Milliseconds 140
}

function Move-Client($proc, [int]$x, [int]$y) {
    $point = New-Object Win+POINT
    $point.X = $x; $point.Y = $y
    [Win]::ClientToScreen($proc.MainWindowHandle, [ref]$point) | Out-Null
    [Win]::SetCursorPos($point.X, $point.Y) | Out-Null
    Start-Sleep -Milliseconds 350
}

function Get-CraftLayout($proc) {
    $rect = New-Object Win+RECT
    [Win]::GetClientRect($proc.MainWindowHandle, [ref]$rect) | Out-Null
    $width = $rect.Right - $rect.Left
    $height = $rect.Bottom - $rect.Top
    $scale = [Math]::Max(1, [Math]::Floor([Math]::Min($width / 320.0, $height / 240.0)))
    return @{ left = [int](($width - 176 * $scale) / 2); top = [int](($height - 166 * $scale) / 2); scale = [int]$scale }
}

function Stage-Recipe($proc, $id) {
    Send-Command '/clear @s'
    $recipe = Get-Content (Join-Path $project "src/main/resources/data/hollow_signal/recipe/$id.json") -Raw | ConvertFrom-Json
    $letters = @($recipe.key.PSObject.Properties.Name | Sort-Object)
    for ($slot = 0; $slot -lt $letters.Count; $slot++) {
        $ingredient = $recipe.key.($letters[$slot]).item
        $count = if ($ingredient -eq 'hollow_signal:echo_heart') { 1 } else { 64 }
        Send-Command "/item replace entity @s hotbar.$slot with $ingredient $count"
    }
    Click-Client $proc 430 240 $true # gameplay uses the central crosshair
    Start-Sleep -Milliseconds 650
    $layout = Get-CraftLayout $proc
    for ($slot = 0; $slot -lt $letters.Count; $slot++) {
        $letter = $letters[$slot]
        $hotX = $layout.left + (8 + 9 + 18 * $slot) * $layout.scale
        $hotY = $layout.top + (142 + 9) * $layout.scale
        Click-Client $proc $hotX $hotY
        for ($row = 0; $row -lt 3; $row++) {
            if ($row -ge $recipe.pattern.Count) { continue }
            for ($col = 0; $col -lt 3; $col++) {
                if ($recipe.pattern[$row][$col] -ne $letter) { continue }
                $gridX = $layout.left + (30 + 9 + 18 * $col) * $layout.scale
                $gridY = $layout.top + (17 + 9 + 18 * $row) * $layout.scale
                Click-Client $proc $gridX $gridY $true
            }
        }
        Click-Client $proc $hotX $hotY
    }
    Move-Client $proc 700 220
    Start-Sleep -Milliseconds 500
    Save-Shot $proc "craft-$id"
    Send-Key 0x1B
    Start-Sleep -Milliseconds 400
}

function Save-Shot($proc, $name) {
    $rect = New-Object Win+RECT
    [Win]::GetClientRect($proc.MainWindowHandle, [ref]$rect) | Out-Null
    $point = New-Object Win+POINT
    [Win]::ClientToScreen($proc.MainWindowHandle, [ref]$point) | Out-Null
    $width = $rect.Right - $rect.Left
    $height = $rect.Bottom - $rect.Top
    $bitmap = New-Object System.Drawing.Bitmap $width, $height
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.CopyFromScreen($point.X, $point.Y, 0, 0, $bitmap.Size)
    $graphics.Dispose()
    $path = Join-Path $shots "$name.png"
    $bitmap.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $bitmap.Dispose()
    Write-Output "saved $name"
}

# --- scenario -------------------------------------------------------------
$jdk = (Get-ChildItem (Join-Path $project 'tools/jdk') -Directory | Select-Object -First 1).FullName
$env:JAVA_HOME = $jdk
$env:PATH = "$jdk\bin;$env:PATH"
$env:GRADLE_USER_HOME = Join-Path $project 'tools/gradle-home'

$configPath = Join-Path $project 'run-visual-qa/config/hollow_signal.properties'
if (Test-Path $configPath) {
    $config = Get-Content $configPath
    $config = $config -replace 'exposure_rate=.*', $(if ($SurvivalScenes -or $SurvivalGallery) { 'exposure_rate=1.0' } else { 'exposure_rate=5.0' })
    if ($SurvivalScenes -or $SurvivalGallery -or $DawnReward) { $config = $config -replace 'signal_spawns=.*', 'signal_spawns=false' }
    $config | Set-Content $configPath -Encoding utf8
}

$log = Join-Path $project 'tools/capture-run.log'
Remove-Item $log -ErrorAction SilentlyContinue
$gradle = Start-Process -FilePath (Join-Path $project 'gradlew.bat') -ArgumentList 'runWorldTest', '--offline' `
    -PassThru -RedirectStandardOutput $log -RedirectStandardError (Join-Path $project 'tools/capture-run.err') -WindowStyle Hidden

try {
    $game = Get-GameWindow
    foreach ($try in 1..40) {
        if ((Test-Path $log) -and (Select-String -Path $log -Pattern 'joined the game' -Quiet)) { break }
        Start-Sleep -Seconds 3
    }
    Start-Sleep -Seconds 6
    [Win]::ShowWindow($game.MainWindowHandle, 3) | Out-Null   # maximize
    [Win]::MoveWindow($game.MainWindowHandle, 40, 40, 1280, 720, $true) | Out-Null
    Start-Sleep -Seconds 3
    Focus-Game $game

    if ($DawnReward) {
        Send-Command '/gamemode survival'
        Send-Command '/gamerule doDaylightCycle false'
        Send-Command '/gamerule doMobSpawning false'
        Send-Command '/clear @s'
        Send-Command '/time set 15000'
        Send-Command '/hollowsignal event red_eclipse'
        Send-Command '/effect give @s minecraft:resistance 99999 4 true'
        Send-Command '/effect give @s minecraft:night_vision 99999 0 true'
        Send-Command '/tp @s 95 -40 -126'
        Send-Command '/fill ~-3 ~-1 ~-3 ~3 ~3 ~3 air'
        Send-Command '/fill ~-4 ~-2 ~-4 ~4 ~-2 ~4 deepslate'
        Start-Sleep -Seconds 34
        Save-Shot $game '01-qualified-at-night'
        Send-Command '/time set 0'
        Start-Sleep -Seconds 3
        Save-Shot $game '02-dawn-reward'
        return
    }

    if ($SurvivalScenes) {
        Send-Command '/gamemode survival'
        Send-Command '/gamerule doDaylightCycle false'
        Send-Command '/gamerule doMobSpawning false'
        Send-Command '/kill @e[type=!player]'
        Send-Command '/time set 15000'
        Send-Command '/fill 90 70 -130 100 79 -105 air'
        Send-Command '/fill 90 69 -130 100 69 -105 minecraft:snow_block'
        Send-Command '/tp @s 95 70 -126 0 10'
        Send-Command '/effect give @s minecraft:resistance 99999 4 true'
        Send-Command '/item replace entity @s hotbar.0 with hollow_signal:resonator'
        Send-Command '/item replace entity @s hotbar.1 with hollow_signal:echo_shard 64'
        Send-Key 0x31
        Clear-Chat
        Save-Shot $game 'debug-survival-stage'
        Send-Command '/hollowsignal event red_eclipse'
        Start-Sleep -Seconds 7
        Save-Shot $game 'survival-red-eclipse'
        Send-Command '/hollowsignal event echo_bloom'
        Start-Sleep -Seconds 7
        Save-Shot $game 'survival-echo-bloom'

        Send-Key 0x35 # empty hand, but keep the survival HUD visible
        foreach ($mob in @('hollow_watcher', 'signal_stalker', 'dread_moth', 'null_creeper', 'hollow_herald')) {
            Send-Command '/kill @e[type=!player]'
            $offset = if ($mob -eq 'dread_moth') { '^ ^1 ^4' } elseif ($mob -eq 'hollow_herald') { '^ ^ ^5' } else { '^ ^ ^3' }
            Send-Command "/summon hollow_signal:$mob $offset {NoAI:1b,PersistenceRequired:1b,Rotation:[180f,0f]}"
            Clear-Chat
            Start-Sleep -Seconds 2
            Save-Shot $game "survival-mob-$mob"
        }
        Send-Command '/kill @e[type=!player]'
        Clear-Chat
        Send-Key 0x31
        Send-Command '/item replace entity @s hotbar.0 with hollow_signal:echo_blade'
        Start-Sleep -Seconds 2
        Save-Shot $game 'survival-echo-blade'
        Send-Command '/item replace entity @s hotbar.0 with hollow_signal:signal_lance'
        Start-Sleep -Seconds 2
        Save-Shot $game 'survival-signal-lance'
        Send-Command '/item replace entity @s hotbar.0 with hollow_signal:resonator'
        Start-Sleep -Seconds 2
        Save-Shot $game 'survival-resonator'
        Send-Command '/setblock 95 70 -121 air'
        Send-Command '/setblock 95 70 -121 hollow_signal:signal_rift'
        Clear-Chat
        Start-Sleep -Seconds 2
        Save-Shot $game 'survival-signal-rift'
        Send-Command '/setblock 95 70 -121 air'
        return
    }

    if ($SurvivalGallery) {
        Send-Command '/gamemode survival'
        Send-Command '/gamerule doDaylightCycle false'
        Send-Command '/gamerule doMobSpawning false'
        Send-Command '/kill @e[type=!player]'
        Send-Command '/time set 6000'
        Send-Command '/effect give @s minecraft:resistance 99999 4 true'
        Send-Command '/tp @s 95 70 -126 0 40'
        Send-Command '/setblock 95 70 -124 minecraft:crafting_table'
        Start-Sleep -Seconds 3
        $recipes = if ($RecipeId) { @($RecipeId) } else {
            @('echo_block', 'echo_blade', 'signal_lance', 'resonator', 'signal_finder', 'ward_charm', 'ward_beacon', 'echo_totem')
        }
        foreach ($selectedRecipe in $recipes) {
            Stage-Recipe $game $selectedRecipe
        }
        if ($FinalExtras) {
            Send-Command '/setblock 95 70 -124 air'
            Send-Command '/time set 15000'
            Send-Command '/tp @s 95 70 -126 0 10'
            Send-Key 0x35
            Send-Command '/summon hollow_signal:hollow_watcher ^ ^ ^3 {NoAI:1b,PersistenceRequired:1b,Rotation:[0f,0f]}'
            Clear-Chat
            Start-Sleep -Seconds 2
            Save-Shot $game 'survival-mob-hollow_watcher'
            Send-Command '/kill @e[type=!player]'
            Send-Command '/setblock 95 70 -122 hollow_signal:signal_rift'
            Clear-Chat
            Start-Sleep -Seconds 2
            Save-Shot $game 'survival-signal-rift'
            Send-Command '/setblock 95 70 -122 air'
        }
        return
    }

    if ($QuickEvents) {
        Send-Command '/gamemode survival'
        Send-Command '/gamerule doMobSpawning false'
        Send-Command '/kill @e[type=!player]'
        Send-Command '/tp @s 95 70 -126 facing 95 70 -121'
        Send-Command '/time set 15000'
        Send-Command '/effect give @s minecraft:resistance 99999 4 true'
        Send-Command '/hollowsignal event red_eclipse'
        Start-Sleep -Seconds 6
        Save-Shot $game '01a-red-eclipse'
        Send-Command '/hollowsignal event echo_bloom'
        Start-Sleep -Seconds 6
        Save-Shot $game '01b-echo-bloom'
        Send-Command '/gamemode creative'
        return
    }

    if ($QuickWeapon) {
        Send-Command '/gamemode creative'
        Send-Command '/tp @s 95 70 -126 facing 95 70 -121'
        Send-Command '/time set 15000'
        Send-Command '/item replace entity @s hotbar.0 with hollow_signal:resonator'
        Send-Key 0x31
        Start-Sleep -Seconds 3
        Save-Shot $game '10-weapon-resonator'
        return
    }

    Send-Command '/gamemode creative'
    Send-Command '/tp @s 95 70 -126 facing 95 70 -121'
    Send-Command '/gamerule doDaylightCycle false'
    Send-Command '/gamerule doMobSpawning false'
    Send-Command '/gamerule doWeatherCycle false'
    Send-Command '/weather clear'
    Send-Command '/kill @e[type=!player]'
    Send-Command '/time set 15000'
    Send-Command '/effect give @s minecraft:night_vision 99999 0 true'
    Start-Sleep -Seconds 2
    Save-Shot $game '01-night-event-title'
    Send-Command '/gamemode survival'
    Send-Command '/effect give @s minecraft:resistance 99999 4 true'
    Send-Command '/hollowsignal event red_eclipse'
    Start-Sleep -Seconds 6
    Save-Shot $game '01a-red-eclipse'
    Send-Command '/hollowsignal event echo_bloom'
    Start-Sleep -Seconds 6
    Save-Shot $game '01b-echo-bloom'
    Send-Command '/gamemode creative'
    Send-Key 0x70 # F1: clean mob portraits without the held item and HUD

    # Mob portraits, frozen with NoAI so they hold still in front of the camera.
    $mobs = @(
        @{ name = 'hollow_watcher'; offset = '^ ^ ^4' },
        @{ name = 'signal_stalker'; offset = '^ ^ ^4' },
        @{ name = 'dread_moth';     offset = '^ ^1 ^4' },
        @{ name = 'null_creeper';   offset = '^ ^ ^4' },
        @{ name = 'hollow_herald';  offset = '^ ^ ^6' }
    )
    $index = 2
    foreach ($mob in $mobs) {
        Send-Command "/kill @e[type=!player]"
        Send-Command "/summon hollow_signal:$($mob.name) $($mob.offset) {NoAI:1b,PersistenceRequired:1b,Rotation:[180f,0f]}"
        Start-Sleep -Seconds 2
        Save-Shot $game ("{0:d2}-mob-{1}" -f $index, $mob.name)
        if ($mob.name -in @('hollow_watcher', 'dread_moth', 'hollow_herald')) {
            Toggle-Hitboxes
            Save-Shot $game ("{0:d2}-hitbox-{1}" -f $index, $mob.name)
            Toggle-Hitboxes
        }
        $index++
    }
    Send-Key 0x70 # restore HUD for equipment and event screenshots
    Send-Command '/kill @e[type=!player]'

    # Weapons and items in the inventory, then the blade held in hand.
    Send-Command '/give @s hollow_signal:echo_blade'
    Send-Command '/give @s hollow_signal:signal_lance'
    Send-Command '/give @s hollow_signal:resonator'
    Send-Command '/give @s hollow_signal:signal_finder'
    Send-Command '/give @s hollow_signal:ward_charm 8'
    Send-Command '/give @s hollow_signal:echo_totem'
    Send-Command '/give @s hollow_signal:echo_shard 64'
    Send-Command '/give @s hollow_signal:echo_heart 2'
    Send-Command '/give @s hollow_signal:echo_block 16'
    Send-Command '/give @s hollow_signal:ward_beacon 4'
    Start-Sleep -Seconds 5
    Send-Key 0x45 ; Start-Sleep -Seconds 1      # E: inventory
    Save-Shot $game '07-items-inventory'
    Send-Key 0x1B ; Start-Sleep -Milliseconds 500  # Escape

    Send-Key 0x31 ; Start-Sleep -Seconds 2; Save-Shot $game '08-weapon-echo-blade'
    Send-Key 0x32 ; Start-Sleep -Seconds 2; Save-Shot $game '09-weapon-signal-lance'
    Send-Key 0x33 ; Start-Sleep -Seconds 2; Save-Shot $game '10-weapon-resonator'

    # Tier 3 Ward Beacon: three Echo Blocks under a beacon, then fuel it by hand.
    Send-Command '/fill ~2 ~-3 ~2 ~2 ~-1 ~2 hollow_signal:echo_block'
    Send-Command '/setblock ~2 ~ ~2 hollow_signal:ward_beacon'
    Send-Command '/tp @s ~ ~ ~ facing ~2 ~0.4 ~2'
    Start-Sleep -Seconds 1
    Send-Key 0x37    # hotbar slot 7 (echo shards)
    Start-Sleep -Milliseconds 400
    Right-Click
    Right-Click
    Start-Sleep -Seconds 2
    Save-Shot $game '11-ward-beacon-tier3'

    Send-Command '/setblock ~-3 ~ ~4 hollow_signal:signal_rift'
    Send-Command '/tp @s ~ ~ ~ facing ~-3 ~ ~4'
    Start-Sleep -Seconds 2
    Save-Shot $game '12-signal-rift'
    Send-Command '/setblock ~-3 ~ ~4 air'

    # Exposure meter: survival in the dark with a fast exposure rate.
    Send-Command '/gamemode survival'
    Send-Command '/effect give @s minecraft:resistance 99999 4 true'
    Send-Command '/effect clear @s minecraft:night_vision'
    Send-Command '/tp @s ~ -40 ~'
    Send-Command '/fill ~-3 ~-1 ~-3 ~3 ~3 ~3 air'
    Send-Command '/fill ~-4 ~-2 ~-4 ~4 ~-2 ~4 deepslate'
    Start-Sleep -Seconds 40
    Save-Shot $game '13-exposure-meter'
    Start-Sleep -Seconds 35
    Save-Shot $game '14-exposure-warning'
    Start-Sleep -Seconds 30
    Save-Shot $game '15-exposure-encounter'
    Send-Command '/gamemode creative'
}
finally {
    if (Test-Path $configPath) {
        (Get-Content $configPath) -replace 'exposure_rate=.*', 'exposure_rate=1.0' `
            -replace 'signal_spawns=.*', 'signal_spawns=true' | Set-Content $configPath -Encoding utf8
    }
    $ids = @($gradle.Id)
    Get-CimInstance Win32_Process | Where-Object { $_.ParentProcessId -eq $gradle.Id } | ForEach-Object {
        $ids += $_.ProcessId
        Get-CimInstance Win32_Process | Where-Object { $_.ParentProcessId -eq $_.ProcessId } | ForEach-Object { $ids += $_.ProcessId }
    }
    if ($game) { $ids += $game.Id }
    foreach ($id in $ids) { try { Stop-Process -Id $id -Force -ErrorAction Stop } catch {} }
}
Write-Output 'capture finished'
