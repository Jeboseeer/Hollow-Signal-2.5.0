"""Catch cuboid UV layouts that extend beyond an entity texture sheet."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "src/main/java/dev/hollowsignal/client"
issues = []

for path in sorted(MODELS.glob("*Model.java")):
    source = path.read_text(encoding="utf-8")
    sheet = re.search(r"TexturedModelData\.of\(data,\s*(\d+),\s*(\d+)\)", source)
    if sheet is None:
        continue
    texture_width, texture_height = map(int, sheet.groups())
    for match in re.finditer(r"\.uv\((\d+)\s*,\s*(\d+)\)\.cuboid\(([^)]*)\)", source):
        u, v = map(int, match.group(1, 2))
        values = [float(value.strip().rstrip("f")) for value in match.group(3).split(",")]
        if len(values) != 6:
            continue
        width, height, depth = values[3:]
        # Vanilla's unfolded box UV occupies 2*width + 2*depth by height + depth.
        if u + 2 * width + 2 * depth > texture_width or v + height + depth > texture_height:
            line = source.count("\n", 0, match.start()) + 1
            issues.append(f"{path.name}:{line}: cuboid UV exceeds {texture_width}x{texture_height} sheet")

if issues:
    print("\n".join(issues))
    sys.exit(1)
print("all entity cuboid UVs fit their texture sheets")
