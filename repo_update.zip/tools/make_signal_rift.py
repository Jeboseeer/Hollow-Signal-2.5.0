"""Generate the luminous voxel model and atlas for the natural Signal Rift."""
from pathlib import Path
import json, struct, zlib
root = Path(__file__).resolve().parents[1] / 'src/main/resources/assets/hollow_signal'
colors = [(15, 12, 28), (40, 27, 67), (77, 42, 113), (125, 66, 173),
          (184, 108, 223), (232, 172, 255), (37, 120, 139), (93, 223, 222),
          (75, 65, 100), (124, 110, 150), (20, 18, 34), (226, 227, 251),
          (47, 33, 75), (107, 68, 145), (162, 91, 200), (254, 220, 255)]
raw = bytearray()
for y in range(16):
    raw.append(0)
    for x in range(16):
        r, g, b = colors[(y // 4) * 4 + x // 4]
        shade = -9 if x % 4 == 0 or y % 4 == 0 else 0
        raw.extend((max(0, r + shade), max(0, g + shade), max(0, b + shade), 255))
def chunk(tag, data):
    return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data))
png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB',16,16,8,6,0,0,0)) + chunk(b'IDAT',zlib.compress(raw,9)) + chunk(b'IEND',b'')
(root / 'textures/block/signal_rift.png').write_bytes(png)
def uv(i):
    x, y = i % 4 * 4, i // 4 * 4
    return [x,y,x+4,y+4]
def box(frm,to,front,side,top):
    return {'from':frm,'to':to,'faces':{face:{'uv':uv(index),'texture':'#atlas'} for face,index in
      [('north',front),('south',front),('east',side),('west',side),('up',top),('down',side)]}}
elements = [
    box([-2,0,-2],[18,2,18],1,0,8),
    box([1,2,1],[15,3,15],2,1,9),
    box([5,3,5],[11,17,11],1,2,3),
    box([6,6,4.7],[10,16,5],7,6,7),
    box([6,6,11],[10,16,11.3],7,6,7),
    box([6,17,6],[10,21,10],3,2,4),
    box([7,21,7],[9,26,9],5,4,11),
    box([2,2,2],[4,14,4],12,1,3),
    box([12,2,2],[14,17,4],13,2,4),
    box([2,2,12],[4,17,14],13,2,4),
    box([12,2,12],[14,14,14],12,1,3),
    box([2,14,2],[4,20,4],4,3,5),
    box([12,17,2],[14,23,4],5,3,11),
    box([2,17,12],[4,23,14],5,3,11),
    box([12,14,12],[14,20,14],4,3,5),
    box([0,3,6],[3,5,10],2,1,4),
    box([13,3,6],[16,5,10],2,1,4),
]
model={'textures':{'atlas':'hollow_signal:block/signal_rift','particle':'hollow_signal:block/signal_rift'},'elements':elements}
(root / 'models/block/signal_rift.json').write_text(json.dumps(model,indent=2)+'\n',encoding='utf-8')
(root / 'blockstates/signal_rift.json').write_text(json.dumps({
    'variants': {f'phase={phase}': {'model': 'hollow_signal:block/signal_rift'} for phase in range(4)}
}, indent=2)+'\n',encoding='utf-8')
