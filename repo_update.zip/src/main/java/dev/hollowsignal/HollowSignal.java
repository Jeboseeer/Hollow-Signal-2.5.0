package dev.hollowsignal;

import dev.hollowsignal.block.WardBeaconBlock;
import dev.hollowsignal.block.WardBeaconBlockEntity;
import dev.hollowsignal.block.SignalRiftBlock;
import dev.hollowsignal.entity.DreadMothEntity;
import dev.hollowsignal.entity.HollowHeraldEntity;
import dev.hollowsignal.entity.HollowWatcherEntity;
import dev.hollowsignal.entity.NullCreeperEntity;
import dev.hollowsignal.entity.SignalStalkerEntity;
import dev.hollowsignal.item.EchoBladeItem;
import dev.hollowsignal.item.EchoMaterial;
import dev.hollowsignal.item.ResonatorItem;
import dev.hollowsignal.item.SignalLanceItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;

public class HollowSignal implements ModInitializer {
    public static final String MOD_ID = "hollow_signal";

    public static final Item ECHO_SHARD = register("echo_shard", new Item(new Item.Settings()));
    public static final Item ECHO_HEART = register("echo_heart", new Item(new Item.Settings().maxCount(4).rarity(net.minecraft.util.Rarity.EPIC)));
    public static final Item ECHO_TOTEM = register("echo_totem", new Item(new Item.Settings().maxCount(1).rarity(net.minecraft.util.Rarity.RARE)));
    public static final Item SIGNAL_FINDER = register("signal_finder", new Item(new Item.Settings().maxCount(1).maxDamage(96)));
    public static final Item WARD_CHARM = register("ward_charm", new Item(new Item.Settings().maxCount(16)));
    public static final Item ECHO_BLADE = register("echo_blade", new EchoBladeItem(EchoMaterial.INSTANCE,
        new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(EchoMaterial.INSTANCE, 3, -2.4f))));
    public static final Item SIGNAL_LANCE = register("signal_lance", new SignalLanceItem(EchoMaterial.INSTANCE,
        new Item.Settings().attributeModifiers(SignalLanceItem.modifiers(4.5, -3.0, 1.5))));
    public static final Item RESONATOR = register("resonator", new ResonatorItem(new Item.Settings().maxCount(1).maxDamage(192)));

    public static final Block WARD_BEACON = Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "ward_beacon"),
        new WardBeaconBlock(AbstractBlock.Settings.create().strength(2.5f)
            .luminance(state -> state.get(WardBeaconBlock.LIT) ? 14 : 4).sounds(BlockSoundGroup.AMETHYST_BLOCK)));
    public static final Block ECHO_BLOCK = Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "echo_block"),
        new Block(AbstractBlock.Settings.create().strength(3.0f).luminance(state -> 5).sounds(BlockSoundGroup.AMETHYST_BLOCK)));
    public static final Block SIGNAL_RIFT = Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "signal_rift"),
        new SignalRiftBlock(AbstractBlock.Settings.create().strength(5.0f).nonOpaque()
            .luminance(state -> 10).sounds(BlockSoundGroup.AMETHYST_BLOCK)));
    public static final Item WARD_BEACON_ITEM = register("ward_beacon", new BlockItem(WARD_BEACON, new Item.Settings()));
    public static final Item ECHO_BLOCK_ITEM = register("echo_block", new BlockItem(ECHO_BLOCK, new Item.Settings()));
    public static final BlockEntityType<WardBeaconBlockEntity> WARD_BEACON_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE,
        Identifier.of(MOD_ID, "ward_beacon"), BlockEntityType.Builder.create(WardBeaconBlockEntity::new, WARD_BEACON).build(null));

    public static final EntityType<SignalStalkerEntity> SIGNAL_STALKER = registerEntity("signal_stalker",
        EntityType.Builder.create(SignalStalkerEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f));
    public static final EntityType<HollowWatcherEntity> HOLLOW_WATCHER = registerEntity("hollow_watcher",
        EntityType.Builder.create(HollowWatcherEntity::new, SpawnGroup.MONSTER).dimensions(1.55f, 0.9f));
    public static final EntityType<DreadMothEntity> DREAD_MOTH = registerEntity("dread_moth",
        EntityType.Builder.<DreadMothEntity>create(DreadMothEntity::new, SpawnGroup.MONSTER).dimensions(2.0f, 1.0f));
    public static final EntityType<NullCreeperEntity> NULL_CREEPER = registerEntity("null_creeper",
        EntityType.Builder.<NullCreeperEntity>create(NullCreeperEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.7f));
    public static final EntityType<HollowHeraldEntity> HOLLOW_HERALD = registerEntity("hollow_herald",
        EntityType.Builder.<HollowHeraldEntity>create(HollowHeraldEntity::new, SpawnGroup.MONSTER).dimensions(1.4f, 2.9f));

    public static final Item STALKER_EGG = register("signal_stalker_spawn_egg", new SpawnEggItem(SIGNAL_STALKER, 0x161322, 0x65E3E8, new Item.Settings()));
    public static final Item WATCHER_EGG = register("hollow_watcher_spawn_egg", new SpawnEggItem(HOLLOW_WATCHER, 0x21172D, 0xDA6BF6, new Item.Settings()));
    public static final Item MOTH_EGG = register("dread_moth_spawn_egg", new SpawnEggItem(DREAD_MOTH, 0x1B1A2E, 0x8FE3D2, new Item.Settings()));
    public static final Item CREEPER_EGG = register("null_creeper_spawn_egg", new SpawnEggItem(NULL_CREEPER, 0x121824, 0x4FD6B8, new Item.Settings()));
    public static final Item HERALD_EGG = register("hollow_herald_spawn_egg", new SpawnEggItem(HOLLOW_HERALD, 0x0D0A16, 0xC77BFF, new Item.Settings()));

    /** True for every mob this mod adds; the echo weapons and the Ward Beacon hit them harder. */
    public static boolean isHollowMob(Entity entity) {
        return entity instanceof HollowWatcherEntity || entity instanceof SignalStalkerEntity
            || entity instanceof DreadMothEntity || entity instanceof NullCreeperEntity
            || entity instanceof HollowHeraldEntity;
    }

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(MOD_ID, name), item);
    }

    private static <T extends net.minecraft.entity.Entity> EntityType<T> registerEntity(String name, EntityType.Builder<T> builder) {
        return Registry.register(Registries.ENTITY_TYPE, Identifier.of(MOD_ID, name), builder.build(MOD_ID + ":" + name));
    }

    @Override public void onInitialize() {
        HollowSignalConfig.load();
        PayloadTypeRegistry.playS2C().register(ExposurePayload.ID, ExposurePayload.CODEC);
        FabricDefaultAttributeRegistry.register(SIGNAL_STALKER, SignalStalkerEntity.attributes());
        FabricDefaultAttributeRegistry.register(HOLLOW_WATCHER, HollowWatcherEntity.attributes());
        FabricDefaultAttributeRegistry.register(DREAD_MOTH, DreadMothEntity.attributes());
        FabricDefaultAttributeRegistry.register(NULL_CREEPER, NullCreeperEntity.attributes());
        FabricDefaultAttributeRegistry.register(HOLLOW_HERALD, HollowHeraldEntity.attributes());

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> { entries.add(SIGNAL_FINDER); entries.add(WARD_CHARM); entries.add(ECHO_TOTEM); });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> { entries.add(ECHO_BLADE); entries.add(SIGNAL_LANCE); entries.add(RESONATOR); });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> { entries.add(ECHO_SHARD); entries.add(ECHO_HEART); });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> { entries.add(WARD_BEACON_ITEM); entries.add(ECHO_BLOCK_ITEM); });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            entries.add(STALKER_EGG); entries.add(WATCHER_EGG); entries.add(MOTH_EGG); entries.add(CREEPER_EGG); entries.add(HERALD_EGG);
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (world.isClient || !(player instanceof ServerPlayerEntity server)) return TypedActionResult.pass(stack);
            if (stack.isOf(SIGNAL_FINDER)) return scan(server, hand, stack);
            if (stack.isOf(WARD_CHARM)) return ward(server, stack);
            return TypedActionResult.pass(stack);
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity server)) return ActionResult.PASS;
            ItemStack stack = player.getStackInHand(hand);
            if (!stack.isOf(ECHO_SHARD) || !world.getBlockState(hit.getBlockPos()).isOf(ECHO_BLOCK)) return ActionResult.PASS;
            if (!SignalManager.summonHerald((ServerWorld) world, hit.getBlockPos(), server)) {
                server.sendMessage(Text.translatable("message.hollow_signal.ritual_failed").formatted(Formatting.GRAY), true);
                return ActionResult.SUCCESS;
            }
            if (!player.getAbilities().creativeMode) stack.decrement(1);
            return ActionResult.SUCCESS;
        });

        ServerTickEvents.END_SERVER_TICK.register(SignalManager::tick);
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            var eventCommand = CommandManager.literal("event").then(
                CommandManager.literal("random").executes(context -> {
                    SignalManager.forceEvent(context.getSource().getServer(),
                        NightEvent.roll(context.getSource().getWorld().getRandom()));
                    return 1;
                }));
            for (NightEvent nightEvent : NightEvent.values()) {
                eventCommand.then(CommandManager.literal(nightEvent.id).executes(context -> {
                    SignalManager.forceEvent(context.getSource().getServer(), nightEvent);
                    return 1;
                }));
            }
            dispatcher.register(CommandManager.literal("hollowsignal")
                .requires(source -> source.hasPermissionLevel(2)).then(eventCommand));
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> SignalManager.reset());
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> SignalManager.forget(handler.getPlayer().getUuid()));

        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> !SignalManager.consumeTotem(entity));
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayerEntity player) SignalManager.onPlayerDeath(player);
            boolean hollow = entity instanceof SignalStalkerEntity || entity instanceof HollowWatcherEntity ||
                entity instanceof DreadMothEntity || entity instanceof NullCreeperEntity || entity instanceof HollowHeraldEntity;
            if (hollow && source.getAttacker() instanceof ServerPlayerEntity killer) SignalManager.onHollowKilled(killer);
            int bonus = SignalManager.dropBonus();
            if (entity instanceof SignalStalkerEntity) entity.dropStack(new ItemStack(ECHO_SHARD, (2 + entity.getRandom().nextInt(2)) * bonus));
            if (entity instanceof HollowWatcherEntity) entity.dropStack(new ItemStack(ECHO_SHARD, 1 * bonus));
            if (entity instanceof DreadMothEntity) entity.dropStack(new ItemStack(ECHO_SHARD, (1 + entity.getRandom().nextInt(2)) * bonus));
            if (entity instanceof NullCreeperEntity) entity.dropStack(new ItemStack(ECHO_SHARD, (1 + entity.getRandom().nextInt(3)) * bonus));
            if (entity instanceof HollowHeraldEntity) {
                entity.dropStack(new ItemStack(ECHO_HEART, 1));
                entity.dropStack(new ItemStack(ECHO_SHARD, 8 + entity.getRandom().nextInt(5)));
            }
        });
    }

    private static TypedActionResult<ItemStack> scan(ServerPlayerEntity player, Hand hand, ItemStack stack) {
        if (player.getItemCooldownManager().isCoolingDown(SIGNAL_FINDER)) return TypedActionResult.fail(stack);
        var targets = player.getWorld().getEntitiesByClass(HostileEntity.class, player.getBoundingBox().expand(32), e -> e.isAlive());
        for (HostileEntity target : targets) {
            player.getServerWorld().spawnParticles(net.minecraft.particle.ParticleTypes.SCULK_SOUL,
                target.getX(), target.getBodyY(0.8), target.getZ(), 10, 0.4, 0.5, 0.4, 0.015);
        }
        int found = targets.size();
        player.sendMessage(Text.translatable("message.hollow_signal.scan", found), true);
        BlockPos nearestRift = SignalManager.findNearestRift(player.getServerWorld(), player.getBlockPos(), 32);
        if (nearestRift != null) {
            int dx = nearestRift.getX() - player.getBlockX();
            int dz = nearestRift.getZ() - player.getBlockZ();
            String direction = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? "E" : "W") : (dz > 0 ? "S" : "N");
            int distance = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
            player.sendMessage(Text.translatable("message.hollow_signal.rift_found", distance,
                Text.translatable("direction.hollow_signal." + direction.toLowerCase(java.util.Locale.ROOT))), false);
        }
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 0.8f, found > 0 ? 0.6f : 1.3f);
        player.getItemCooldownManager().set(SIGNAL_FINDER, 240);
        stack.damage(1, player, hand == Hand.MAIN_HAND ? net.minecraft.entity.EquipmentSlot.MAINHAND : net.minecraft.entity.EquipmentSlot.OFFHAND);
        return TypedActionResult.success(stack);
    }

    private static TypedActionResult<ItemStack> ward(ServerPlayerEntity player, ItemStack stack) {
        if (player.getItemCooldownManager().isCoolingDown(WARD_CHARM)) return TypedActionResult.fail(stack);
        SignalManager.clearExposure(player);
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 0));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 300, 0));
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 0.9f, 1.5f);
        player.sendMessage(Text.translatable("message.hollow_signal.ward"), true);
        player.getItemCooldownManager().set(WARD_CHARM, 600);
        if (!player.getAbilities().creativeMode) stack.decrement(1);
        return TypedActionResult.success(stack);
    }
}
