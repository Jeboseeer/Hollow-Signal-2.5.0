package dev.hollowsignal;

import dev.hollowsignal.entity.HollowHeraldEntity;
import dev.hollowsignal.entity.HollowWatcherEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Tracks darkness exposure, the nightly event and every active Ward Beacon. */
public final class SignalManager {
    private static final Map<UUID, Integer> EXPOSURE = new HashMap<>();
    private static final Map<UUID, Long> NEXT_RIFT_ATTEMPT = new HashMap<>();
    private static final Map<Long, Ward> WARDS = new HashMap<>();
    private static final Set<UUID> NIGHT_PARTICIPANTS = new HashSet<>();
    private static NightEvent event = NightEvent.CALM;
    private static long eventDay = -1;
    private static int ticks;

    private record Ward(String dimension, BlockPos pos, int radius, long stamp) {}

    private SignalManager() {}

    public static NightEvent currentEvent() { return event; }

    public static int exposureOf(ServerPlayerEntity player) { return EXPOSURE.getOrDefault(player.getUuid(), 0); }

    public static void clearExposure(ServerPlayerEntity player) { EXPOSURE.put(player.getUuid(), 0); }

    /** Echo Bloom turns a dangerous night into a recoverable hunt. */
    public static void onHollowKilled(ServerPlayerEntity player) {
        markParticipation(player);
        if (event != NightEvent.ECHO_BLOOM || !player.getServerWorld().isNight()) return;
        EXPOSURE.put(player.getUuid(), Math.max(0, exposureOf(player) - 18));
        player.getServerWorld().spawnParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0,
            player.getZ(), 18, 0.5, 0.6, 0.5, 0.02);
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
            SoundCategory.PLAYERS, 0.5f, 1.3f);
        player.sendMessage(Text.translatable("message.hollow_signal.bloom_relief").formatted(Formatting.AQUA), true);
    }

    public static void forget(UUID id) {
        EXPOSURE.remove(id);
        NIGHT_PARTICIPANTS.remove(id);
    }

    public static void onPlayerDeath(ServerPlayerEntity player) {
        NIGHT_PARTICIPANTS.remove(player.getUuid());
        EXPOSURE.put(player.getUuid(), 0);
    }

    private static void markParticipation(ServerPlayerEntity player) {
        if (event != NightEvent.CALM && player.getServerWorld().getRegistryKey().equals(World.OVERWORLD)
                && player.getServerWorld().isNight() && !player.isCreative() && !player.isSpectator()) {
            NIGHT_PARTICIPANTS.add(player.getUuid());
        }
    }

    public static void riftSealed(ServerPlayerEntity player) {
        markParticipation(player);
        NEXT_RIFT_ATTEMPT.put(player.getUuid(), player.getServerWorld().getTime() + 2400);
    }

    public static void reset() {
        EXPOSURE.clear();
        NEXT_RIFT_ATTEMPT.clear();
        WARDS.clear();
        NIGHT_PARTICIPANTS.clear();
        event = NightEvent.CALM;
        eventDay = -1;
        ticks = 0;
    }

    public static void registerWard(World world, BlockPos pos, int radius) {
        WARDS.put(key(world, pos), new Ward(world.getRegistryKey().getValue().toString(), pos.toImmutable(), radius, world.getTime()));
    }

    private static long key(World world, BlockPos pos) {
        return pos.asLong() * 31L + world.getRegistryKey().getValue().toString().hashCode();
    }

    public static boolean isWarded(ServerPlayerEntity player) {
        World world = player.getWorld();
        String dimension = world.getRegistryKey().getValue().toString();
        long now = world.getTime();
        for (Ward ward : WARDS.values()) {
            if (!ward.dimension().equals(dimension) || now - ward.stamp() > 60) continue;
            BlockPos pos = ward.pos();
            double dx = player.getX() - (pos.getX() + 0.5);
            double dz = player.getZ() - (pos.getZ() + 0.5);
            double dy = Math.abs(player.getY() - pos.getY());
            if (dx * dx + dz * dz <= ward.radius() * (double) ward.radius() && dy <= Math.max(4, ward.radius() / 2.0)) return true;
        }
        return false;
    }

    public static void tick(MinecraftServer server) {
        ticks++;
        if (ticks % 20 == 0) {
            updateEvent(server);
            WARDS.values().removeIf(ward -> server.getOverworld().getTime() - ward.stamp() > 200);
            if (HollowSignalConfig.hud) {
                for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                    if (net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(player, ExposurePayload.ID)) {
                        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player,
                            new ExposurePayload(exposureOf(player), event.ordinal()));
                    }
                }
            }
        }
        if (ticks % 100 != 0) return;
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) tickPlayer(player);
    }

    private static void updateEvent(MinecraftServer server) {
        ServerWorld overworld = server.getOverworld();
        long time = overworld.getTimeOfDay() % 24000L;
        long day = overworld.getTimeOfDay() / 24000L;
        if (time < 13000L) {
            if (event != NightEvent.CALM) {
                rewardSurvivors(server);
                event = NightEvent.CALM;
                broadcast(server, Text.translatable("event.hollow_signal.dawn").formatted(Formatting.GRAY), null, false);
            }
            return;
        }
        if (day == eventDay) return;
        eventDay = day;
        NIGHT_PARTICIPANTS.clear();
        event = HollowSignalConfig.events ? NightEvent.roll(overworld.getRandom()) : NightEvent.CALM;
        announceEvent(server);
    }

    private static void rewardSurvivors(MinecraftServer server) {
        int count = switch (event) {
            case RED_ECLIPSE -> 4;
            case SIGNAL_STORM, CONVERGENCE, ECHO_BLOOM -> 3;
            case DEAD_SILENCE, ECHO_HUNT -> 2;
            default -> 0;
        };
        if (count > 0) {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (!NIGHT_PARTICIPANTS.contains(player.getUuid()) || !player.isAlive() || player.isCreative() || player.isSpectator()) continue;
                ItemStack reward = new ItemStack(HollowSignal.ECHO_SHARD, count);
                player.getInventory().insertStack(reward);
                if (!reward.isEmpty()) player.dropItem(reward, false);
                player.sendMessage(Text.translatable("message.hollow_signal.dawn_reward", count).formatted(Formatting.AQUA), false);
                player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                    SoundCategory.PLAYERS, 0.8f, 1.2f);
            }
        }
        NIGHT_PARTICIPANTS.clear();
    }

    /** Lets world operators stage and inspect an encounter without waiting for the next dusk. */
    public static void forceEvent(MinecraftServer server, NightEvent chosen) {
        eventDay = server.getOverworld().getTimeOfDay() / 24000L;
        if (chosen != event) NIGHT_PARTICIPANTS.clear();
        event = chosen;
        announceEvent(server);
    }

    private static void announceEvent(MinecraftServer server) {
        if (event == NightEvent.CALM) return;
        // The client HUD announces the event in a compact banner when the synced event changes.
        if (!HollowSignalConfig.hud) {
            broadcast(server, Text.translatable(event.titleKey()).formatted(Formatting.LIGHT_PURPLE), null, false);
        }
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.AMBIENT, 0.7f, 0.6f);
        }
    }

    private static void broadcast(MinecraftServer server, Text title, Text subtitle, boolean overlay) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (overlay) {
                player.networkHandler.sendPacket(new TitleS2CPacket(title));
                if (subtitle != null) player.networkHandler.sendPacket(new SubtitleS2CPacket(subtitle));
            } else {
                player.sendMessage(title, true);
            }
        }
    }

    private static void tickPlayer(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        UUID id = player.getUuid();
        int exposure = EXPOSURE.getOrDefault(id, 0);
        boolean dark = world.getLightLevel(player.getBlockPos()) < 8;
        if (player.isSpectator() || player.isCreative() || !world.isNight() || !dark || player.isSleeping() || isWarded(player)) {
            EXPOSURE.put(id, Math.max(0, exposure - 3));
            return;
        }
        int gain = (int) Math.max(1, Math.round(HollowSignalConfig.exposureRate * switch (event) {
            case SIGNAL_STORM -> 2.0;
            case CONVERGENCE -> 1.5;
            case DEAD_SILENCE -> 0.5;
            case RED_ECLIPSE -> 1.7;
            case ECHO_BLOOM -> 1.2;
            default -> 1.0;
        }));
        int before = exposure;
        exposure = Math.min(100, exposure + gain);
        EXPOSURE.put(id, exposure);
        if (exposure >= 50) markParticipation(player);
        warn(player, before, exposure);
        if (HollowSignalConfig.spawns) tickRift(player, world, exposure);
        if (exposure >= 60) {
            world.spawnParticles(ParticleTypes.SCULK_SOUL, player.getX(), player.getY() + 2.2, player.getZ(), 2, 0.4, 0.2, 0.4, 0.0);
        }
        if (exposure >= 25 && event != NightEvent.DEAD_SILENCE && world.getRandom().nextInt(exposure >= 75 ? 3 : 7) == 0) {
            world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT,
                SoundCategory.AMBIENT, 0.16f + exposure * 0.002f, 0.65f + world.getRandom().nextFloat() * 0.12f);
        }
        if (event == NightEvent.SIGNAL_STORM && exposure >= 25) {
            world.spawnParticles(ParticleTypes.ASH, player.getX(), player.getY() + 1.6, player.getZ(),
                5, 3.0, 1.2, 3.0, 0.003);
        }
        showEventAtmosphere(world, player, exposure);
        if (HollowSignalConfig.spawns) escalate(player, world, before, exposure);
    }

    /** Each night event has its own readable sky-side effect without potion particles. */
    private static void showEventAtmosphere(ServerWorld world, ServerPlayerEntity player, int exposure) {
        double x = player.getX(), y = player.getY() + 1.5, z = player.getZ();
        switch (event) {
            case SIGNAL_STORM -> {
                world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 9, 5.0, 2.0, 5.0, 0.025);
                if (world.getRandom().nextInt(4) == 0) world.playSound(null, player.getBlockPos(),
                    SoundEvents.BLOCK_SCULK_SENSOR_CLICKING, SoundCategory.AMBIENT, 0.35f, 0.55f);
            }
            case DEAD_SILENCE -> world.spawnParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 4, 4.0, 1.0, 4.0, 0.002);
            case ECHO_HUNT -> {
                world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y - 0.5, z, 6, 5.0, 0.6, 5.0, 0.0);
                if (exposure >= 50 && world.getRandom().nextInt(3) == 0) world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_SPIDER_AMBIENT, SoundCategory.AMBIENT, 0.28f, 0.55f);
            }
            case CONVERGENCE -> {
                world.spawnParticles(ParticleTypes.PORTAL, x, y, z, 12, 4.0, 1.7, 4.0, 0.05);
                if (world.getRandom().nextInt(4) == 0) world.playSound(null, player.getBlockPos(),
                    SoundEvents.BLOCK_AMETHYST_BLOCK_RESONATE, SoundCategory.AMBIENT, 0.4f, 0.55f);
            }
            case RED_ECLIPSE -> {
                world.spawnParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 16, 5.0, 2.0, 5.0, 0.012);
                world.spawnParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 3, 4.0, 1.0, 4.0, 0.003);
                if (world.getRandom().nextInt(3) == 0) world.playSound(null, player.getBlockPos(),
                    SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.AMBIENT, 0.38f, 0.45f);
            }
            case ECHO_BLOOM -> {
                world.spawnParticles(ParticleTypes.END_ROD, x, y, z, 12, 5.0, 1.5, 5.0, 0.004);
                if (world.getRandom().nextInt(4) == 0) world.playSound(null, player.getBlockPos(),
                    SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.AMBIENT, 0.3f, 1.2f);
            }
            default -> { }
        }
    }

    /** Searches loaded nearby blocks only; used by the finder and the rift encounter. */
    public static BlockPos findNearestRift(ServerWorld world, BlockPos origin, int radius) {
        BlockPos best = null;
        double nearest = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.iterate(origin.add(-radius, -8, -radius), origin.add(radius, 8, radius))) {
            if (!world.getBlockState(pos).isOf(HollowSignal.SIGNAL_RIFT)) continue;
            double distance = pos.getSquaredDistance(origin);
            if (distance < nearest) {
                nearest = distance;
                best = pos.toImmutable();
            }
        }
        return best;
    }

    private static void tickRift(ServerPlayerEntity player, ServerWorld world, int exposure) {
        BlockPos nearby = findNearestRift(world, player.getBlockPos(), 8);
        if (nearby != null) {
            // Wake rifts carried over from worlds created before scheduled waves existed.
            if (!world.getBlockTickScheduler().isQueued(nearby, HollowSignal.SIGNAL_RIFT)
                    && !world.getBlockTickScheduler().isTicking(nearby, HollowSignal.SIGNAL_RIFT)) {
                world.scheduleBlockTick(nearby, HollowSignal.SIGNAL_RIFT, 120);
            }
            if (nearby.getSquaredDistance(player.getBlockPos()) <= 64) {
                EXPOSURE.put(player.getUuid(), Math.min(100, exposure + 3));
                world.spawnParticles(ParticleTypes.SCULK_SOUL, nearby.getX() + 0.5, nearby.getY() + 1.0,
                    nearby.getZ() + 0.5, 6, 0.5, 0.6, 0.5, 0.015);
                // Escalating waves are driven by the rift's scheduled block tick.
            }
            return;
        }
        int threshold = event == NightEvent.CONVERGENCE ? 35 : 50;
        if (exposure < threshold || !world.isNight()) return;
        long now = world.getTime();
        if (now < NEXT_RIFT_ATTEMPT.getOrDefault(player.getUuid(), 0L)) return;
        NEXT_RIFT_ATTEMPT.put(player.getUuid(), now + 400);
        if (findNearestRift(world, player.getBlockPos(), 40) != null) return;
        if (spawnRift(world, player)) NEXT_RIFT_ATTEMPT.put(player.getUuid(), now + 3600);
    }

    private static boolean spawnRift(ServerWorld world, ServerPlayerEntity player) {
        BlockPos pos = placeRift(world, player.getBlockPos(), 10, 19);
        if (pos == null) return false;
        player.sendMessage(Text.translatable("message.hollow_signal.rift_opened").formatted(Formatting.DARK_PURPLE), false);
        return true;
    }

    /** Escalating rift defence, capped so long-lived rifts do not flood the world. */
    public static void spawnRiftWave(ServerWorld world, BlockPos pos, ServerPlayerEntity target, int phase) {
        spawnRiftGuard(world, pos, target);
        if (phase >= 2) spawnRiftGuard(world, pos, target);
        if (phase < 3) return;
        var nearby = world.getEntitiesByClass(dev.hollowsignal.entity.NullCreeperEntity.class,
            new net.minecraft.util.math.Box(pos).expand(12), e -> e.isAlive());
        if (!nearby.isEmpty()) return;
        for (int attempt = 0; attempt < 12; attempt++) {
            BlockPos spawn = pos.add(world.getRandom().nextBetween(-5, 5), 0,
                world.getRandom().nextBetween(-5, 5));
            if (!world.getBlockState(spawn).isAir() || !world.getBlockState(spawn.up()).isAir()) continue;
            if (!world.getBlockState(spawn.down()).isSolidBlock(world, spawn.down())) continue;
            var creeper = HollowSignal.NULL_CREEPER.create(world);
            if (creeper == null) return;
            creeper.refreshPositionAndAngles(spawn, world.getRandom().nextFloat() * 360.0f, 0.0f);
            creeper.setTarget(target);
            world.spawnEntity(creeper);
            return;
        }
    }

    /** The Herald opens one nearby rift at the start of its second phase. */
    public static boolean openHeraldRift(ServerWorld world, BlockPos origin) {
        if (findNearestRift(world, origin, 16) != null) return true;
        return placeRift(world, origin, 5, 9) != null;
    }

    private static BlockPos placeRift(ServerWorld world, BlockPos origin, int minRadius, int maxRadius) {
        var random = world.getRandom();
        for (int attempt = 0; attempt < 40; attempt++) {
            int dx = random.nextBetween(-maxRadius, maxRadius);
            int dz = random.nextBetween(-maxRadius, maxRadius);
            if (dx * dx + dz * dz < minRadius * minRadius) continue;
            for (int dy = 8; dy >= -8; dy--) {
                BlockPos pos = origin.add(dx, dy, dz);
                var state = world.getBlockState(pos);
                if (!state.isAir() && !state.isOf(Blocks.SNOW)) continue;
                if (!world.getBlockState(pos.up()).isAir() || !world.getBlockState(pos.up(2)).isAir()) continue;
                if (!world.getBlockState(pos.down()).isSolidBlock(world, pos.down())) continue;
                if (!world.setBlockState(pos, HollowSignal.SIGNAL_RIFT.getDefaultState())) continue;
                world.spawnParticles(ParticleTypes.SCULK_SOUL, pos.getX() + 0.5, pos.getY() + 0.5,
                    pos.getZ() + 0.5, 45, 1.0, 1.2, 1.0, 0.035);
                world.playSound(null, pos, SoundEvents.BLOCK_SCULK_SHRIEKER_SHRIEK, SoundCategory.HOSTILE, 0.9f, 0.7f);
                return pos;
            }
        }
        return null;
    }

    private static void spawnRiftGuard(ServerWorld world, BlockPos pos, ServerPlayerEntity player) {
        var nearby = world.getEntitiesByClass(HollowWatcherEntity.class,
            new net.minecraft.util.math.Box(pos).expand(12), e -> e.isAlive());
        if (nearby.size() >= 3) return;
        for (int attempt = 0; attempt < 12; attempt++) {
            BlockPos spawn = pos.add(world.getRandom().nextBetween(-4, 4), 0, world.getRandom().nextBetween(-4, 4));
            if (!world.getBlockState(spawn).isAir() || !world.getBlockState(spawn.up()).isAir()) continue;
            if (!world.getBlockState(spawn.down()).isSolidBlock(world, spawn.down())) continue;
            HollowWatcherEntity guard = HollowSignal.HOLLOW_WATCHER.create(world);
            if (guard == null) return;
            guard.refreshPositionAndAngles(spawn, world.getRandom().nextFloat() * 360.0f, 0.0f);
            guard.setTarget(player);
            world.spawnEntity(guard);
            return;
        }
    }

    private static void warn(ServerPlayerEntity player, int before, int now) {
        if (!HollowSignalConfig.warnings || event == NightEvent.DEAD_SILENCE) return;
        for (int step : new int[]{25, 50, 75}) {
            if (before < step && now >= step) {
                player.sendMessage(Text.translatable("message.hollow_signal.warning_" + step).formatted(Formatting.DARK_PURPLE), true);
                player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.AMBIENT, 0.55f, 0.7f);
            }
        }
    }

    private static void escalate(ServerPlayerEntity player, ServerWorld world, int before, int now) {
        var random = world.getRandom();
        if (event == NightEvent.ECHO_HUNT && now >= 35 && random.nextFloat() < 0.25f) {
            if (spawnNear(player, HollowSignal.HOLLOW_WATCHER)) spawnNear(player, HollowSignal.HOLLOW_WATCHER);
        }
        if (event == NightEvent.SIGNAL_STORM && now >= 40 && random.nextFloat() < 0.3f) {
            spawnNear(player, HollowSignal.DREAD_MOTH);
        }
        if (event == NightEvent.CONVERGENCE && now >= 60 && random.nextFloat() < 0.2f) {
            spawnNear(player, HollowSignal.NULL_CREEPER);
        }
        if (event == NightEvent.RED_ECLIPSE && now >= 35 && random.nextFloat() < 0.3f) {
            spawnNear(player, HollowSignal.NULL_CREEPER);
        }
        if (event == NightEvent.ECHO_BLOOM && now >= 35 && random.nextFloat() < 0.2f) {
            spawnNear(player, HollowSignal.DREAD_MOTH);
        }
        if (before < 50 && now >= 50 && spawnNear(player, HollowSignal.HOLLOW_WATCHER)) {
            player.sendMessage(Text.translatable("message.hollow_signal.watcher").formatted(Formatting.DARK_PURPLE), false);
        }
        int stalkerThreshold = event == NightEvent.DEAD_SILENCE ? 70 : 100;
        if (now < stalkerThreshold) return;
        if (spawnNear(player, HollowSignal.SIGNAL_STALKER)) {
            player.sendMessage(Text.translatable("message.hollow_signal.arrival").formatted(Formatting.DARK_RED), false);
            world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WARDEN_ROAR, SoundCategory.HOSTILE, 0.7f, 0.8f);
            EXPOSURE.put(player.getUuid(), 20);
        }
    }

    /** Summons the boss at an Echo Block; returns false when the ritual cannot run here. */
    public static boolean summonHerald(ServerWorld world, BlockPos pos, ServerPlayerEntity player) {
        if (!HollowSignalConfig.boss || !world.isNight()) return false;
        if (!world.getEntitiesByClass(HollowHeraldEntity.class, new net.minecraft.util.math.Box(pos).expand(64), e -> e.isAlive()).isEmpty()) return false;
        HollowHeraldEntity herald = HollowSignal.HOLLOW_HERALD.create(world);
        if (herald == null) return false;
        herald.refreshPositionAndAngles(pos.up(1), world.getRandom().nextFloat() * 360.0f, 0.0f);
        if (!world.isSpaceEmpty(herald)) return false;
        herald.setTarget(player);
        if (!world.spawnEntity(herald)) return false;
        world.spawnParticles(ParticleTypes.SCULK_SOUL, pos.getX() + 0.5, pos.getY() + 1.5, pos.getZ() + 0.5, 60, 1.0, 1.0, 1.0, 0.05);
        world.playSound(null, pos, SoundEvents.ENTITY_WARDEN_ROAR, SoundCategory.HOSTILE, 1.4f, 0.5f);
        broadcast(world.getServer(), Text.translatable("message.hollow_signal.herald_arrives").formatted(Formatting.DARK_RED),
            Text.translatable("message.hollow_signal.herald_subtitle").formatted(Formatting.GRAY), true);
        return true;
    }

    public static int dropBonus() { return event == NightEvent.ECHO_HUNT || event == NightEvent.ECHO_BLOOM ? 2 : 1; }

    public static boolean consumeTotem(LivingEntity entity) {
        if (!(entity instanceof ServerPlayerEntity player)) return false;
        for (net.minecraft.util.Hand hand : net.minecraft.util.Hand.values()) {
            if (!player.getStackInHand(hand).isOf(HollowSignal.ECHO_TOTEM)) continue;
            player.getStackInHand(hand).decrement(1);
            player.setHealth(player.getMaxHealth());
            player.clearStatusEffects();
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 1));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 400, 1));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 600, 0));
            clearExposure(player);
            player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ITEM_TOTEM_USE, SoundCategory.PLAYERS, 1.0f, 0.6f);
            player.getServerWorld().spawnParticles(ParticleTypes.SCULK_SOUL, player.getX(), player.getY() + 1.0, player.getZ(), 40, 0.6, 0.8, 0.6, 0.08);
            player.sendMessage(Text.translatable("message.hollow_signal.totem").formatted(Formatting.LIGHT_PURPLE), true);
            return true;
        }
        return false;
    }

    private static <T extends MobEntity> boolean spawnNear(ServerPlayerEntity player, EntityType<T> type) {
        ServerWorld world = player.getServerWorld();
        if (world.getEntitiesByClass(MobEntity.class, player.getBoundingBox().expand(32), e -> e.getType() == type).size() >= 3) return false;
        var random = world.getRandom();
        BlockPos origin = player.getBlockPos();
        boolean flying = type == HollowSignal.DREAD_MOTH;
        for (int attempt = 0; attempt < 40; attempt++) {
            int dx = random.nextBetween(-16, 16);
            int dz = random.nextBetween(-16, 16);
            if (dx * dx + dz * dz < 64) continue;
            BlockPos spot = origin.add(dx, flying ? random.nextBetween(4, 9) : random.nextBetween(-3, 3), dz);
            if (!world.getBlockState(spot).isAir() || !world.getBlockState(spot.up()).isAir()) continue;
            if (!flying && !world.getBlockState(spot.down()).isSolidBlock(world, spot.down())) continue;
            T mob = type.create(world);
            if (mob == null) return false;
            mob.refreshPositionAndAngles(spot, random.nextFloat() * 360.0f, 0.0f);
            mob.setTarget(player);
            if (event == NightEvent.DEAD_SILENCE || event == NightEvent.RED_ECLIPSE) {
                mob.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 6000, 0, true, false, false));
            }
            return world.spawnEntity(mob);
        }
        return false;
    }
}
