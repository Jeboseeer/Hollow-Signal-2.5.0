package dev.hollowsignal;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record ExposurePayload(int exposure, int event) implements CustomPayload {
    public static final CustomPayload.Id<ExposurePayload> ID =
        new CustomPayload.Id<>(Identifier.of(HollowSignal.MOD_ID, "exposure"));
    public static final PacketCodec<PacketByteBuf, ExposurePayload> CODEC = CustomPayload.codecOf(
        (value, buf) -> { buf.writeVarInt(value.exposure()); buf.writeVarInt(value.event()); },
        buf -> new ExposurePayload(buf.readVarInt(), buf.readVarInt()));

    @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}
