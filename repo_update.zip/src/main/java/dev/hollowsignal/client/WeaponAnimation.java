package dev.hollowsignal.client;

import dev.hollowsignal.HollowSignal;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

/** Short, item-specific first-person motion for successful weapon abilities. */
public final class WeaponAnimation {
    private static Hand activeHand;
    private static int activeKind;
    private static long started;

    private WeaponAnimation() {}

    public static void start(Hand hand, int kind) {
        activeHand = hand;
        activeKind = kind;
        started = System.nanoTime();
    }

    public static void apply(MatrixStack matrices, Hand hand, ItemStack stack) {
        if (hand != activeHand) return;
        int kind = stack.isOf(HollowSignal.ECHO_BLADE) ? 1 :
            stack.isOf(HollowSignal.SIGNAL_LANCE) ? 2 :
            stack.isOf(HollowSignal.RESONATOR) ? 3 : 0;
        if (kind == 0 || kind != activeKind) return;
        double duration = kind == 1 ? 0.38 : kind == 2 ? 0.32 : 0.28;
        double progress = (System.nanoTime() - started) / 1_000_000_000.0 / duration;
        if (progress < 0 || progress >= 1) return;
        float pulse = (float) Math.sin(Math.PI * progress);
        float side = hand == Hand.MAIN_HAND ? 1.0f : -1.0f;
        switch (kind) {
            case 1 -> { // Echo Blade: arc across the view after the blink.
                matrices.translate(-0.13f * side * pulse, 0.08f * pulse, -0.10f * pulse);
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-29.0f * side * pulse));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(17.0f * side * pulse));
            }
            case 2 -> { // Signal Lance: a forward thrust, then recovery.
                matrices.translate(0.04f * side * pulse, -0.07f * pulse, -0.42f * pulse);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-12.0f * pulse));
            }
            case 3 -> { // Resonator: kick back and settle.
                matrices.translate(0.05f * side * pulse, -0.035f * pulse, 0.24f * pulse);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(15.0f * pulse));
            }
            default -> {}
        }
    }
}
