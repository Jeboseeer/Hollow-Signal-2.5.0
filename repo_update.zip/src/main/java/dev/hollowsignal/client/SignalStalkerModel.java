package dev.hollowsignal.client;

import dev.hollowsignal.entity.SignalStalkerEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class SignalStalkerModel extends SinglePartEntityModel<SignalStalkerEntity> {
    private final ModelPart root, head, leftArm, rightArm, leftLeg, rightLeg, leftTendril, rightTendril;

    public SignalStalkerModel(ModelPart root) {
        this.root = root;
        head = root.getChild("head");
        leftArm = root.getChild("left_arm");
        rightArm = root.getChild("right_arm");
        leftLeg = root.getChild("left_leg");
        rightLeg = root.getChild("right_leg");
        leftTendril = root.getChild("left_tendril");
        rightTendril = root.getChild("right_tendril");
    }

    public static TexturedModelData textureData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData head = root.addChild("head", ModelPartBuilder.create()
            .uv(0,0).cuboid(-4,-8,-4,8,8,8)
            .uv(32,0).cuboid(-5,-9,-5,10,9,10)
            .uv(80,0).cuboid(-3,-5,-6,2,2,1)
            .uv(80,0).cuboid(1,-5,-6,2,2,1)
            .uv(88,0).cuboid(-2,-2,-6,4,1,1), ModelTransform.pivot(0,0,0));
        head.addChild("left_antenna", ModelPartBuilder.create().uv(96,0).cuboid(-4,-14,-1,1,6,1)
            .uv(108,0).cuboid(-5,-15,-2,3,2,3), ModelTransform.NONE);
        head.addChild("right_antenna", ModelPartBuilder.create().uv(96,0).cuboid(3,-14,-1,1,6,1)
            .uv(108,0).cuboid(2,-15,-2,3,2,3), ModelTransform.NONE);
        root.addChild("body", ModelPartBuilder.create()
            .uv(0,32).cuboid(-4,0,-2,8,12,4)
            .uv(32,32).cuboid(-6,0,-3,12,3,6)
            .uv(80,20).cuboid(-1,3,-3,2,4,1)
            .uv(88,20).cuboid(-4,5,-3,8,1,1)
            .uv(88,20).cuboid(-3,8,-3,6,1,1), ModelTransform.NONE);
        root.addChild("left_arm", ModelPartBuilder.create().uv(0,64).cuboid(0,-1,-2,3,15,4)
            .uv(96,20).cuboid(0,12,-2,3,3,4), ModelTransform.pivot(5,2,0));
        root.addChild("right_arm", ModelPartBuilder.create().uv(16,64).cuboid(-3,-1,-2,3,15,4)
            .uv(96,20).cuboid(-3,12,-2,3,3,4), ModelTransform.pivot(-5,2,0));
        root.addChild("left_leg", ModelPartBuilder.create().uv(32,64).cuboid(-1,0,-2,3,12,4)
            .uv(48,64).cuboid(-1,10,-4,3,2,6), ModelTransform.pivot(2,12,0));
        root.addChild("right_leg", ModelPartBuilder.create().uv(32,64).cuboid(-2,0,-2,3,12,4)
            .uv(48,64).cuboid(-2,10,-4,3,2,6), ModelTransform.pivot(-2,12,0));
        root.addChild("left_tendril", ModelPartBuilder.create().uv(72,64).cuboid(0,0,0,2,18,2),
            ModelTransform.of(3,2,2,0,0,-0.16f));
        root.addChild("right_tendril", ModelPartBuilder.create().uv(72,64).cuboid(-2,0,0,2,18,2),
            ModelTransform.of(-3,2,2,0,0,0.16f));
        return TexturedModelData.of(data,128,128);
    }

    @Override public ModelPart getPart() { return root; }

    @Override public void setAngles(SignalStalkerEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        head.yaw = headYaw * MathHelper.RADIANS_PER_DEGREE;
        head.pitch = headPitch * MathHelper.RADIANS_PER_DEGREE;
        float swing = MathHelper.cos(limbAngle * 0.6662f) * Math.min(limbDistance, 1f);
        leftArm.pitch = -swing * 0.8f - 0.18f;
        rightArm.pitch = swing * 0.8f - 0.18f;
        leftLeg.pitch = swing * 0.9f;
        rightLeg.pitch = -swing * 0.9f;
        leftTendril.roll = -0.16f + MathHelper.sin(animationProgress * 0.09f) * 0.09f;
        rightTendril.roll = 0.16f - MathHelper.sin(animationProgress * 0.09f) * 0.09f;
    }
}
