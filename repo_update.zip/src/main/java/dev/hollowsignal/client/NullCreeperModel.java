package dev.hollowsignal.client;

import dev.hollowsignal.entity.NullCreeperEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class NullCreeperModel extends SinglePartEntityModel<NullCreeperEntity> {
    private final ModelPart root, head, core;
    private final ModelPart[] legs = new ModelPart[4];

    public NullCreeperModel(ModelPart root) {
        this.root = root;
        head = root.getChild("head");
        core = root.getChild("body").getChild("core");
        for (int i = 0; i < 4; i++) legs[i] = root.getChild("leg_" + i);
    }

    public static TexturedModelData textureData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        ModelPartData head = root.addChild("head", ModelPartBuilder.create()
            .uv(0, 0).cuboid(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f)
            .uv(32, 0).cuboid(-3.0f, -9.0f, -2.0f, 6.0f, 3.0f, 7.0f)
            .uv(0, 18).cuboid(-3.0f, -6.0f, -5.0f, 2.0f, 2.0f, 1.0f)
            .uv(0, 18).cuboid(1.0f, -6.0f, -5.0f, 2.0f, 2.0f, 1.0f)
            .uv(10, 18).cuboid(-2.0f, -3.0f, -5.0f, 4.0f, 1.0f, 1.0f), ModelTransform.pivot(0.0f, 6.0f, 0.0f));
        head.addChild("vent", ModelPartBuilder.create()
            .uv(40, 14).cuboid(-1.0f, -12.0f, -1.0f, 2.0f, 4.0f, 2.0f), ModelTransform.NONE);
        ModelPartData body = root.addChild("body", ModelPartBuilder.create()
            .uv(0, 28).cuboid(-4.0f, 0.0f, -2.0f, 8.0f, 12.0f, 4.0f)
            .uv(28, 28).cuboid(-5.0f, 1.0f, -3.0f, 10.0f, 3.0f, 6.0f), ModelTransform.pivot(0.0f, 6.0f, 0.0f));
        body.addChild("core", ModelPartBuilder.create()
            .uv(0, 46).cuboid(-2.0f, -2.5f, -2.5f, 4.0f, 5.0f, 5.0f), ModelTransform.pivot(0.0f, 7.0f, 0.0f));
        int[][] offsets = {{-2, -4}, {2, -4}, {-2, 4}, {2, 4}};
        for (int i = 0; i < 4; i++) {
            root.addChild("leg_" + i, ModelPartBuilder.create()
                .uv(44, 28).cuboid(-2.0f, 0.0f, -2.0f, 4.0f, 6.0f, 4.0f)
                .uv(44, 40).cuboid(-2.0f, 5.0f, -3.0f, 4.0f, 1.0f, 5.0f),
                ModelTransform.pivot(offsets[i][0], 18.0f, offsets[i][1]));
        }
        return TexturedModelData.of(data, 64, 64);
    }

    @Override public ModelPart getPart() { return root; }

    @Override public void setAngles(NullCreeperEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        head.yaw = headYaw * MathHelper.RADIANS_PER_DEGREE;
        head.pitch = headPitch * MathHelper.RADIANS_PER_DEGREE;
        float swing = MathHelper.cos(limbAngle * 0.6662f) * 1.4f * Math.min(limbDistance, 1.0f);
        legs[0].pitch = swing;
        legs[1].pitch = -swing;
        legs[2].pitch = -swing;
        legs[3].pitch = swing;
        float fuse = entity.fuseProgress();
        core.xScale = core.yScale = core.zScale = 1.0f + fuse * 0.6f;
        head.pitch -= fuse * 0.25f;
    }
}
