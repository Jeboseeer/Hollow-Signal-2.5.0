package dev.hollowsignal.client;

import dev.hollowsignal.entity.HollowHeraldEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class HollowHeraldModel extends SinglePartEntityModel<HollowHeraldEntity> {
    private final ModelPart root, head, leftArm, rightArm, leftLeg, rightLeg, cloak;

    public HollowHeraldModel(ModelPart root) {
        this.root = root.getChild("figure");
        head = this.root.getChild("head");
        leftArm = this.root.getChild("left_arm");
        rightArm = this.root.getChild("right_arm");
        leftLeg = this.root.getChild("left_leg");
        rightLeg = this.root.getChild("right_leg");
        cloak = this.root.getChild("cloak");
    }

    public static TexturedModelData textureData() {
        ModelData data = new ModelData();
        // Keep the feet at Minecraft's 24-pixel ground baseline; renderer scaling
        // grows the body upward around that baseline.
        ModelPartData root = data.getRoot().addChild("figure", ModelPartBuilder.create(), ModelTransform.pivot(0.0f, 24.0f, 0.0f));
        ModelPartData head = root.addChild("head", ModelPartBuilder.create()
            .uv(0, 0).cuboid(-5.0f, -10.0f, -5.0f, 10.0f, 10.0f, 10.0f)
            .uv(40, 0).cuboid(-6.0f, -11.0f, -6.0f, 12.0f, 4.0f, 12.0f)
            .uv(0, 20).cuboid(-4.0f, -6.0f, -6.0f, 2.0f, 2.0f, 1.0f)
            .uv(0, 20).cuboid(2.0f, -6.0f, -6.0f, 2.0f, 2.0f, 1.0f)
            .uv(10, 20).cuboid(-3.0f, -2.0f, -6.0f, 6.0f, 1.0f, 1.0f)
            .uv(40, 0).cuboid(-6.0f, -7.0f, -5.0f, 1.0f, 6.0f, 5.0f)
            .uv(40, 0).cuboid(5.0f, -7.0f, -5.0f, 1.0f, 6.0f, 5.0f)
            .uv(0, 20).cuboid(-1.0f, -10.0f, -7.0f, 2.0f, 3.0f, 1.0f), ModelTransform.pivot(0.0f, -12.0f, 0.0f));
        head.addChild("left_horn", ModelPartBuilder.create()
            .uv(80, 0).cuboid(3.0f, -20.0f, -2.0f, 2.0f, 10.0f, 2.0f)
            .uv(90, 0).cuboid(5.0f, -22.0f, -2.0f, 2.0f, 4.0f, 2.0f), ModelTransform.NONE);
        head.addChild("right_horn", ModelPartBuilder.create()
            .uv(80, 0).cuboid(-5.0f, -20.0f, -2.0f, 2.0f, 10.0f, 2.0f)
            .uv(90, 0).cuboid(-7.0f, -22.0f, -2.0f, 2.0f, 4.0f, 2.0f), ModelTransform.NONE);
        root.addChild("body", ModelPartBuilder.create()
            .uv(0, 40).cuboid(-7.0f, -12.0f, -4.0f, 14.0f, 20.0f, 8.0f)
            .uv(60, 40).cuboid(-9.0f, -13.0f, -5.0f, 18.0f, 5.0f, 10.0f)
            .uv(0, 24).cuboid(-2.0f, -6.0f, -5.0f, 4.0f, 6.0f, 1.0f)
            .uv(60, 40).cuboid(-6.0f, -10.0f, -5.0f, 12.0f, 2.0f, 1.0f)
            .uv(60, 40).cuboid(-6.0f, -3.0f, -5.0f, 12.0f, 2.0f, 1.0f)
            .uv(0, 40).cuboid(-7.5f, 1.0f, -4.5f, 15.0f, 3.0f, 9.0f), ModelTransform.pivot(0.0f, -12.0f, 0.0f));
        root.addChild("left_shoulder_spike", ModelPartBuilder.create()
            .uv(80, 0).cuboid(0.0f, -9.0f, -2.0f, 3.0f, 10.0f, 4.0f), ModelTransform.of(9.0f, -24.0f, 0.0f, 0.0f, 0.0f, -0.35f));
        root.addChild("right_shoulder_spike", ModelPartBuilder.create()
            .uv(80, 0).cuboid(-3.0f, -9.0f, -2.0f, 3.0f, 10.0f, 4.0f), ModelTransform.of(-9.0f, -24.0f, 0.0f, 0.0f, 0.0f, 0.35f));
        root.addChild("cloak", ModelPartBuilder.create()
            .uv(60, 56).cuboid(-8.0f, 0.0f, 0.0f, 16.0f, 22.0f, 2.0f)
            .uv(60, 56).cuboid(-8.0f, 20.0f, 0.0f, 5.0f, 8.0f, 2.0f)
            .uv(60, 56).cuboid(3.0f, 20.0f, 0.0f, 5.0f, 8.0f, 2.0f), ModelTransform.pivot(0.0f, -24.0f, 4.0f));
        root.addChild("left_arm", ModelPartBuilder.create()
            .uv(96, 40).cuboid(0.0f, -2.0f, -3.0f, 5.0f, 22.0f, 5.0f)
            .uv(96, 40).cuboid(-0.5f, 11.0f, -3.5f, 6.0f, 4.0f, 6.0f)
            .uv(96, 68).cuboid(1.0f, 19.0f, -3.0f, 2.0f, 6.0f, 1.0f)
            .uv(96, 68).cuboid(1.0f, 19.0f, 1.0f, 2.0f, 6.0f, 1.0f), ModelTransform.pivot(7.0f, -22.0f, 0.0f));
        root.addChild("right_arm", ModelPartBuilder.create()
            .uv(96, 40).cuboid(-5.0f, -2.0f, -3.0f, 5.0f, 22.0f, 5.0f)
            .uv(96, 40).cuboid(-5.5f, 11.0f, -3.5f, 6.0f, 4.0f, 6.0f)
            .uv(104, 68).cuboid(-3.0f, 19.0f, -3.0f, 2.0f, 6.0f, 1.0f)
            .uv(104, 68).cuboid(-3.0f, 19.0f, 1.0f, 2.0f, 6.0f, 1.0f), ModelTransform.pivot(-7.0f, -22.0f, 0.0f));
        root.addChild("left_leg", ModelPartBuilder.create()
            .uv(32, 88).cuboid(-2.5f, 0.0f, -3.0f, 5.0f, 16.0f, 5.0f)
            .uv(32, 88).cuboid(-3.0f, 6.0f, -3.5f, 6.0f, 4.0f, 6.0f)
            .uv(56, 88).cuboid(-2.5f, 14.0f, -5.0f, 5.0f, 2.0f, 7.0f), ModelTransform.pivot(3.5f, -16.0f, 0.0f));
        root.addChild("right_leg", ModelPartBuilder.create()
            .uv(32, 88).cuboid(-2.5f, 0.0f, -3.0f, 5.0f, 16.0f, 5.0f)
            .uv(32, 88).cuboid(-3.0f, 6.0f, -3.5f, 6.0f, 4.0f, 6.0f)
            .uv(56, 88).cuboid(-2.5f, 14.0f, -5.0f, 5.0f, 2.0f, 7.0f), ModelTransform.pivot(-3.5f, -16.0f, 0.0f));
        return TexturedModelData.of(data, 128, 128);
    }

    @Override public ModelPart getPart() { return root; }

    @Override public void setAngles(HollowHeraldEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        head.yaw = headYaw * MathHelper.RADIANS_PER_DEGREE;
        head.pitch = headPitch * MathHelper.RADIANS_PER_DEGREE;
        float swing = MathHelper.cos(limbAngle * 0.5f) * Math.min(limbDistance, 1.0f);
        leftArm.pitch = -swing * 0.7f - 0.1f;
        rightArm.pitch = swing * 0.7f - 0.1f;
        leftArm.roll = 0.08f + MathHelper.sin(animationProgress * 0.05f) * 0.04f;
        rightArm.roll = -0.08f - MathHelper.sin(animationProgress * 0.05f) * 0.04f;
        leftLeg.pitch = swing * 0.8f;
        rightLeg.pitch = -swing * 0.8f;
        cloak.pitch = 0.06f + MathHelper.sin(animationProgress * 0.06f) * 0.05f + Math.min(limbDistance, 1.0f) * 0.1f;
    }
}
