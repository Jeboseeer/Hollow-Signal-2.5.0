package dev.hollowsignal.client;

import dev.hollowsignal.NightEvent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.text.OrderedText;
import java.util.List;

/** Draws the exposure meter and the current night event in the lower left corner. */
public final class ExposureHud {
    private static final int WIDTH = 62;
    private static final int HEIGHT = 5;
    private static int exposure;
    private static NightEvent event = NightEvent.CALM;
    private static float shown;
    private static long bannerStarted;

    private ExposureHud() {}

    public static void update(int value, int eventOrdinal) {
        exposure = Math.max(0, Math.min(100, value));
        NightEvent[] all = NightEvent.values();
        NightEvent next = eventOrdinal >= 0 && eventOrdinal < all.length ? all[eventOrdinal] : NightEvent.CALM;
        if (next != event && next != NightEvent.CALM) bannerStarted = System.currentTimeMillis();
        event = next;
    }

    public static void render(DrawContext context, RenderTickCounter counter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden || client.player.isSpectator()) return;
        shown += (exposure - shown) * 0.12f;
        renderVignette(context, client);
        renderEventBanner(context, client);
        if (shown < 0.5f && event == NightEvent.CALM) return;
        int x = 8;
        int y = context.getScaledWindowHeight() - 34;
        context.fill(x - 1, y - 1, x + WIDTH + 1, y + HEIGHT + 1, 0x88000000);
        context.fill(x, y, x + WIDTH, y + HEIGHT, 0xFF14101F);
        int filled = Math.round(WIDTH * Math.min(1.0f, shown / 100.0f));
        if (filled > 0) context.fill(x, y, x + filled, y + HEIGHT, color());
        if (event != NightEvent.CALM) {
            int titleColor = event == NightEvent.RED_ECLIPSE ? 0xE8616A :
                event == NightEvent.ECHO_BLOOM ? 0x77E7E9 : 0xC9A6FF;
            context.drawTextWithShadow(client.textRenderer, Text.translatable(event.titleKey()), x, y - 11, titleColor);
        }
        if (shown >= 0.5f) {
            context.drawTextWithShadow(client.textRenderer, Text.literal(Math.round(shown) + "%"), x + WIDTH + 5, y - 1, 0x9C8AB8);
        }
    }

    private static void renderEventBanner(DrawContext context, MinecraftClient client) {
        if (event == NightEvent.CALM) return;
        long age = System.currentTimeMillis() - bannerStarted;
        if (age < 0 || age > 5000) return;
        int width = Math.min(300, context.getScaledWindowWidth() - 16);
        if (width < 100) return;
        int x = (context.getScaledWindowWidth() - width) / 2;
        int y = 8;
        List<OrderedText> lines = client.textRenderer.wrapLines(Text.translatable(event.descriptionKey()), width - 22);
        int visibleLines = Math.min(2, lines.size());
        int height = 20 + visibleLines * 10;
        float fade = Math.min(1.0f, Math.min(age / 250.0f, (5000 - age) / 450.0f));
        int alpha = Math.max(0, Math.min(255, Math.round(205 * fade)));
        int accent = event == NightEvent.RED_ECLIPSE ? 0xE8616A :
            event == NightEvent.ECHO_BLOOM ? 0x77E7E9 : 0xC9A6FF;
        context.fill(x, y, x + width, y + height, (alpha << 24) | 0x100D1B);
        context.fill(x, y, x + 2, y + height, (Math.min(255, alpha + 25) << 24) | accent);
        context.drawCenteredTextWithShadow(client.textRenderer, Text.translatable(event.titleKey()),
            x + width / 2, y + 5, (Math.min(255, alpha + 35) << 24) | accent);
        for (int i = 0; i < visibleLines; i++) {
            OrderedText line = lines.get(i);
            context.drawTextWithShadow(client.textRenderer, line,
                x + (width - client.textRenderer.getWidth(line)) / 2, y + 18 + i * 10,
                (Math.min(255, alpha + 20) << 24) | 0xC7BED7);
        }
    }

    private static void renderVignette(DrawContext context, MinecraftClient client) {
        int threat = Math.round(shown);
        if (event == NightEvent.RED_ECLIPSE || event == NightEvent.ECHO_BLOOM) threat = Math.max(threat, 60);
        else if (event != NightEvent.CALM) threat = Math.max(threat, 27);
        if (threat < 25) return;

        int width = context.getScaledWindowWidth();
        int height = context.getScaledWindowHeight();
        float pulse = 0.92f + 0.08f * (float) Math.sin(System.currentTimeMillis() / 620.0);
        int alpha = Math.min(74, Math.round((14 + (threat - 25) * 0.8f) * pulse));
        if (event == NightEvent.DEAD_SILENCE) alpha = Math.min(82, alpha + 8);
        int band = Math.max(7, Math.min(width, height) / 45);
        for (int layer = 0; layer < 5; layer++) {
            int inset = layer * band;
            int layerAlpha = alpha * (5 - layer) /
                (event == NightEvent.RED_ECLIPSE || event == NightEvent.ECHO_BLOOM ? 6 : 12);
            int shade = (layerAlpha << 24) | (event == NightEvent.RED_ECLIPSE ? 0x32070E :
                event == NightEvent.ECHO_BLOOM ? 0x063039 : 0x1A0928);
            context.fill(inset, inset, width - inset, inset + band, shade);
            context.fill(inset, height - inset - band, width - inset, height - inset, shade);
            context.fill(inset, inset + band, inset + band, height - inset - band, shade);
            context.fill(width - inset - band, inset + band, width - inset, height - inset - band, shade);
        }
    }

    private static int color() {
        if (exposure >= 75) return 0xFFD4425E;
        if (exposure >= 50) return 0xFFB45BE0;
        if (exposure >= 25) return 0xFF7E5BD0;
        return 0xFF4E6BC4;
    }
}
