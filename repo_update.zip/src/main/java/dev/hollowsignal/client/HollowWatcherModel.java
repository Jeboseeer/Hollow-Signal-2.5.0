package dev.hollowsignal.client;

import dev.hollowsignal.entity.HollowWatcherEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class HollowWatcherModel extends SinglePartEntityModel<HollowWatcherEntity> {
    private final ModelPart root, head, abdomen;
    private final ModelPart[] leftLegs = new ModelPart[4], rightLegs = new ModelPart[4];

    public HollowWatcherModel(ModelPart root) {
        this.root = root;
        head = root.getChild("head");
        abdomen = root.getChild("abdomen");
        for (int i=0; i<4; i++) {
            leftLegs[i] = root.getChild("left_leg_" + i);
            rightLegs[i] = root.getChild("right_leg_" + i);
        }
    }

    public static TexturedModelData textureData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        root.addChild("head", ModelPartBuilder.create()
            .uv(0,0).cuboid(-4,-3,-5,8,6,7)
            .uv(104,0).cuboid(-3,-1,-6,2,2,1)
            .uv(104,0).cuboid(1,-1,-6,2,2,1)
            .uv(104,0).cuboid(-3,-4,-4,2,1,2)
            .uv(104,0).cuboid(1,-4,-4,2,1,2)
            .uv(112,0).cuboid(-2,1,-7,1,3,2)
            .uv(112,0).cuboid(1,1,-7,1,3,2), ModelTransform.pivot(0,16,-3));
        root.addChild("thorax", ModelPartBuilder.create().uv(32,0).cuboid(-4,-3,-4,8,6,8)
            .uv(80,0).cuboid(-3,-4,-2,6,1,6), ModelTransform.pivot(0,15,2));
        root.addChild("abdomen", ModelPartBuilder.create().uv(0,32).cuboid(-6,-4,-5,12,8,11)
            .uv(52,32).cuboid(-4,-5,-3,8,1,7), ModelTransform.pivot(0,14,8));
        for (int i=0; i<4; i++) {
            float z = -3 + i*4;
            ModelPartData left = root.addChild("left_leg_"+i, ModelPartBuilder.create().uv(0,64).cuboid(0,-1,-1,11,2,2)
                .uv(32,64).cuboid(9,-1,-2,3,3,4), ModelTransform.pivot(4,17,z));
            left.addChild("lower", ModelPartBuilder.create().uv(48,64).cuboid(-1,0,-1,2,7,2)
                .uv(60,64).cuboid(-1,6,-2,2,2,4), ModelTransform.pivot(11,0,0));
            ModelPartData right = root.addChild("right_leg_"+i, ModelPartBuilder.create().uv(0,64).cuboid(-11,-1,-1,11,2,2)
                .uv(32,64).cuboid(-12,-1,-2,3,3,4), ModelTransform.pivot(-4,17,z));
            right.addChild("lower", ModelPartBuilder.create().uv(48,64).cuboid(-1,0,-1,2,7,2)
                .uv(60,64).cuboid(-1,6,-2,2,2,4), ModelTransform.pivot(-11,0,0));
        }
        return TexturedModelData.of(data,128,96);
    }

    @Override public ModelPart getPart() { return root; }

    @Override public void setAngles(HollowWatcherEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        head.yaw = headYaw * MathHelper.RADIANS_PER_DEGREE * 0.5f;
        abdomen.pitch = MathHelper.sin(animationProgress*0.08f)*0.04f;
        for (int i=0; i<4; i++) {
            float stagger = i%2==0 ? 0 : MathHelper.PI;
            float step = MathHelper.cos(limbAngle*0.6662f + stagger) * Math.min(limbDistance,1f)*0.3f;
            leftLegs[i].roll = 0.22f + step;
            rightLegs[i].roll = -0.22f - step;
            leftLegs[i].yaw = (1.5f-i)*0.75f;
            rightLegs[i].yaw = -(1.5f-i)*0.75f;
        }
    }
}
