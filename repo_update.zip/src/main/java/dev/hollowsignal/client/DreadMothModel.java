package dev.hollowsignal.client;

import dev.hollowsignal.entity.DreadMothEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class DreadMothModel extends SinglePartEntityModel<DreadMothEntity> {
    private final ModelPart root, head, tail;
    private final ModelPart leftWing, leftWingTip, rightWing, rightWingTip;
    private final ModelPart leftAntenna, rightAntenna;

    public DreadMothModel(ModelPart root) {
        this.root = root.getChild("moth");
        head = this.root.getChild("head");
        tail = this.root.getChild("tail");
        leftWing = this.root.getChild("left_wing");
        leftWingTip = leftWing.getChild("tip");
        rightWing = this.root.getChild("right_wing");
        rightWingTip = rightWing.getChild("tip");
        leftAntenna = head.getChild("left_antenna");
        rightAntenna = head.getChild("right_antenna");
    }

    public static TexturedModelData textureData() {
        ModelData data = new ModelData();
        // Entity models are rendered from a 24-pixel ground baseline. Keep the
        // flying body's center inside its one-block-tall targeting box.
        ModelPartData root = data.getRoot().addChild("moth", ModelPartBuilder.create(), ModelTransform.pivot(0, 17, 0));
        ModelPartData body = root.addChild("body", ModelPartBuilder.create()
            .uv(0, 0).cuboid(-3.0f, -2.0f, -4.0f, 6.0f, 4.0f, 9.0f)
            .uv(0, 14).cuboid(-2.0f, -3.0f, -2.0f, 4.0f, 1.0f, 6.0f), ModelTransform.NONE);
        ModelPartData head = root.addChild("head", ModelPartBuilder.create()
            .uv(30, 0).cuboid(-2.5f, -2.0f, -4.0f, 5.0f, 4.0f, 4.0f)
            .uv(30, 9).cuboid(-1.5f, -1.0f, -5.0f, 3.0f, 2.0f, 1.0f), ModelTransform.pivot(0.0f, 0.0f, -4.0f));
        head.addChild("left_antenna", ModelPartBuilder.create()
            .uv(48, 0).cuboid(0.0f, -6.0f, -1.0f, 1.0f, 6.0f, 1.0f), ModelTransform.of(1.5f, -1.5f, -3.0f, 0.0f, 0.0f, -0.35f));
        head.addChild("right_antenna", ModelPartBuilder.create()
            .uv(48, 0).cuboid(-1.0f, -6.0f, -1.0f, 1.0f, 6.0f, 1.0f), ModelTransform.of(-1.5f, -1.5f, -3.0f, 0.0f, 0.0f, 0.35f));
        root.addChild("tail", ModelPartBuilder.create()
            .uv(0, 22).cuboid(-2.0f, -1.5f, 0.0f, 4.0f, 3.0f, 7.0f)
            .uv(22, 22).cuboid(-1.0f, -0.5f, 6.0f, 2.0f, 1.0f, 5.0f), ModelTransform.pivot(0.0f, 0.0f, 5.0f));
        ModelPartData leftWing = root.addChild("left_wing", ModelPartBuilder.create()
            .uv(0, 34).cuboid(0.0f, 0.0f, -4.0f, 9.0f, 1.0f, 9.0f), ModelTransform.pivot(2.5f, -1.5f, -1.0f));
        leftWing.addChild("tip", ModelPartBuilder.create()
            .uv(0, 46).cuboid(0.0f, 0.0f, -3.0f, 7.0f, 1.0f, 7.0f), ModelTransform.pivot(9.0f, 0.0f, 0.0f));
        ModelPartData rightWing = root.addChild("right_wing", ModelPartBuilder.create()
            .uv(0, 34).cuboid(-9.0f, 0.0f, -4.0f, 9.0f, 1.0f, 9.0f), ModelTransform.pivot(-2.5f, -1.5f, -1.0f));
        rightWing.addChild("tip", ModelPartBuilder.create()
            .uv(0, 46).cuboid(-7.0f, 0.0f, -3.0f, 7.0f, 1.0f, 7.0f), ModelTransform.pivot(-9.0f, 0.0f, 0.0f));
        body.addChild("left_leg", ModelPartBuilder.create()
            .uv(40, 22).cuboid(0.0f, 0.0f, -1.0f, 1.0f, 5.0f, 1.0f), ModelTransform.of(2.5f, 1.5f, 0.0f, 0.0f, 0.0f, -0.5f));
        body.addChild("right_leg", ModelPartBuilder.create()
            .uv(40, 22).cuboid(-1.0f, 0.0f, -1.0f, 1.0f, 5.0f, 1.0f), ModelTransform.of(-2.5f, 1.5f, 0.0f, 0.0f, 0.0f, 0.5f));
        return TexturedModelData.of(data, 64, 64);
    }

    @Override public ModelPart getPart() { return root; }

    @Override public void setAngles(DreadMothEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        float flap = MathHelper.sin(animationProgress * 0.45f);
        leftWing.roll = -0.15f - flap * 0.7f;
        rightWing.roll = 0.15f + flap * 0.7f;
        leftWingTip.roll = -flap * 0.5f;
        rightWingTip.roll = flap * 0.5f;
        leftWing.yaw = 0.1f + flap * 0.08f;
        rightWing.yaw = -0.1f - flap * 0.08f;
        head.pitch = headPitch * MathHelper.RADIANS_PER_DEGREE * 0.6f + 0.1f;
        head.yaw = headYaw * MathHelper.RADIANS_PER_DEGREE * 0.6f;
        tail.pitch = MathHelper.sin(animationProgress * 0.12f) * 0.12f;
        leftAntenna.pitch = MathHelper.sin(animationProgress * 0.2f) * 0.15f;
        rightAntenna.pitch = -MathHelper.sin(animationProgress * 0.2f) * 0.15f;
    }
}
