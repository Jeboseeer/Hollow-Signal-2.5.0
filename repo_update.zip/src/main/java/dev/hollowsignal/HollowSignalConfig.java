package dev.hollowsignal;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class HollowSignalConfig {
    public static double exposureRate = 1.0;
    public static boolean events = true;
    public static boolean spawns = true;
    public static boolean boss = true;
    public static boolean hud = true;
    public static boolean warnings = true;
    public static int beaconRadius = 8;

    private HollowSignalConfig() {}

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("hollow_signal.properties");
        Properties props = new Properties();
        if (Files.exists(file)) {
            try (var in = Files.newInputStream(file)) { props.load(in); } catch (IOException ignored) {}
            exposureRate = Math.max(0.1, Math.min(5.0, number(props, "exposure_rate", exposureRate)));
            events = flag(props, "night_events", events);
            spawns = flag(props, "signal_spawns", spawns);
            boss = flag(props, "herald_ritual", boss);
            hud = flag(props, "exposure_hud", hud);
            warnings = flag(props, "warning_messages", warnings);
            beaconRadius = (int) Math.max(4, Math.min(48, number(props, "beacon_radius", beaconRadius)));
        }
        save(file);
    }

    private static boolean flag(Properties props, String key, boolean fallback) {
        String value = props.getProperty(key);
        return value == null ? fallback : Boolean.parseBoolean(value.trim());
    }

    private static double number(Properties props, String key, double fallback) {
        try { return Double.parseDouble(props.getProperty(key, String.valueOf(fallback)).trim()); }
        catch (NumberFormatException e) { return fallback; }
    }

    private static void save(Path file) {
        String text = """
            # Hollow Signal configuration
            # exposure_rate: how fast darkness exposure builds (0.1 - 5.0)
            exposure_rate=%s
            # night_events: enable the random night events
            night_events=%s
            # signal_spawns: enable exposure driven mob spawns
            signal_spawns=%s
            # herald_ritual: enable summoning the Hollow Herald from an Echo Block
            herald_ritual=%s
            # exposure_hud: draw the exposure meter on the client HUD
            exposure_hud=%s
            # warning_messages: send action bar warnings while exposure rises
            warning_messages=%s
            # beacon_radius: base horizontal radius of a Ward Beacon
            beacon_radius=%s
            """.formatted(exposureRate, events, spawns, boss, hud, warnings, beaconRadius);
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, text);
        } catch (IOException ignored) {}
    }
}
