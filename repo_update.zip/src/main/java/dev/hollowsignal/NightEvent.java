package dev.hollowsignal;

import net.minecraft.util.math.random.Random;

public enum NightEvent {
    CALM("calm", 0),
    SIGNAL_STORM("signal_storm", 6),
    DEAD_SILENCE("dead_silence", 5),
    ECHO_HUNT("echo_hunt", 5),
    CONVERGENCE("convergence", 3),
    RED_ECLIPSE("red_eclipse", 3),
    ECHO_BLOOM("echo_bloom", 4);

    public final String id;
    public final int weight;

    NightEvent(String id, int weight) { this.id = id; this.weight = weight; }

    public String titleKey() { return "event.hollow_signal." + id; }
    public String descriptionKey() { return "event.hollow_signal." + id + ".description"; }

    public static NightEvent roll(Random random) {
        int total = 0;
        for (NightEvent event : values()) total += event.weight;
        int pick = random.nextInt(total + 9);
        for (NightEvent event : values()) {
            pick -= event.weight;
            if (pick < 0) return event;
        }
        return CALM;
    }
}
