package dev.hollowsignal.block;

import com.mojang.serialization.MapCodec;
import dev.hollowsignal.HollowSignal;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class WardBeaconBlock extends Block implements BlockEntityProvider {
    public static final MapCodec<WardBeaconBlock> CODEC = createCodec(WardBeaconBlock::new);
    public static final BooleanProperty LIT = Properties.LIT;

    public WardBeaconBlock(Settings settings) {
        super(settings);
        setDefaultState(getDefaultState().with(LIT, false));
    }

    @Override protected MapCodec<? extends Block> getCodec() { return CODEC; }

    @Override protected void appendProperties(StateManager.Builder<Block, BlockState> builder) { builder.add(LIT); }

    @Override public BlockEntity createBlockEntity(BlockPos pos, BlockState state) { return new WardBeaconBlockEntity(pos, state); }

    @Override public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        if (world.isClient) return null;
        return type == HollowSignal.WARD_BEACON_ENTITY ? (w, pos, s, be) -> ((WardBeaconBlockEntity) be).serverTick(w, pos, s) : null;
    }

    @Override protected ItemActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        boolean handled = stack.isOf(HollowSignal.ECHO_SHARD) || stack.isOf(HollowSignal.ECHO_HEART);
        if (!handled) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (world.isClient) return ItemActionResult.SUCCESS;
        if (!(world.getBlockEntity(pos) instanceof WardBeaconBlockEntity beacon)) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (stack.isOf(HollowSignal.ECHO_HEART)) {
            if (beacon.isEternal()) {
                player.sendMessage(beacon.statusText(), true);
                return ItemActionResult.SUCCESS;
            }
            beacon.makeEternal();
            if (!player.getAbilities().creativeMode) stack.decrement(1);
            world.playSound(null, pos, SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.BLOCKS, 1.0f, 0.8f);
            player.sendMessage(Text.translatable("message.hollow_signal.beacon_eternal"), true);
            return ItemActionResult.SUCCESS;
        }
        if (!beacon.addFuel(1)) {
            player.sendMessage(Text.translatable("message.hollow_signal.beacon_full"), true);
            return ItemActionResult.SUCCESS;
        }
        if (!player.getAbilities().creativeMode) stack.decrement(1);
        world.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 0.8f, 1.2f);
        player.sendMessage(Text.translatable("message.hollow_signal.beacon_fuel", beacon.getFuel(), WardBeaconBlockEntity.MAX_FUEL), true);
        return ItemActionResult.SUCCESS;
    }

    @Override protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!world.isClient && world.getBlockEntity(pos) instanceof WardBeaconBlockEntity beacon) {
            player.sendMessage(beacon.statusText(), true);
        }
        return ActionResult.success(world.isClient);
    }
}
