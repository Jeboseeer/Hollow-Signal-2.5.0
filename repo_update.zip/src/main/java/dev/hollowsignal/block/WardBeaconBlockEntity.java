package dev.hollowsignal.block;

import dev.hollowsignal.HollowSignal;
import dev.hollowsignal.HollowSignalConfig;
import dev.hollowsignal.SignalManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class WardBeaconBlockEntity extends BlockEntity {
    public static final int MAX_FUEL = 8;
    private static final int FUEL_INTERVAL = 2400;
    private int fuel;
    private int tier;
    private boolean eternal;
    private int burnTimer;

    public WardBeaconBlockEntity(BlockPos pos, BlockState state) { super(HollowSignal.WARD_BEACON_ENTITY, pos, state); }

    public int getFuel() { return fuel; }
    public int getTier() { return tier; }
    public boolean isEternal() { return eternal; }
    public boolean isActive() { return eternal || fuel > 0; }
    public int radius() { return HollowSignalConfig.beaconRadius + tier * 6; }

    public boolean addFuel(int amount) {
        if (fuel >= MAX_FUEL) return false;
        fuel = Math.min(MAX_FUEL, fuel + amount);
        markDirty();
        return true;
    }

    public void makeEternal() {
        eternal = true;
        fuel = MAX_FUEL;
        markDirty();
    }

    public Text statusText() {
        if (!isActive()) return Text.translatable("message.hollow_signal.beacon_dormant");
        return Text.translatable("message.hollow_signal.beacon_status", tier, radius(),
            eternal ? Text.translatable("message.hollow_signal.beacon_infinite") : Text.literal(fuel + "/" + MAX_FUEL));
    }

    public void serverTick(World world, BlockPos pos, BlockState state) {
        if (world.getTime() % 20 != 0) return;
        int found = 0;
        for (int depth = 1; depth <= 3; depth++) {
            if (world.getBlockState(pos.down(depth)).isOf(HollowSignal.ECHO_BLOCK)) found++;
            else break;
        }
        if (found != tier) { tier = found; markDirty(); }
        boolean active = isActive();
        if (state.get(WardBeaconBlock.LIT) != active) world.setBlockState(pos, state.with(WardBeaconBlock.LIT, active), 3);
        if (!active) return;
        SignalManager.registerWard(world, pos, radius());
        int reach = radius();
        Box box = new Box(pos).expand(reach, Math.max(4, reach / 2.0), reach);
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, box, p -> !p.isSpectator())) {
            if (tier >= 1) player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, true, false, true));
            if (tier >= 2) player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 60, 0, true, false, true));
        }
        for (LivingEntity mob : world.getEntitiesByClass(LivingEntity.class, box, HollowSignal::isHollowMob)) {
            if (world instanceof ServerWorld server && world.getTime() % 40 == 0) {
                server.spawnParticles(ParticleTypes.END_ROD, mob.getX(), mob.getBodyY(0.8), mob.getZ(), 2, 0.25, 0.2, 0.25, 0.0);
            }
            if (tier >= 3) mob.damage(world.getDamageSources().magic(), 2.0f);
        }
        if (world instanceof ServerWorld server) {
            server.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 3, 0.25, 0.2, 0.25, 0.01);
            if (tier > 0) server.spawnParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + 1.4, pos.getZ() + 0.5, tier, 0.4, 0.4, 0.4, 0.02);
            if (world.getTime() % 200 == 0) world.playSound(null, pos, SoundEvents.BLOCK_BEACON_AMBIENT, SoundCategory.BLOCKS, 0.35f, 1.6f);
        }
        if (eternal || !world.isNight()) return;
        burnTimer += 20;
        if (burnTimer >= FUEL_INTERVAL) {
            burnTimer = 0;
            fuel = Math.max(0, fuel - 1);
            markDirty();
            if (fuel == 0) world.playSound(null, pos, SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.BLOCKS, 0.7f, 1.4f);
        }
    }

    @Override protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.readNbt(nbt, lookup);
        fuel = nbt.getInt("Fuel");
        tier = nbt.getInt("Tier");
        eternal = nbt.getBoolean("Eternal");
        burnTimer = nbt.getInt("BurnTimer");
    }

    @Override protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.writeNbt(nbt, lookup);
        nbt.putInt("Fuel", fuel);
        nbt.putInt("Tier", tier);
        nbt.putBoolean("Eternal", eternal);
        nbt.putInt("BurnTimer", burnTimer);
    }
}
