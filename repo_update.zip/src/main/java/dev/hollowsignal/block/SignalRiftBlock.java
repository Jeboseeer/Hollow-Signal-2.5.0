package dev.hollowsignal.block;

import com.mojang.serialization.MapCodec;
import dev.hollowsignal.HollowSignal;
import dev.hollowsignal.SignalManager;
import dev.hollowsignal.NightEvent;
import dev.hollowsignal.HollowSignalConfig;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/** A naturally appearing encounter that can be sealed with an Echo Shard. */
public class SignalRiftBlock extends Block {
    public static final MapCodec<SignalRiftBlock> CODEC = createCodec(SignalRiftBlock::new);
    public static final IntProperty PHASE = IntProperty.of("phase", 0, 3);

    public SignalRiftBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(PHASE, 0));
    }

    @Override protected MapCodec<? extends Block> getCodec() { return CODEC; }

    @Override protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(PHASE);
    }

    @Override protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
        super.onBlockAdded(state, world, pos, oldState, notify);
        if (!world.isClient && !oldState.isOf(this)) world.scheduleBlockTick(pos, this, 120);
    }

    @Override protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (!world.isNight() || !HollowSignalConfig.spawns) {
            world.scheduleBlockTick(pos, this, 200);
            return;
        }
        ServerPlayerEntity target = null;
        double nearest = 24.0 * 24.0;
        for (ServerPlayerEntity player : world.getPlayers()) {
            if (!player.isAlive() || player.isCreative() || player.isSpectator()) continue;
            double distance = player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (distance < nearest) { nearest = distance; target = player; }
        }
        if (target == null) {
            world.scheduleBlockTick(pos, this, 120);
            return;
        }
        int phase = Math.min(3, state.get(PHASE) + 1);
        world.setBlockState(pos, state.with(PHASE, phase), Block.NOTIFY_LISTENERS);
        SignalManager.spawnRiftWave(world, pos, target, phase);
        String warning = switch (phase) {
            case 1 -> "message.hollow_signal.rift_phase_1";
            case 2 -> "message.hollow_signal.rift_phase_2";
            default -> "message.hollow_signal.rift_phase_3";
        };
        for (ServerPlayerEntity player : world.getPlayers()) {
            double distance = player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (distance > 24.0 * 24.0 || player.isSpectator()) continue;
            player.sendMessage(Text.translatable(warning), true);
            if (distance <= 8.0 * 8.0 && !player.isCreative()) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50 + phase * 10, 0));
                if (phase >= 2 && distance <= 4.0 * 4.0) {
                    player.damage(world.getDamageSources().magic(), phase == 3 ? 3.0f : 2.0f);
                }
            }
        }
        double x = pos.getX() + 0.5, y = pos.getY() + 0.9, z = pos.getZ() + 0.5;
        for (int i = 0; i < 24; i++) {
            double angle = i * Math.PI / 12.0;
            double radius = phase + 1.3;
            world.spawnParticles(phase == 3 ? ParticleTypes.ELECTRIC_SPARK : ParticleTypes.SCULK_SOUL,
                x + Math.cos(angle) * radius, y, z + Math.sin(angle) * radius, 1, 0, 0, 0, 0.02);
        }
        world.playSound(null, pos, SoundEvents.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.HOSTILE,
            0.6f + phase * 0.1f, 0.9f - phase * 0.1f);
        world.scheduleBlockTick(pos, this, phase == 3 ? 400 : 160);
    }

    @Override protected ItemActionResult onUseWithItem(ItemStack stack, BlockState state, World world,
            BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (!stack.isOf(HollowSignal.ECHO_SHARD)) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (world.isClient) return ItemActionResult.SUCCESS;
        if (!player.getAbilities().creativeMode) stack.decrement(1);
        seal((ServerWorld) world, pos, player);
        return ItemActionResult.SUCCESS;
    }

    public static void seal(ServerWorld world, BlockPos pos, PlayerEntity player) {
        if (!world.getBlockState(pos).isOf(HollowSignal.SIGNAL_RIFT)) return;
        int phase = world.getBlockState(pos).get(PHASE);
        world.removeBlock(pos, false);
        int reward = 2 + world.getRandom().nextInt(3) + phase;
        if (SignalManager.currentEvent() == NightEvent.ECHO_BLOOM) reward += 2;
        Block.dropStack(world, pos, new ItemStack(HollowSignal.ECHO_SHARD, reward));
        player.addExperience(8 + phase * 4);
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 300, 0));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 300, 0));
        if (player instanceof net.minecraft.server.network.ServerPlayerEntity serverPlayer) {
            SignalManager.clearExposure(serverPlayer);
            SignalManager.riftSealed(serverPlayer);
        }
        world.spawnParticles(ParticleTypes.SCULK_SOUL, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5,
            45, 0.7, 0.8, 0.7, 0.08);
        world.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK, SoundCategory.BLOCKS, 1.0f, 0.75f);
        player.sendMessage(Text.translatable("message.hollow_signal.rift_sealed", reward), true);
    }

    @Override public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        int phase = state.get(PHASE);
        if (random.nextInt(phase >= 2 ? 1 : 3) == 0) world.addParticle(
            phase >= 3 ? ParticleTypes.ELECTRIC_SPARK : ParticleTypes.SCULK_SOUL,
            pos.getX() + 0.2 + random.nextDouble() * 0.6, pos.getY() + random.nextDouble() * 1.2,
            pos.getZ() + 0.2 + random.nextDouble() * 0.6, 0.0, 0.02, 0.0);
    }
}
