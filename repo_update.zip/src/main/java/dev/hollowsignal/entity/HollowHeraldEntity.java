package dev.hollowsignal.entity;

import dev.hollowsignal.HollowSignal;
import dev.hollowsignal.SignalManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class HollowHeraldEntity extends HostileEntity {
    private final ServerBossBar bossBar = new ServerBossBar(getDisplayName(), BossBar.Color.PURPLE, BossBar.Style.NOTCHED_10);
    private int summonCooldown = 200;
    private int pulseCooldown = 120;
    private boolean secondPhase;

    public HollowHeraldEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        experiencePoints = 120;
        bossBar.setDarkenSky(true);
    }

    public static DefaultAttributeContainer.Builder attributes() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 160)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.29)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 9)
            .add(EntityAttributes.GENERIC_ARMOR, 8)
            .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48);
    }

    @Override protected void initGoals() {
        goalSelector.add(1, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.add(5, new WanderAroundFarGoal(this, 0.7));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override protected void mobTick() {
        super.mobTick();
        bossBar.setPercent(getHealth() / getMaxHealth());
        boolean enraged = getHealth() < getMaxHealth() * 0.5f;
        if (enraged && !secondPhase && getWorld() instanceof ServerWorld server) {
            secondPhase = true;
            bossBar.setColor(BossBar.Color.RED);
            SignalManager.openHeraldRift(server, getBlockPos());
            summonEscort();
            server.spawnParticles(ParticleTypes.SCULK_SOUL, getX(), getBodyY(1.0), getZ(), 80, 1.2, 1.4, 1.2, 0.08);
            getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_ROAR, getSoundCategory(), 1.4f, 0.6f);
            for (PlayerEntity player : getWorld().getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(32), p -> true)) {
                player.sendMessage(Text.translatable("message.hollow_signal.herald_phase_two").formatted(Formatting.DARK_RED), true);
            }
        }
        if (enraged && age % 40 == 0 && getWorld() instanceof ServerWorld server
                && SignalManager.findNearestRift(server, getBlockPos(), 16) != null) heal(2.0f);
        if (--pulseCooldown == 20 && getWorld() instanceof ServerWorld server) {
            server.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getBodyY(0.7), getZ(), 36, 1.2, 0.8, 1.2, 0.02);
            getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_CHARGE, getSoundCategory(), 1.0f, 0.55f);
        }
        if (pulseCooldown <= 0) {
            pulseCooldown = enraged ? 100 : 160;
            for (PlayerEntity player : getWorld().getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(18), p -> !p.isCreative() && !p.isSpectator())) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 120, 0));
                if (enraged) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 0));
            }
            if (getWorld() instanceof ServerWorld server) server.spawnParticles(ParticleTypes.SONIC_BOOM,
                getX(), getBodyY(0.6), getZ(), 1, 0, 0, 0, 0);
            getWorld().playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, getSoundCategory(), 0.9f, 0.8f);
        }
        if (--summonCooldown <= 0 && getTarget() != null) {
            summonCooldown = enraged ? 240 : 400;
            summonEscort();
        }
        if (getWorld() instanceof ServerWorld server && age % 10 == 0) {
            server.spawnParticles(ParticleTypes.SCULK_SOUL, getX(), getBodyY(1.1), getZ(), 4, 0.5, 0.6, 0.5, 0.01);
        }
    }

    private void summonEscort() {
        World world = getWorld();
        int nearby = world.getEntitiesByClass(HollowWatcherEntity.class, getBoundingBox().expand(24), e -> e.isAlive()).size();
        if (nearby >= 4) return;
        int spawned = 0;
        for (int attempt = 0; attempt < 20 && spawned < Math.min(2, 4 - nearby); attempt++) {
            HollowWatcherEntity watcher = HollowSignal.HOLLOW_WATCHER.create(world);
            if (watcher == null) return;
            BlockPos spot = getBlockPos().add(random.nextBetween(-5, 5), random.nextBetween(-2, 2), random.nextBetween(-5, 5));
            if (!world.getBlockState(spot.down()).isSolidBlock(world, spot.down())) continue;
            if (!world.getBlockState(spot).isAir() || !world.getBlockState(spot.up()).isAir()) continue;
            watcher.refreshPositionAndAngles(spot, random.nextFloat() * 360.0f, 0.0f);
            if (!world.isSpaceEmpty(watcher)) continue;
            watcher.setTarget(getTarget());
            if (world.spawnEntity(watcher)) spawned++;
        }
        if (spawned > 0) world.playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_ROAR, getSoundCategory(), 1.0f, 1.2f);
    }

    @Override public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bossBar.addPlayer(player);
    }

    @Override public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bossBar.removePlayer(player);
    }

    @Override public void setCustomName(net.minecraft.text.Text name) {
        super.setCustomName(name);
        bossBar.setName(getDisplayName());
    }

    @Override public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("HollowSignalSecondPhase", secondPhase);
    }

    @Override public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        secondPhase = nbt.getBoolean("HollowSignalSecondPhase");
        if (secondPhase) bossBar.setColor(BossBar.Color.RED);
    }

    @Override public boolean isFireImmune() { return true; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean canBeLeashed() { return false; }

    @Override public boolean damage(DamageSource source, float amount) {
        if (source.isIn(net.minecraft.registry.tag.DamageTypeTags.IS_PROJECTILE)) amount *= 0.5f;
        return super.damage(source, amount);
    }

    @Override public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity living) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 140, 0));
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 200, 1));
        }
        return hit;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_WARDEN_HEARTBEAT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_WARDEN_DEATH; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_WARDEN_HURT; }
}
