package dev.hollowsignal.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

public class HollowWatcherEntity extends SpiderEntity {
    private int snareCooldown = 120;
    public HollowWatcherEntity(EntityType<? extends SpiderEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder attributes() {
        return SpiderEntity.createSpiderAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 22)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4);
    }

    @Override protected void mobTick() {
        super.mobTick();
        if (!(getWorld() instanceof ServerWorld server) || --snareCooldown > 0) return;
        snareCooldown = 140 + random.nextInt(80);
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive() || squaredDistanceTo(target) > 64) return;
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 70, 2, true, false, false));
        server.spawnParticles(ParticleTypes.WITCH, target.getX(), target.getBodyY(0.5), target.getZ(), 22, 0.6, 0.8, 0.6, 0.01);
        server.spawnParticles(ParticleTypes.SCULK_SOUL, getX(), getBodyY(0.6), getZ(), 12, 0.5, 0.3, 0.5, 0.01);
        playSound(SoundEvents.ENTITY_SPIDER_AMBIENT, 0.9f, 0.55f);
    }

    @Override public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity living) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 0));
        }
        return hit;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.BLOCK_SCULK_SENSOR_CLICKING; }
}
