package dev.hollowsignal.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

public class NullCreeperEntity extends HostileEntity {
    private static final TrackedData<Boolean> PRIMED =
        DataTracker.registerData(NullCreeperEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private static final int FUSE_LENGTH = 34;
    private int fuse;

    public NullCreeperEntity(EntityType<? extends HostileEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder attributes() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 18)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.29)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 2)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 36);
    }

    @Override protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(PRIMED, false);
    }

    @Override protected void initGoals() {
        goalSelector.add(1, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.15, false));
        goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 10.0f));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    public boolean isPrimed() { return dataTracker.get(PRIMED); }

    public float fuseProgress() { return MathHelper.clamp(fuse / (float) FUSE_LENGTH, 0.0f, 1.0f); }

    @Override public void tick() {
        if (!getWorld().isClient) {
            LivingEntity target = getTarget();
            boolean close = target != null && target.isAlive() && squaredDistanceTo(target) < 20.0;
            if (close) {
                if (fuse == 0) playSound(SoundEvents.ENTITY_CREEPER_PRIMED, 1.0f, 0.6f);
                fuse++;
            } else if (fuse > 0) {
                fuse -= 2;
            }
            fuse = Math.max(0, fuse);
            dataTracker.set(PRIMED, fuse > 0);
            if (fuse > 0 && fuse % 5 == 0 && getWorld() instanceof ServerWorld server) {
                server.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getBodyY(0.5), getZ(),
                    4 + fuse / 5, 0.4 + fuse / 80.0, 0.5, 0.4 + fuse / 80.0, 0.02);
            }
            if (fuse >= FUSE_LENGTH) detonate();
        } else if (isPrimed()) {
            fuse = Math.min(FUSE_LENGTH, fuse + 1);
        } else {
            fuse = Math.max(0, fuse - 2);
        }
        super.tick();
    }

    private void detonate() {
        World world = getWorld();
        world.createExplosion(this, getX(), getBodyY(0.5), getZ(), 2.2f, World.ExplosionSourceType.NONE);
        for (LivingEntity living : world.getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(10), e -> e instanceof PlayerEntity)) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 200, 0));
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 0));
        }
        world.playSound(null, getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, getSoundCategory(), 0.8f, 1.4f);
        discard();
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.BLOCK_SCULK_SHRIEKER_SHRIEK; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_CREEPER_DEATH; }
    @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) { return SoundEvents.ENTITY_CREEPER_HURT; }
    @Override public boolean isFireImmune() { return true; }
}
