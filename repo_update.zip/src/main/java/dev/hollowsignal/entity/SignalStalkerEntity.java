package dev.hollowsignal.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class SignalStalkerEntity extends ZombieEntity {
    private int phaseCooldown = 160;
    public SignalStalkerEntity(EntityType<? extends ZombieEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder attributes() {
        return ZombieEntity.createZombieAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 34)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.31)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40);
    }

    @Override protected boolean burnsInDaylight() { return false; }

    @Override protected void mobTick() {
        super.mobTick();
        if (!(getWorld() instanceof ServerWorld server) || --phaseCooldown > 0) return;
        phaseCooldown = 160 + random.nextInt(100);
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive() || squaredDistanceTo(target) < 16 || squaredDistanceTo(target) > 196) return;
        Vec3d behind = target.getRotationVec(1.0f).multiply(-2.2);
        Vec3d arrival = target.getPos().add(behind.x, 0, behind.z);
        if (!server.isSpaceEmpty(this, getBoundingBox().offset(arrival.subtract(getPos())))) return;
        server.spawnParticles(ParticleTypes.SCULK_SOUL, getX(), getBodyY(0.6), getZ(), 20, 0.4, 0.8, 0.4, 0.04);
        requestTeleport(arrival.x, arrival.y, arrival.z);
        server.spawnParticles(ParticleTypes.SCULK_SOUL, getX(), getBodyY(0.6), getZ(), 24, 0.5, 0.8, 0.5, 0.04);
        playSound(SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0.7f, 0.65f);
    }

    @Override public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity living) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 80, 0));
        }
        return hit;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_WARDEN_HEARTBEAT; }
}
