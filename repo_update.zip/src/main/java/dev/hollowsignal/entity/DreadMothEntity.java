package dev.hollowsignal.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

public class DreadMothEntity extends PhantomEntity {
    private int shriekCooldown = 140;
    public DreadMothEntity(EntityType<? extends PhantomEntity> type, World world) {
        super(type, world);
        setPhantomSize(1);
    }

    public static DefaultAttributeContainer.Builder attributes() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 16)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.32)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48);
    }

    /** Phantom size is randomized on spawn; keep the target area tied to this model instead. */
    @Override public EntityDimensions getBaseDimensions(EntityPose pose) {
        return EntityDimensions.fixed(2.0f, 1.0f);
    }

    /** Phantom movement is useful here, but vanilla's daylight ignition hides our model. */
    @Override protected boolean isAffectedByDaylight() { return false; }

    @Override protected void mobTick() {
        super.mobTick();
        if (!(getWorld() instanceof ServerWorld server) || --shriekCooldown > 0) return;
        shriekCooldown = 160 + random.nextInt(100);
        LivingEntity target = getTarget();
        if (target == null || squaredDistanceTo(target) > 100) return;
        server.spawnParticles(ParticleTypes.SONIC_BOOM, getX(), getBodyY(0.5), getZ(), 1, 0, 0, 0, 0);
        server.spawnParticles(ParticleTypes.END_ROD, getX(), getBodyY(0.5), getZ(), 18, 1.2, 0.4, 1.2, 0.03);
        for (PlayerEntity player : server.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(7), p -> !p.isCreative() && !p.isSpectator())) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 70, 0, true, false, false));
        }
        playSound(SoundEvents.ENTITY_PHANTOM_SWOOP, 1.0f, 0.6f);
    }

    @Override public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity living) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0));
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 120, 0));
        }
        return hit;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_PHANTOM_AMBIENT; }
    @Override protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) { return SoundEvents.ENTITY_PHANTOM_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_PHANTOM_DEATH; }
}
