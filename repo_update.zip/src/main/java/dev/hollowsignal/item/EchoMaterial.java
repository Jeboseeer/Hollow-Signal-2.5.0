package dev.hollowsignal.item;

import dev.hollowsignal.HollowSignal;
import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;

/** Tool material for the echo weapons: diamond-grade reach, repaired with Echo Shards. */
public enum EchoMaterial implements ToolMaterial {
    INSTANCE;

    @Override public int getDurability() { return 1240; }
    @Override public float getMiningSpeedMultiplier() { return 7.0f; }
    @Override public float getAttackDamage() { return 3.5f; }
    @Override public TagKey<Block> getInverseTag() { return BlockTags.INCORRECT_FOR_DIAMOND_TOOL; }
    @Override public int getEnchantability() { return 20; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(HollowSignal.ECHO_SHARD); }
}
