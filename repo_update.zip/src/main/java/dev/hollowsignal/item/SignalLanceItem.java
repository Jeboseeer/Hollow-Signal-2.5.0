package dev.hollowsignal.item;

import dev.hollowsignal.HollowSignal;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/** Reach weapon: hits from a block further away and throws the target back. */
public class SignalLanceItem extends SwordItem {
    private static final Identifier REACH_ID = Identifier.of(HollowSignal.MOD_ID, "lance_reach");

    public SignalLanceItem(ToolMaterial material, Settings settings) { super(material, settings); }

    /** A piercing thrust follows the crosshair and stops at the first wall. */
    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (player.getItemCooldownManager().isCoolingDown(this)) return TypedActionResult.fail(stack);
        if (world.isClient) {
            dev.hollowsignal.client.WeaponAnimation.start(hand, 2);
            return TypedActionResult.success(stack);
        }
        Vec3d start = player.getEyePos();
        Vec3d direction = player.getRotationVec(1.0f);
        Vec3d end = start.add(direction.multiply(8.0));
        BlockHitResult wall = world.raycast(new RaycastContext(start, end,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        if (wall.getType() != HitResult.Type.MISS) end = wall.getPos();
        double range = start.distanceTo(end);
        if (world instanceof ServerWorld server) {
            for (double distance = 0.5; distance < range; distance += 0.5) {
                Vec3d point = start.add(direction.multiply(distance));
                server.spawnParticles(ParticleTypes.ELECTRIC_SPARK, point.x, point.y, point.z, 2, 0.08, 0.08, 0.08, 0.01);
                if (distance < 4.0) server.spawnParticles(ParticleTypes.ENCHANT,
                    point.x, point.y, point.z, 1, 0.12, 0.12, 0.12, 0.02);
            }
            for (LivingEntity target : server.getEntitiesByClass(LivingEntity.class,
                    player.getBoundingBox().stretch(end.subtract(start)).expand(1.0), e -> e != player && e.isAlive())) {
                Vec3d offset = target.getBoundingBox().getCenter().subtract(start);
                double along = offset.dotProduct(direction);
                if (along < 0 || along > range || offset.subtract(direction.multiply(along)).lengthSquared() > 0.85 * 0.85) continue;
                target.damage(world.getDamageSources().playerAttack(player), HollowSignal.isHollowMob(target) ? 11.0f : 7.0f);
                target.takeKnockback(1.7, player.getX() - target.getX(), player.getZ() - target.getZ());
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 120, 0, true, false, false));
            }
        }
        world.playSound(null, player.getBlockPos(), SoundEvents.ITEM_TRIDENT_HIT, SoundCategory.PLAYERS, 1.0f, 0.75f);
        player.getItemCooldownManager().set(this, 100);
        player.swingHand(hand);
        stack.damage(2, player, hand == Hand.MAIN_HAND ? net.minecraft.entity.EquipmentSlot.MAINHAND : net.minecraft.entity.EquipmentSlot.OFFHAND);
        return TypedActionResult.success(stack);
    }

    public static AttributeModifiersComponent modifiers(double damage, double speed, double reach) {
        return AttributeModifiersComponent.builder()
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                new EntityAttributeModifier(Item.BASE_ATTACK_DAMAGE_MODIFIER_ID, damage, EntityAttributeModifier.Operation.ADD_VALUE),
                AttributeModifierSlot.MAINHAND)
            .add(EntityAttributes.GENERIC_ATTACK_SPEED,
                new EntityAttributeModifier(Item.BASE_ATTACK_SPEED_MODIFIER_ID, speed, EntityAttributeModifier.Operation.ADD_VALUE),
                AttributeModifierSlot.MAINHAND)
            .add(EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE,
                new EntityAttributeModifier(REACH_ID, reach, EntityAttributeModifier.Operation.ADD_VALUE),
                AttributeModifierSlot.MAINHAND)
            .build();
    }

    @Override public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.postHit(stack, target, attacker);
        target.takeKnockback(1.1, attacker.getX() - target.getX(), attacker.getZ() - target.getZ());
        if (HollowSignal.isHollowMob(target)) {
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 120, 0, true, false, false));
        }
        attacker.getWorld().playSound(null, attacker.getBlockPos(), SoundEvents.ITEM_TRIDENT_HIT, SoundCategory.PLAYERS, 0.8f, 1.3f);
        return result;
    }
}
