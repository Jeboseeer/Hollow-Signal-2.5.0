package dev.hollowsignal.item;

import dev.hollowsignal.HollowSignal;
import dev.hollowsignal.block.SignalRiftBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Ranged weapon: fires a sonic pulse along the player's view, paid for with one Echo Shard. */
public class ResonatorItem extends Item {
    private static final double RANGE = 24.0;
    private static final float DAMAGE = 9.0f;
    private static final int COOLDOWN = 50;

    public ResonatorItem(Settings settings) { super(settings); }

    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (player.getItemCooldownManager().isCoolingDown(this)) return TypedActionResult.fail(stack);
        if (world.isClient) {
            if (!player.getAbilities().creativeMode && !hasShards(player, player.isSneaking() ? 3 : 1)) {
                return TypedActionResult.fail(stack);
            }
            dev.hollowsignal.client.WeaponAnimation.start(hand, 3);
            return TypedActionResult.success(stack);
        }
        boolean overcharged = player.isSneaking();
        int cost = overcharged ? 3 : 1;
        if (!player.getAbilities().creativeMode && !consumeShards(player, cost)) {
            player.sendMessage(Text.translatable("message.hollow_signal.resonator_empty").formatted(Formatting.GRAY), true);
            return TypedActionResult.fail(stack);
        }
        if (overcharged) {
            Vec3d forward = player.getRotationVec(1.0f);
            Vec3d side = new Vec3d(-forward.z, 0, forward.x).normalize();
            fire(world, player, forward.add(side.multiply(-0.19)).normalize(), 0.75f);
            fire(world, player, forward, 1.15f);
            fire(world, player, forward.add(side.multiply(0.19)).normalize(), 0.75f);
        } else {
            fire(world, player, player.getRotationVec(1.0f), 1.0f);
        }
        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS,
            overcharged ? 1.2f : 0.8f, overcharged ? 0.65f : 1.2f);
        player.getItemCooldownManager().set(this, overcharged ? 140 : COOLDOWN);
        player.swingHand(hand);
        stack.damage(overcharged ? 3 : 1, player,
            hand == Hand.MAIN_HAND ? net.minecraft.entity.EquipmentSlot.MAINHAND : net.minecraft.entity.EquipmentSlot.OFFHAND);
        return TypedActionResult.success(stack);
    }

    private static void fire(World world, PlayerEntity player, Vec3d direction, float strength) {
        Vec3d start = player.getEyePos();
        Vec3d end = start.add(direction.multiply(RANGE));
        BlockHitResult blockHit = world.raycast(new RaycastContext(start, end,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        if (blockHit.getType() != HitResult.Type.MISS) end = blockHit.getPos();
        EntityHitResult hit = ProjectileUtil.raycast(player, start, end,
            player.getBoundingBox().stretch(end.subtract(start)).expand(1.0),
            entity -> entity instanceof LivingEntity && entity != player && entity.isAlive(), start.squaredDistanceTo(end));
        if (world instanceof ServerWorld server) {
            Vec3d side = direction.crossProduct(new Vec3d(0, 1, 0)).normalize();
            if (side.lengthSquared() < 0.01) side = new Vec3d(1, 0, 0);
            Vec3d up = direction.crossProduct(side).normalize();
            Vec3d muzzle = start.add(direction.multiply(1.2));
            for (int i = 0; i < 10; i++) {
                double angle = i * Math.PI / 5.0;
                Vec3d spark = muzzle.add(side.multiply(Math.cos(angle) * 0.38))
                    .add(up.multiply(Math.sin(angle) * 0.38));
                server.spawnParticles(ParticleTypes.ELECTRIC_SPARK,
                    spark.x, spark.y, spark.z, 1, 0, 0, 0, 0.015);
            }
            Vec3d step = end.subtract(start).normalize().multiply(0.9);
            Vec3d point = start;
            double reach = hit == null ? end.distanceTo(start) : hit.getPos().distanceTo(start);
            for (double travelled = 0.0; travelled < reach; travelled += 0.9) {
                server.spawnParticles(ParticleTypes.END_ROD, point.x, point.y, point.z, 1, 0.0, 0.0, 0.0, 0.0);
                point = point.add(step);
            }
        }
        if (hit != null && hit.getEntity() instanceof LivingEntity target) {
            if (world instanceof ServerWorld server) {
                server.spawnParticles(ParticleTypes.SONIC_BOOM, target.getX(), target.getBodyY(0.6), target.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
            }
            float damage = (HollowSignal.isHollowMob(target) ? DAMAGE + 4.0f : DAMAGE) * strength;
            target.damage(world.getDamageSources().sonicBoom(player), damage);
            target.takeKnockback(0.9, player.getX() - target.getX(), player.getZ() - target.getZ());
        } else if (blockHit.getType() == HitResult.Type.BLOCK && world.getBlockState(blockHit.getBlockPos()).isOf(HollowSignal.SIGNAL_RIFT)
                && world instanceof ServerWorld server) {
            SignalRiftBlock.seal(server, blockHit.getBlockPos(), player);
        }
    }

    private static boolean consumeShards(PlayerEntity player, int count) {
        if (!hasShards(player, count)) return false;
        for (int slot = 0; slot < player.getInventory().size(); slot++) {
            ItemStack candidate = player.getInventory().getStack(slot);
            if (!candidate.isOf(HollowSignal.ECHO_SHARD)) continue;
            int taken = Math.min(count, candidate.getCount());
            candidate.decrement(taken);
            count -= taken;
            if (count == 0) return true;
        }
        return false;
    }

    private static boolean hasShards(PlayerEntity player, int count) {
        int available = 0;
        for (int slot = 0; slot < player.getInventory().size(); slot++) {
            if (player.getInventory().getStack(slot).isOf(HollowSignal.ECHO_SHARD)) {
                available += player.getInventory().getStack(slot).getCount();
            }
        }
        return available >= count;
    }

    @Override public boolean isEnchantable(ItemStack stack) { return true; }
}
