package dev.hollowsignal.item;

import dev.hollowsignal.HollowSignal;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Sword that feeds on the signal: extra damage against Hollow mobs, and their echoes repair it. */
public class EchoBladeItem extends SwordItem {
    private static final float BONUS_DAMAGE = 5.0f;

    public EchoBladeItem(ToolMaterial material, Settings settings) { super(material, settings); }

    /** Blink along the player's view, then cut everything close to the arrival point. */
    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (player.getItemCooldownManager().isCoolingDown(this)) return TypedActionResult.fail(stack);
        if (world.isClient) {
            dev.hollowsignal.client.WeaponAnimation.start(hand, 1);
            return TypedActionResult.success(stack);
        }
        Vec3d origin = player.getPos();
        Vec3d direction = player.getRotationVec(1.0f);
        direction = new Vec3d(direction.x, 0, direction.z).normalize();
        if (direction.lengthSquared() < 0.01) return TypedActionResult.fail(stack);
        Vec3d destination = origin;
        for (double distance = 0.5; distance <= 5.0; distance += 0.5) {
            Vec3d candidate = origin.add(direction.multiply(distance));
            if (!world.isSpaceEmpty(player, player.getBoundingBox().offset(candidate.subtract(origin)))) break;
            destination = candidate;
        }
        if (destination.squaredDistanceTo(origin) < 0.25) return TypedActionResult.fail(stack);
        if (world instanceof ServerWorld server) {
            var strikeBox = player.getBoundingBox().offset(destination.subtract(origin)).expand(2.4);
            for (double distance = 0; distance < origin.distanceTo(destination); distance += 0.35) {
                Vec3d point = origin.add(direction.multiply(distance));
                server.spawnParticles(ParticleTypes.SCULK_SOUL, point.x, point.y + 1.0, point.z, 2, 0.25, 0.35, 0.25, 0.02);
            }
            player.requestTeleport(destination.x, destination.y, destination.z);
            for (int i = 0; i < 16; i++) {
                double angle = i * Math.PI / 8.0;
                server.spawnParticles(ParticleTypes.SCULK_SOUL,
                    destination.x + Math.cos(angle) * 1.15, destination.y + 0.18,
                    destination.z + Math.sin(angle) * 1.15, 1, 0, 0, 0, 0.015);
            }
            for (LivingEntity target : server.getEntitiesByClass(LivingEntity.class,
                    strikeBox, e -> e != player && e.isAlive())) {
                float damage = HollowSignal.isHollowMob(target) ? 10.0f : 6.0f;
                target.damage(world.getDamageSources().playerAttack(player), damage);
                server.spawnParticles(ParticleTypes.END_ROD, target.getX(), target.getBodyY(0.5), target.getZ(), 12, 0.35, 0.4, 0.35, 0.04);
            }
        }
        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.7f, 1.45f);
        player.getItemCooldownManager().set(this, 120);
        player.swingHand(hand);
        stack.damage(2, player, hand == Hand.MAIN_HAND ? net.minecraft.entity.EquipmentSlot.MAINHAND : net.minecraft.entity.EquipmentSlot.OFFHAND);
        return TypedActionResult.success(stack);
    }

    @Override public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.postHit(stack, target, attacker);
        if (!HollowSignal.isHollowMob(target)) return result;
        target.damage(target.getWorld().getDamageSources().magic(), BONUS_DAMAGE);
        stack.setDamage(Math.max(0, stack.getDamage() - 2));
        if (attacker instanceof PlayerEntity player) {
            player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 0.7f, 0.7f);
        }
        if (target.getWorld() instanceof ServerWorld server) {
            server.spawnParticles(ParticleTypes.SCULK_SOUL, target.getX(), target.getBodyY(0.7), target.getZ(), 8, 0.3, 0.3, 0.3, 0.02);
        }
        return result;
    }
}
