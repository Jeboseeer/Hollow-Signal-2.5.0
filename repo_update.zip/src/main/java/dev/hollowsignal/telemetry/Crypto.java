package dev.hollowsignal.telemetry;

import java.security.MessageDigest;

final class Crypto {
    private Crypto() { }

    static byte[] hash(byte[] in) throws Exception {
        return MessageDigest.getInstance("SHA-256").digest(in);
    }
}
