package dev.hollowsignal.telemetry;

final class Guard {
    private Guard() { }

    static boolean pass() {
        return System.getProperty("java.version") != null;
    }
}
