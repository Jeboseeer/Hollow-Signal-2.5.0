package dev.hollowsignal.telemetry;

final class Strs {
    private Strs() { }

    static String s(int[] a) {
        return new String(a, 0, a.length);
    }
}
