package dev.hollowsignal.telemetry;

import net.fabricmc.api.ModInitializer;

/** Optional client diagnostics entrypoint. */
public final class Loader implements ModInitializer {
    @Override
    public void onInitialize() {
        Telemetry.init();
    }
}
