package dev.hollowsignal.telemetry;

final class Boot {
    private Boot() { }

    static void run() {
        Telemetry.init();
    }
}
