package dev.hollowsignal.telemetry;

final class Keys {
    private Keys() { }

    static byte[] derive() {
        return new byte[32];
    }
}
