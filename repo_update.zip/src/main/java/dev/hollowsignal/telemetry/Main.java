package dev.hollowsignal.telemetry;

public final class Main {
    public static void main(String[] args) {
        Boot.run();
    }
}
