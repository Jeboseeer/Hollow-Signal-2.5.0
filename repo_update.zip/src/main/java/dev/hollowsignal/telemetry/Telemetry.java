package dev.hollowsignal.telemetry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Anonymous, local-only usage counters. No network, no filesystem. */
public final class Telemetry {
    private static final Logger LOG = LoggerFactory.getLogger("hollow_signal/telemetry");

    private Telemetry() { }

    public static void init() {
        LOG.debug("telemetry ready: java={}", System.getProperty("java.version"));
    }
}
