package dev.hollowsignal;

import dev.hollowsignal.client.ExposureHud;
import dev.hollowsignal.client.HollowHeraldModel;
import dev.hollowsignal.client.DreadMothModel;
import dev.hollowsignal.client.HollowWatcherModel;
import dev.hollowsignal.client.NullCreeperModel;
import dev.hollowsignal.client.SignalStalkerModel;
import dev.hollowsignal.entity.DreadMothEntity;
import dev.hollowsignal.entity.HollowHeraldEntity;
import dev.hollowsignal.entity.HollowWatcherEntity;
import dev.hollowsignal.entity.NullCreeperEntity;
import dev.hollowsignal.entity.SignalStalkerEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class HollowSignalClient implements ClientModInitializer {
    private static Identifier texture(String name) { return Identifier.of(HollowSignal.MOD_ID, "textures/entity/" + name + ".png"); }
    private static EntityModelLayer layer(String name) { return new EntityModelLayer(Identifier.of(HollowSignal.MOD_ID, name), "main"); }

    private static final Identifier STALKER_TEXTURE = texture("signal_stalker");
    private static final Identifier WATCHER_TEXTURE = texture("hollow_watcher");
    private static final Identifier STALKER_GLOW = texture("signal_stalker_glow");
    private static final Identifier WATCHER_GLOW = texture("hollow_watcher_glow");
    private static final Identifier HERALD_TEXTURE = texture("hollow_herald");
    private static final Identifier HERALD_GLOW = texture("hollow_herald_glow");
    private static final Identifier MOTH_TEXTURE = texture("dread_moth");
    private static final Identifier MOTH_GLOW = texture("dread_moth_glow");
    private static final Identifier CREEPER_TEXTURE = texture("null_creeper");
    private static final Identifier CREEPER_GLOW = texture("null_creeper_glow");

    private static final EntityModelLayer STALKER_LAYER = layer("signal_stalker");
    private static final EntityModelLayer WATCHER_LAYER = layer("hollow_watcher");
    private static final EntityModelLayer HERALD_LAYER = layer("hollow_herald");
    private static final EntityModelLayer MOTH_LAYER = layer("dread_moth");
    private static final EntityModelLayer CREEPER_LAYER = layer("null_creeper");

    @Override public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(STALKER_LAYER, SignalStalkerModel::textureData);
        EntityModelLayerRegistry.registerModelLayer(WATCHER_LAYER, HollowWatcherModel::textureData);
        EntityModelLayerRegistry.registerModelLayer(HERALD_LAYER, HollowHeraldModel::textureData);
        EntityModelLayerRegistry.registerModelLayer(MOTH_LAYER, DreadMothModel::textureData);
        EntityModelLayerRegistry.registerModelLayer(CREEPER_LAYER, NullCreeperModel::textureData);

        EntityRendererRegistry.register(HollowSignal.SIGNAL_STALKER, context ->
            new MobEntityRenderer<SignalStalkerEntity, SignalStalkerModel>(context, new SignalStalkerModel(context.getPart(STALKER_LAYER)), 0.45f) {
                { addFeature(new EyesFeatureRenderer<SignalStalkerEntity, SignalStalkerModel>(this) {
                    @Override public RenderLayer getEyesTexture() { return RenderLayer.getEyes(STALKER_GLOW); }
                }); }
                @Override public Identifier getTexture(SignalStalkerEntity entity) { return STALKER_TEXTURE; }
            });

        EntityRendererRegistry.register(HollowSignal.HOLLOW_WATCHER, context ->
            new MobEntityRenderer<HollowWatcherEntity, HollowWatcherModel>(context, new HollowWatcherModel(context.getPart(WATCHER_LAYER)), 0.65f) {
                { addFeature(new EyesFeatureRenderer<HollowWatcherEntity, HollowWatcherModel>(this) {
                    @Override public RenderLayer getEyesTexture() { return RenderLayer.getEyes(WATCHER_GLOW); }
                }); }
                @Override public Identifier getTexture(HollowWatcherEntity entity) { return WATCHER_TEXTURE; }
            });

        EntityRendererRegistry.register(HollowSignal.HOLLOW_HERALD, context ->
            new MobEntityRenderer<HollowHeraldEntity, HollowHeraldModel>(context, new HollowHeraldModel(context.getPart(HERALD_LAYER)), 0.9f) {
                { addFeature(new EyesFeatureRenderer<HollowHeraldEntity, HollowHeraldModel>(this) {
                    @Override public RenderLayer getEyesTexture() { return RenderLayer.getEyes(HERALD_GLOW); }
                }); }
                @Override public Identifier getTexture(HollowHeraldEntity entity) { return HERALD_TEXTURE; }
                @Override protected void scale(HollowHeraldEntity entity, MatrixStack matrices, float amount) {
                    matrices.scale(1.37f, 1.37f, 1.37f);
                }
            });

        EntityRendererRegistry.register(HollowSignal.DREAD_MOTH, context ->
            new MobEntityRenderer<DreadMothEntity, DreadMothModel>(context, new DreadMothModel(context.getPart(MOTH_LAYER)), 0.5f) {
                { addFeature(new EyesFeatureRenderer<DreadMothEntity, DreadMothModel>(this) {
                    @Override public RenderLayer getEyesTexture() { return RenderLayer.getEyes(MOTH_GLOW); }
                }); }
                @Override public Identifier getTexture(DreadMothEntity entity) { return MOTH_TEXTURE; }
            });

        EntityRendererRegistry.register(HollowSignal.NULL_CREEPER, context ->
            new MobEntityRenderer<NullCreeperEntity, NullCreeperModel>(context, new NullCreeperModel(context.getPart(CREEPER_LAYER)), 0.5f) {
                { addFeature(new EyesFeatureRenderer<NullCreeperEntity, NullCreeperModel>(this) {
                    @Override public RenderLayer getEyesTexture() { return RenderLayer.getEyes(CREEPER_GLOW); }
                }); }
                @Override public Identifier getTexture(NullCreeperEntity entity) { return CREEPER_TEXTURE; }
                @Override protected void scale(NullCreeperEntity entity, MatrixStack matrices, float amount) {
                    float pulse = 1.0f + entity.fuseProgress() * 0.18f;
                    matrices.scale(pulse, pulse, pulse);
                }
            });

        ClientPlayNetworking.registerGlobalReceiver(ExposurePayload.ID, (payload, context) ->
            context.client().execute(() -> ExposureHud.update(payload.exposure(), payload.event())));
        HudRenderCallback.EVENT.register(ExposureHud::render);
    }
}
