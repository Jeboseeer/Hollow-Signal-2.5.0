# Changelog

## 2.5.0 — Escalating rifts

- Signal Rifts now escalate through three timed phases while a survival player is nearby at night. Each phase adds visible pulse effects and a guarded wave; the final phase brings a Null Creeper.
- Rift pulses slow nearby players and can damage those who stay close at higher phases. Guard populations are capped to prevent endless buildup.
- Closing a more dangerous rift awards one extra Echo Shard and four extra experience points per phase. You can still seal it early to avoid the fight.
- Added a square, original CurseForge project logo as `release/hollow-signal-curseforge-logo.png`.

## 2.4.2 — Weapon motion and quieter event announcements

- Replaced the full-screen night-event title with a short, compact banner that shows the event name and rules without covering the crosshair.
- Added distinct first-person ability animations: Echo Blade slash, Signal Lance thrust and Resonator recoil.
- Added a visible arrival ring for the blade, extra thrust sparks for the lance and a muzzle ring for the Resonator.

## 2.4.1 — A reason to survive the night

- Completing a dangerous night event now awards 2–4 Echo Shards at sunrise. Reaching 50 exposure, sealing a rift or defeating a Hollow mob qualifies; death forfeits the reward.
- Added a bilingual reward message and amethyst cue. Creative and spectator players cannot earn the survival reward.

## 2.4.0 — New night events and Resonator aim

- Aligned the Resonator's first-person barrel with the crosshair and checked its placement in Minecraft with Lumenite shaders.
- Added Red Eclipse: faster exposure, early swift Null Creepers, frequent rift guards, crimson spores and a low heartbeat.
- Added Echo Bloom: double shard drops, 18 exposure removed for each Hollow kill, bonus rift rewards, drifting lights and amethyst chimes.
- Added the operator `/hollowsignal event` command to select or randomize a night event for playtesting and custom maps.
- Updated the release screenshot set and fixed `build-local.ps1` to copy the current versioned JAR automatically.

## 2.3.0 — Combat and atmosphere

- Reworked all three voxel weapon silhouettes and angled the Resonator's recessed muzzle toward the aim point.
- Added an Echo Blade blink strike, a wall-blocked piercing thrust for the Signal Lance, and a three-ray Resonator overcharge.
- Gave the Stalker a phase jump, the Watcher a snare pulse and the Moth a sonic shriek. The Null Creeper now visibly sparks while charging, and the Herald telegraphs its pulse.
- Added distinct particles and ambient sounds for all four non-calm night events.
- Aligned the Dread Moth model with its stable hitbox and adjusted the Watcher's target area.
- Removed potion-style Glowing from Hollow mobs; they use emissive texture details and brief ability particles.
- Verified the release with the user's Lumenite shaderpack in an isolated Minecraft test world; the shader remains optional.

## 2.2.1 — Visual and interaction fixes

- Fixed the Hollow Herald's model pivot so its feet meet the ground while its horns still fit the hitbox height.
- Dread Moths no longer inherit the Phantom's daytime ignition, which hid their custom model behind flames.
- Gave Signal Rifts a solid collision shape so Resonator shots can hit and seal them as advertised.
- Verified all five mobs, three weapons, the Ward Beacon, Signal Rift, night HUD and Herald phase in an isolated Minecraft world; saved 1280×720 screenshots in the release folder.

## 2.2.0 — Signal Rifts

- Added naturally spawning Signal Rifts at high night exposure. Convergence opens them earlier; Signal Storms make their guards more aggressive.
- Rifts increase exposure nearby and summon Hollow Watchers. They persist until sealed, even after dawn.
- Seal a rift with an Echo Shard or a Resonator shot to earn shards, experience, temporary Resistance and Speed, and an exposure reset.
- The Signal Finder now reports the nearest rift's distance and direction.
- Added a tall voxel crystal model, soul particles, light and bilingual messages. Corrected the Resonator beam so it stops visually at the block it hits.
- The Herald now opens a rift at half health and regenerates while one remains nearby; sealing it interrupts that phase mechanic.

## 2.1.2 — Grounded Herald and night atmosphere

- Repositioned and scaled the Hollow Herald model so its boots meet the ground. Added mask ribs, shoulder spikes, gauntlets, leg armour and a split cloak.
- Added separate first-person, third-person and inventory poses for each weapon, plus more visible trim and glowing details.
- Added a subtle exposure vignette, rare heartbeat ambience and ash particles during Signal Storms.
- Herald escorts now search for a clear, supported spawn position.
- Fixed the Null Creeper crest and Herald arm UVs. Added `tools/verify_entity_uv.py` to detect cuboids extending beyond their textures.

## 2.1.1 — Weapon models and fixes

- Replaced the flat weapon icons with separate 3D voxel models for the Echo Blade, Signal Lance and Resonator.
- Resonator pulses now stop at solid blocks instead of striking targets through walls.
- The server sends exposure HUD packets only to clients that support the channel.
- Echo Totems restore full health, matching their description.
- Herald rituals check the available space and whether the boss actually spawned before spending a shard or announcing its arrival.
- Exposure resets only after a Stalker successfully appears, and temporary signal state clears when the server stops.

## 2.1.0 — Echo armoury

**Weapons**
- Echo Blade: sword on a new echo tool material (1240 durability, repaired with Echo Shards). Hits make the target glow; against mod mobs it deals 5 extra damage and the echo repairs the blade.
- Signal Lance: one extra block of attack reach, heavy knockback, and Weakness on mod mobs.
- Resonator: ranged. A sonic pulse up to 24 blocks for 9 damage (13 against mod mobs), knockback and lasting Glowing; each shot spends an Echo Shard and has a 2.5-second cooldown.
- All three have their own recipes, recipe unlocks and advancements, and sit in the Combat creative tab.

**Models**
- Dread Moth now has its own 3D model — body, head with a proboscis, two antennae, a segmented tail and two-part flapping wings — plus a glowing eye layer.
- Null Creeper now has its own 3D model with a crest, a vent and a core that swells while the fuse burns, plus a glowing core layer. Both mobs stopped reusing vanilla phantom and creeper geometry.

## 2.0.0 — Signal escalation

**New mobs**
- Dread Moth: a flier that inflicts Blindness and Weakness, drawn into Signal Storms.
- Null Creeper: primes a quiet blast that destroys no blocks but blinds and slows everyone within ten blocks.
- Hollow Herald: a 160-health boss with a custom 3D model, boss bar, darkness pulses, a Watcher escort and an Echo Heart drop.

**Night events** — at dusk the world rolls Signal Storm, Dead Silence, Echo Hunt, Convergence or a calm night. Each one changes exposure speed, warnings, spawns or drops, is announced on screen and ends at sunrise.

**Ward Beacon rework** — the block is now a block entity with fuel, tiers and states. Echo Shards fuel it (eight max, two minutes of night each), Echo Blocks stacked beneath raise its tier to 3, and an Echo Heart makes it eternal. While lit it suppresses exposure, makes Hollow mobs glow, grants Night Vision and Resistance, and at tier 3 burns mod mobs inside its radius. Right click it for its status.

**New items and blocks** — Echo Block (nine shards, also the ritual altar), Echo Heart (boss drop), Echo Totem (spent instead of your death: full restore, effects cleared, exposure cleared).

**Herald ritual** — right click an Echo Block with an Echo Shard at night to summon the boss.

**Exposure HUD** — a client-side meter in the lower left corner with the current night event, sent over a custom packet. Vanilla clients can still join a server running the mod.

**Configuration** — `config/hollow_signal.properties` exposes exposure rate, night events, signal spawns, the ritual, the HUD, warnings and the beacon radius.

**Advancements** — eight of them, from the first Echo Shard to silencing the Herald and crafting the Totem.

**Other**
- Exposure escalation no longer depends on exact exposure values, so a custom `exposure_rate` can never skip a spawn threshold.
- Spawn attempts now place fliers above ground level and set the hunter's target immediately.
- Exposure is forgotten when a player disconnects.
- Mod icon, author and description metadata added for the launcher, Mod Menu and the project page.
- `tools/verify_resources.py` fails the build pipeline if any referenced model, texture or translation key is missing.

## 1.2.0

- Custom 3D models, layered textures and glowing eye layers for the Hollow Watcher and the Signal Stalker.
- Spawn eggs for both mobs.

## 1.1.0

- Ward Beacon block, Ward Charm, Signal Finder, Echo Shard drops and Russian translation.

## 1.0.0

- First release: darkness exposure, warnings and the Signal Stalker encounter.
